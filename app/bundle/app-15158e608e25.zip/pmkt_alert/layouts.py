"""Each team's input files: what to download, how the app recognises each file, and how its sheets map onto the tables
the rules run on (loaders.load_inputs). SSO is the layout from before teams; SFO's Data workbook carries the same data
in another shape (Product_info, KPI per SKU), which load_inputs turns into SSO's tables."""
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Layout:
    team: str
    name: str
    sheets: dict  # table → sheet name in the Data workbook (raw, products, kpi, ineligible, listing, inventory)
    ads_sheets: tuple  # Ads by Campaign: the export's sheet first, then the Data workbook's copy
    exports: tuple  # SharePoint exports found in OneDrive (synced files or "Add shortcut to My files" .url)
    hourly_file: str
    kpi_header_row: int = 1
    keepa: bool = True  # Keepa listing flags (US Keepa Raw Auto) cover this team's ASINs
    all_accounts: bool = False  # Ads accounts: False = the account with the most rows (SSO: Yes4All); True = every one
    kpi_by_sku: bool = False  # KPI rows are per SKU (SFO): the target goes to the SKU's Main ASIN
    ads_export_wins: bool = False  # the Ads export beats the Data workbook's pasted copy even if the workbook was saved later
    guide: tuple = field(default_factory=tuple)  # the Run page's "where the files come from", one line each
    data_file: str = ""  # the Data workbook (Product Info, KPI, Summary) – what the people of this team call it


SSO = Layout(
    team="sso", name="SSO",
    sheets={"raw": "raw_sso_us", "products": "Product Info", "kpi": "KPI", "ineligible": "INELIGIBLE ASIN",
            "listing": "Listing Issue", "inventory": "Inventory"},
    ads_sheets=("ads_camp",),
    exports=("SSO US Data Extraction Daily -- raw_sso_us.xlsx", "SSO AMZ Ads by Campaign -- ads_camp.xlsx",
             "Ineligible adgroup -- INELIGIBLE ASIN.xlsx", "US Keepa Raw Auto.xlsx", "USA Inventory Y4A-AMZ.xlsx",
             "SSO USA AMS Converted Cross Sale Report -- usa.xlsx"),  # cross-sale / halo (optional), USA only
    hourly_file="usa_amz_sso_hourly -- usa.xlsx",
    data_file="SSO US_Raw Data_All source.xlsx",
    guide=("Dữ liệu ngày: SSO US Data Extraction Daily -- raw_sso_us",
           "Ads: SSO AMZ Ads by Campaign -- ads_camp",
           "Ineligible adgroup -- INELIGIBLE ASIN · US Keepa Raw Auto · USA Inventory Y4A-AMZ",
           "Hourly: usa_amz_sso_hourly -- usa",
           "File Data (Product Info, KPI, Summary): SSO US_Raw Data_All source",
           "Tùy chọn – Cross-sale · halo: SSO USA AMS Converted Cross Sale Report -- usa"),
)

SFO = Layout(
    team="sfo", name="SFO",
    sheets={"raw": "raw_prime", "products": "Product_info", "kpi": "KPI", "ineligible": "INELIGIBLE ASIN",
            "listing": "Listing Issue", "inventory": "Inventory"},
    ads_sheets=("AMZ", "AMZ_Ads Raw"),
    exports=("Raw Data daily SFO Prime -- raw_prime.xlsx", "SFO AMZ ADS by Campaign -- AMZ.xlsx",
             "Ineligible adgroup -- INELIGIBLE ASIN.xlsx", "USA Inventory Y4A-AMZ.xlsx"),
    hourly_file="usa_amz_sfo_hourly -- USA.xlsx",
    kpi_header_row=2, keepa=False, all_accounts=True, kpi_by_sku=True, ads_export_wins=True,
    data_file="SFO_All_RawData.xlsx",
    guide=("Dữ liệu ngày: Raw Data daily SFO Prime -- raw_prime",
           "Ads: SFO AMZ ADS by Campaign -- AMZ (mọi tài khoản Ads của SFO)",
           "Ineligible adgroup -- INELIGIBLE ASIN · USA Inventory Y4A-AMZ (dùng chung với SSO; SFO không dùng Keepa)",
           "Hourly: usa_amz_sfo_hourly -- USA",
           "File Data (Product_info, KPI, Summary): SFO_All_RawData",
           "Tùy chọn – Converted product (cross-sale · halo): file chung của mọi nhóm, app chỉ lấy dòng department SFO, USD"),
)

LAYOUTS = {"sso": SSO, "sfo": SFO}


def layout_of(team: str | None) -> Layout:
    """A team's layout; a team without its own (or none) uses SSO's, as before teams."""
    return LAYOUTS.get(team or "", SSO)
