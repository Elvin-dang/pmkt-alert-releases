"""Robust xlsx / csv reading. Workbooks are read with calamine (Rust; ~7× faster than openpyxl on the big Data
workbook and exports), which reads the cells themselves, not the files' (often wrong) <dimension> tags; values come back
as openpyxl gave them (blank → None, whole numbers → int, dates → datetime). Inside `session()` each sheet is loaded
once – finding which file is which, then loading them, read the same sheets. A .csv is one table (no sheets):
separator (, ; tab) and encoding (UTF-8 with or without BOM, else Windows-1258) are detected."""
import contextlib
import csv
import functools
import threading
from datetime import date, datetime
from pathlib import Path

import pandas as pd
from openpyxl.utils import get_column_letter
from python_calamine import CalamineWorkbook


def is_csv(path: Path) -> bool:
    return Path(path).suffix.lower() == ".csv"


def _decode(raw: bytes) -> tuple[str, str]:
    """(text, encoding): UTF-8 with or without BOM, else Windows-1258, else Latin-1."""
    for enc in ("utf-8-sig", "cp1258", "latin-1"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", errors="replace"), "latin-1"


def _sniff(sample: str) -> str:
    try:
        return csv.Sniffer().sniff(sample, delimiters=",;\t").delimiter
    except csv.Error:
        return ","


def _head(path: Path) -> tuple[str, str]:
    """(text, encoding) of the first 64 KB, cut at the last line break so a split UTF-8 character can't break the decode."""
    with open(path, "rb") as fh:
        head = fh.read(65536)
    return _decode(head.rsplit(b"\n", 1)[0] if b"\n" in head else head)


def csv_header(path: Path) -> list[str]:
    """The header row only – without reading a big export (100+ MB) through."""
    text, _ = _head(path)
    row = next(csv.reader(text.splitlines()[:1], delimiter=_sniff(text[:8192])), [])
    return [h.strip() or f"col{i}" for i, h in enumerate(row)]


def csv_format(path: Path) -> tuple[str, str]:
    """(encoding, separator) of a CSV, judged on its first 64 KB – for a fast pandas read of a big export."""
    text, enc = _head(path)
    return enc, _sniff(text[:8192])


def _read_csv(path: Path) -> tuple[list[str], list[tuple[int, tuple]]]:
    text, _ = _decode(Path(path).read_bytes())
    sep = _sniff(text[:8192])
    rows = list(csv.reader(text.splitlines(), delimiter=sep))
    if not rows:
        return [], []
    header = [h.strip() or f"col{i}" for i, h in enumerate(rows[0])]
    body = [(n, tuple(v if v != "" else None for v in r)) for n, r in enumerate(rows[1:], 2) if any(x.strip() for x in r)]
    width = len(header)
    return header, [(n, r[:width] + (None,) * (width - len(r))) for n, r in body]


def _key(path: Path) -> tuple[str, int, int]:
    st = Path(path).stat()
    return str(Path(path).resolve()), st.st_mtime_ns, st.st_size


def sheet_names(path: Path) -> list[str]:
    if is_csv(path):
        return []
    return list(_sheet_names(*_key(path)))  # asked ~20× per load


@functools.lru_cache(maxsize=32)
def _sheet_names(path: str, mtime_ns: int, size: int) -> tuple[str, ...]:
    wb = CalamineWorkbook.from_path(path)
    try:
        return tuple(wb.sheet_names)
    finally:
        wb.close()


_local = threading.local()  # the sheets loaded in this thread's session (a run, or one detect)


@contextlib.contextmanager
def session():
    """Within: every sheet is loaded from disk once (sessions nest; the outer one keeps them). After: freed."""
    outer = getattr(_local, "sheets", None) is not None
    if not outer:
        _local.sheets = {}
    try:
        yield
    finally:
        if not outer:
            _local.sheets = None


def _sheet(path: Path, sheet: str | None):
    """The loaded sheet (None = the first one). Loading is the cost (~1.5 s for 150k rows); reading rows is cheap."""
    key = (*_key(path), sheet)
    cache = getattr(_local, "sheets", None)
    if cache is not None and key in cache:
        return cache[key]
    wb = CalamineWorkbook.from_path(key[0])
    try:
        ws = wb.get_sheet_by_name(sheet) if sheet else wb.get_sheet_by_index(0)
    except Exception as e:  # WorksheetNotFound: KeyError like openpyxl's wb[name]
        raise KeyError(f"Worksheet {sheet} does not exist.") from e
    finally:
        wb.close()
    if cache is not None:
        cache[key] = ws
    return ws


_DATE, _DATETIME = date, datetime


def _cell(v):
    """calamine → openpyxl's value: "" (blank / error cell) → None, 5.0 → 5, date → datetime."""
    t = type(v)
    if t is float:
        return int(v) if v.is_integer() else v
    if t is str:
        return v or None
    if t is _DATE:
        return _DATETIME(v.year, v.month, v.day)
    return v


def rows(path: Path, sheet: str | None = None, first: int = 1, last: int | None = None) -> list[tuple]:
    """The sheet's rows `first`..`last` (Excel row numbers, 1-based; last=None: to the end) as tuples of cell values,
    empty rows included (so position = row number), trailing blank cells dropped like openpyxl."""
    got = _sheet(path, sheet).to_python(skip_empty_area=False, nrows=last)
    out = []
    for r in got[first - 1:]:
        r = tuple(map(_cell, r))
        n = len(r)
        while n and r[n - 1] is None:
            n -= 1
        out.append(r[:n])
    return out


def _read(path: Path, sheet: str | None, header_row: int):
    """(header, [(excel_row, values), ...]) with fully empty rows dropped."""
    if is_csv(path):
        return _read_csv(path)
    got = rows(path, sheet, header_row)
    if not got:
        return [], []
    body = [(header_row + i, r) for i, r in enumerate(got[1:], 1) if any(v is not None and v != "" for v in r)]
    width = max(len(r) for r in [got[0], *(r for _, r in body)])
    head = tuple(got[0]) + (None,) * (width - len(got[0]))
    header = [str(h).strip() if h is not None else f"col{i}" for i, h in enumerate(head)]
    return header, [(n, tuple(r[:width]) + (None,) * (width - len(r))) for n, r in body]


def read_sheet(path: Path, sheet: str | None = None, header_row: int = 1) -> pd.DataFrame:
    header, body = _read(path, sheet, header_row)
    return pd.DataFrame([r for _, r in body], columns=header) if header else pd.DataFrame()


def read_sheet_with_rows(path: Path, sheet: str | None = None, header_row: int = 1) -> tuple[pd.DataFrame, dict]:
    """Like read_sheet plus a `_row` column (Excel row number) and {header: column letter} – for evidence."""
    header, body = _read(path, sheet, header_row)
    if not header:
        return pd.DataFrame(), {}
    df = pd.DataFrame([r for _, r in body], columns=header)
    df["_row"] = [n for n, _ in body]
    return df, {h: get_column_letter(i + 1) for i, h in enumerate(header) if not h.startswith("col")}


def to_num(s: pd.Series) -> pd.Series:
    cleaned = s.map(lambda v: v.replace(",", "") if isinstance(v, str) else v)
    return pd.to_numeric(cleaned, errors="coerce").fillna(0.0).astype(float)
