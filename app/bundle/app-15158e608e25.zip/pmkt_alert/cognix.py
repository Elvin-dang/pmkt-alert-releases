"""Activity Log straight from the Ads tool (ads.yes4all.com / Cognix), so nobody downloads it by hand.

Sign-in: Yes4All Keycloak, the Ads website's own public client. It only accepts https://ads.yes4all.com/ as the
return address, so the login page opens in an app window and the code is read from that window's address once the
login redirects there (authorization code + PKCE); the app then trades it for tokens itself. The refresh token is
kept encrypted (secrets.bin) and renews the 30-minute access token, so a user signs in about once.

Export: export-excel starts a job → download-histories/get-list shows it (status, url) → the url is a plain S3 link.

On/off: the Campaign table turns a campaign, or one ASIN inside it, on or off with the user's own Ads login – the
same calls the website makes, so the Ads tool's permissions and its Activity Log apply as usual."""
import base64
import hashlib
import json
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from .progress import check

AUTH = "https://oauth.yes4all.com/auth/realms/portal/protocol/openid-connect"
CLIENT = "cli-ads"
REDIRECT = "https://ads.yes4all.com/"
API = "https://cognix.yes4all.com/ads/api/external"
API_IDS = {"user-log/export-excel": "API_608af724-07dd-45b7-a0a8-b6ce87a659bd",  # sent by the website per endpoint
           "download-histories/get-list": "API_99a18636-0ce2-4145-b2ce-b48d887b6d68",  # (and per action: pause ≠ enable)
           "campaigns/get-list": "API_2569473b-27eb-4f94-a922-54aa859850bf",
           "campaigns/get-by-id": "API_f3f034f4-f368-4ae1-935e-bcea40e83659",
           "campaigns/PAUSED": "API_353ddbcf-ae6d-40b5-a2b8-d60ab52df5a4",
           "campaigns/ENABLED": "API_a9ef9a4b-db4e-44d0-abec-a249b8fc4ae8",
           "campaigns/budget": "API_0c791751-f824-47b0-9977-3c385526e299",
           "ad-group/get-list": "API_23ee18e8-61cc-46f7-8632-3b2a8bd45654",
           "product-ads/get-list": "API_5da2e75d-aa47-44de-9f6a-baa92cd539b6",
           "product-ads/PAUSED": "API_afdf3306-878b-4dfb-87d0-bf405431d598",
           "product-ads/ENABLED": "API_7de23e4d-b46e-48f0-816b-6dc353a20d2d"}
PAGE = 300  # rows per list call (the website asks for 300 product ads at once)
# The default team's Amazon Ads profile; a team's own profile(s) (Cài đặt → Nhóm) or settings "ads_profile_id" override it.
PROFILE_ID = "3282801524712805"
DAYS = 7  # the range the team exported by hand


class CognixError(Exception):
    pass


def pkce() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(48)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return verifier, challenge


def login_url(state: str, challenge: str) -> str:
    return f"{AUTH}/auth?" + urllib.parse.urlencode({
        "client_id": CLIENT, "redirect_uri": REDIRECT, "response_type": "code", "response_mode": "query",
        "scope": "openid offline_access", "state": state, "code_challenge": challenge, "code_challenge_method": "S256"})


def code_from(url: str | None, state: str) -> str | None:
    """The login window's address after the redirect → the code (only for our own request)."""
    if not url or not url.startswith(REDIRECT):
        return None
    q = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
    if q.get("error"):
        raise CognixError("Đăng nhập Ads bị từ chối: " + q["error"][0])
    return q["code"][0] if q.get("state") == [state] and q.get("code") else None


def email_of(token: str) -> str:
    part = token.split(".")[1]
    return json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4))).get("email", "")


class Cognix:
    def __init__(self, refresh: str, save_refresh, opener=urllib.request.urlopen, clock=time.time, sleep=time.sleep):
        self.refresh, self._save, self._open, self._clock, self._sleep = refresh, save_refresh, opener, clock, sleep
        self._access, self._expires = None, 0.0
        self._tok = threading.Lock()  # ad groups are read in parallel: one renewal at a time

    @classmethod
    def sign_in(cls, code: str, verifier: str, save_refresh, opener=urllib.request.urlopen, **kw) -> "Cognix":
        c = cls("", save_refresh, opener, **kw)
        c._grant({"grant_type": "authorization_code", "code": code, "redirect_uri": REDIRECT, "code_verifier": verifier})
        return c

    def _grant(self, form: dict) -> None:
        req = urllib.request.Request(f"{AUTH}/token", data=urllib.parse.urlencode({"client_id": CLIENT, **form}).encode(),
                                     headers={"Content-Type": "application/x-www-form-urlencoded"}, method="POST")
        try:
            with self._open(req, timeout=30) as r:
                tok = json.load(r)
        except urllib.error.HTTPError as e:
            if e.code in (400, 401):  # refresh token expired / revoked / session ended
                raise CognixError("Phiên đăng nhập Ads đã hết – bấm “Lấy Activity Log từ Ads” để đăng nhập lại") from e
            raise CognixError(f"Không đăng nhập được Ads (HTTP {e.code})") from e
        self._access, self._expires = tok["access_token"], self._clock() + tok.get("expires_in", 300)
        self.refresh = tok["refresh_token"]
        self._save(self.refresh)  # Keycloak may rotate it

    def token(self) -> str:
        with self._tok:
            if not self._access or self._clock() > self._expires - 60:
                self._grant({"grant_type": "refresh_token", "refresh_token": self.refresh})
            return self._access

    def _post(self, path: str, body: dict | None, profile: str, method: str = "POST", ident: str | None = None) -> dict:
        """ident: the API_IDS key when it isn't the path itself (get-by-id/<id>, PUT <thing>/<id>)."""
        req = urllib.request.Request(f"{API}/{path}", data=None if body is None else json.dumps(body).encode(), method=method, headers={
            "Content-Type": "application/json;charset=utf-8", "Accept": "application/json", "Authorization": f"Bearer {self.token()}",
            "api-identifier": API_IDS[ident or path], "aprofileid": profile, "Origin": REDIRECT.rstrip("/"), "Referer": REDIRECT,
            "X-Requested-With": "XMLHttpRequest"})
        try:
            with self._open(req, timeout=60) as r:
                out = json.load(r)
        except urllib.error.HTTPError as e:
            raise CognixError(f"Ads tool trả lỗi HTTP {e.code} ở {path}") from e
        if out.get("status_code", 200) != 200:
            raise CognixError(f"Ads tool trả lỗi ở {path}: {out.get('message') or out.get('code')}")
        return out.get("data") or {}

    def fetch_activity(self, dest: Path, profile: str = PROFILE_ID, today: date | None = None, wait_s: int = 180,
                       cancel=None) -> Path:
        """Export the last DAYS days of the Activity Log, wait for the job, download it into dest/. cancel: a
        threading.Event looked at while waiting and between download chunks (progress.Cancelled once set)."""
        today = today or date.today()
        body = {"filters": [], "fromDate": (today - timedelta(days=DAYS)).isoformat(), "toDate": today.isoformat()}
        started = datetime.now(timezone.utc) - timedelta(seconds=30)  # server clock slack
        check(cancel)
        self._post("user-log/export-excel", body, profile)
        deadline = self._clock() + wait_s
        while True:
            check(cancel)
            jobs = self._post("download-histories/get-list",
                              {"pageSize": 20, "pageIndex": 0, "name": "", "profileID": int(profile)}, profile).get("downloadHistories") or []
            job = next((j for j in jobs if j.get("startDate") == body["fromDate"] and j.get("endDate") == body["toDate"]
                        and _utc(j.get("createdAt")) >= started), None)  # newest first: our job, not an older one
            if job and job.get("status") == "SUCCESS" and job.get("url"):
                break
            if job and any(w in str(job.get("status")).upper() for w in ("FAIL", "ERROR")):  # else: still running
                raise CognixError(f"Export Activity Log lỗi: {job.get('messageError') or job.get('status')}")
            if self._clock() > deadline:
                raise CognixError("Export Activity Log quá lâu – thử lại sau ít phút")
            self._sleep(2)
        dest.mkdir(parents=True, exist_ok=True)
        name = Path(job.get("name") or "Activity Log.xlsx").name  # never a path from the server
        out = dest / (name if name.lower().endswith(".xlsx") else name + ".xlsx")
        part = out.with_name(out.name + ".part")
        try:
            with self._open(urllib.request.Request(job["url"]), timeout=60) as r, open(part, "wb") as w:
                while chunk := r.read(256 * 1024):
                    check(cancel)
                    w.write(chunk)
            check(cancel)
            part.replace(out)
        finally:
            part.unlink(missing_ok=True)  # a stopped / failed download leaves nothing behind
        for old in dest.glob("*.xlsx"):  # keep only the newest export
            if old != out:
                old.unlink(missing_ok=True)
        return out

    # ------------------------------------------------------------- campaign / ASIN on-off (same calls as the website)
    def _pages(self, path: str, body: dict, key: str, profile: str) -> list[dict]:
        rows, page = [], 0
        while True:
            out = self._post(path, {**body, "pageSize": PAGE, "pageIndex": page}, profile)
            rows += out.get(key) or []
            page += 1
            if page >= (out.get("totalPage") or 0) or not out.get(key):
                return rows

    def campaigns(self, profile: str = PROFILE_ID) -> list[dict]:
        """Every campaign of the profile: Amazon id (awsCampaignID, = ads_camp campaign_id), the tool's own id, state."""
        today = date.today().isoformat()
        return self._pages("campaigns/get-list", {"isGetSpend": False, "isGetSpendTotal": False, "filters": [], "name": "",
                                                  "spendFromDate": today, "spendToDate": today, "profileId": int(profile)},
                           "campaigns", profile)

    def set_campaign(self, campaign_id: str, on: bool, profile: str = PROFILE_ID) -> str:
        """Turn one campaign on / off (campaign_id = the tool's id). The website sends the whole campaign back with the new
        state, so it is read fresh first. → the state read back afterwards."""
        cur = self._post(f"campaigns/get-by-id/{campaign_id}", None, profile, "GET", "campaigns/get-by-id")
        want = "ENABLED" if on else "PAUSED"
        if state_of(cur) == "ARCHIVED":
            raise CognixError("Campaign đã archive trên Ads – không bật/tắt được")
        if state_of(cur) != want:
            self._post(f"campaigns/{campaign_id}", {**cur, "state": want}, profile, "PUT", f"campaigns/{want}")
        return state_of(self._post(f"campaigns/get-by-id/{campaign_id}", None, profile, "GET", "campaigns/get-by-id"))

    def set_budget(self, campaign_id: str, amount: float, profile: str = PROFILE_ID) -> dict:
        """Set one campaign's budget (the website's inline budget edit: the whole campaign back with the new budget).
        → budget_of() read back afterwards."""
        amount = round(float(amount), 2)
        if not 1 <= amount <= MAX_BUDGET:
            raise CognixError(f"Budget phải từ $1 đến ${MAX_BUDGET:,}")
        cur = self._post(f"campaigns/get-by-id/{campaign_id}", None, profile, "GET", "campaigns/get-by-id")
        if state_of(cur) == "ARCHIVED":
            raise CognixError("Campaign đã archive trên Ads – không sửa budget được")
        if cur.get("isEditDailyBudget") is False:
            raise CognixError("Ads không cho sửa budget campaign này (có automation / rule quản lý budget?)")
        if float(cur.get("budget") or 0) != amount:
            self._post(f"campaigns/{campaign_id}", {**cur, "budget": amount}, profile, "PUT", "campaigns/budget")
        return budget_of(self._post(f"campaigns/get-by-id/{campaign_id}", None, profile, "GET", "campaigns/get-by-id"))

    def product_ads(self, campaign_id: str, profile: str = PROFILE_ID) -> list[dict]:
        """The campaign's product ads (one per ASIN per ad group). product-ads/get-list ignores campaignID – without an
        adGroupID it lists the whole account – so it goes ad group by ad group."""
        today = date.today().isoformat()
        span = {"isGetSpend": False, "isGetSpendTotal": False, "filters": [], "name": "", "spendFromDate": today,
                "spendToDate": today, "compareStartDate": "", "compareEndDate": ""}
        groups = self._pages("ad-group/get-list", {**span, "campaignID": str(campaign_id)}, "adGroups", profile)
        groups = [g for g in groups if str(g.get("campaignID")) == str(campaign_id)]
        read = lambda g: self._pages("product-ads/get-list", {**span, "adGroupID": str(g["adGroupID"]), "signal": {}},  # noqa: E731
                                     "productAds", profile)
        with ThreadPoolExecutor(6) as pool:  # a test campaign can hold 17 groups × 500 ads
            ads = [a for rows in pool.map(read, groups) for a in rows]
        return [a for a in ads if str(a.get("campaignID")) == str(campaign_id)]

    def ad_stats(self, group_ids: list[str], start: str, end: str, profile: str = PROFILE_ID) -> dict[str, dict]:
        """adID → performanceInfo (spend, sale, order, click, impression…) over start–end, for every ad of the given ad
        groups. The list's name search can't take an ASIN (the tool answers with an SQL error), so whole groups are read."""
        span = {"isGetSpend": True, "isGetSpendTotal": False, "filters": [], "name": "", "spendFromDate": start,
                "spendToDate": end, "compareStartDate": "", "compareEndDate": "", "signal": {}}
        read = lambda g: self._pages("product-ads/get-list", {**span, "adGroupID": str(g)}, "productAds", profile)  # noqa: E731
        with ThreadPoolExecutor(6) as pool:
            return {str(a["adID"]): a.get("performanceInfo") or {} for rows in pool.map(read, sorted(set(group_ids))) for a in rows}

    def set_ads(self, ads: list[dict], on: bool, profile: str = PROFILE_ID) -> int:
        """Turn the given product ads on / off (archived ones are left alone). → how many were changed."""
        want, n = "ENABLED" if on else "PAUSED", 0
        for a in ads:
            if state_of(a) not in (want, "ARCHIVED"):
                self._post(f"product-ads/{a['adID']}", {**a, "state": want}, profile, "PUT", f"product-ads/{want}")
                a["state"], n = want, n + 1
        return n


def merge_activity(logs: list[Path], out: Path) -> Path:
    """One Activity Log workbook from several profiles' exports (same columns): the first file's header, then every
    file's rows. Written to a .part first, so a failed merge leaves the previous workbook in place."""
    from openpyxl import Workbook, load_workbook
    wb = Workbook(write_only=True)
    ws, header = wb.create_sheet("Activity Log"), None
    for f in logs:
        src = load_workbook(f, read_only=True)
        try:
            rows = src.worksheets[0].iter_rows(values_only=True)
            head = next(rows, None)
            if not any(v is not None for v in head or ()):  # a profile with no changes: an empty export
                continue
            if header is None:
                header = head
                ws.append(list(head or ()))
            elif head != header:
                raise CognixError(f"Activity Log của các profile khác cột nhau ({f.parent.name})")
            for r in rows:
                if any(v is not None for v in r):
                    ws.append(list(r))
        finally:
            src.close()
    if header is None:
        raise CognixError("Activity Log của các profile đều trống")
    part = out.with_name(out.name + ".part")
    try:
        wb.save(part)
        part.replace(out)
    finally:
        part.unlink(missing_ok=True)
    return out


def ad_group_url(ad: dict) -> str:
    """The Ads website's page of the ad group holding this product ad (its route: /campaigns/[type]/[campaignId]/
    ad-groups/[adGroupId], with the tool's own ids and type SP / SB / SD)."""
    q = lambda v: urllib.parse.quote(str(v), safe="")  # noqa: E731
    return f"{REDIRECT}campaigns/{q(ad.get('campaignType') or 'SP')}/{q(ad['campaignID'])}/ad-groups/{q(ad['adGroupID'])}"


MAX_BUDGET = 10000  # $ / day: a typo guard well above any campaign's budget


def budget_of(c: dict) -> dict:
    """Budget fields of a campaign row from the tool, for the Campaign table's Budget column."""
    sug = ((c.get("budgetRecommend") or {}).get("suggestedBudget")) or 0
    return {"budget": c.get("budget"), "type": str(c.get("budgetType") or "").title(),
            "editable": c.get("isEditDailyBudget") is not False and state_of(c) != "ARCHIVED", "suggested": sug or None}


def state_of(row: dict) -> str:
    return str(row.get("state") or "").upper()  # the tool returns both "PAUSED" and "paused"


def asin_states(ads: list[dict]) -> dict[str, str]:
    """ASIN → ENABLED (every live ad on) / PAUSED (every live ad off) / MIXED / ARCHIVED, over the campaign's ad groups."""
    by: dict[str, set] = {}
    for a in ads:
        if a.get("asin"):
            by.setdefault(a["asin"], set()).add(state_of(a))
    out = {}
    for asin, s in by.items():
        live = s - {"ARCHIVED"}
        out[asin] = "ARCHIVED" if not live else live.pop() if len(live) == 1 else "MIXED"
    return out


def _utc(s: str | None) -> datetime:
    try:
        return datetime.fromisoformat(str(s).replace("Z", "+00:00"))
    except ValueError:
        return datetime.min.replace(tzinfo=timezone.utc)
