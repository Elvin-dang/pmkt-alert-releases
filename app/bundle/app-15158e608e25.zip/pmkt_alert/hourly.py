"""Hourly tab: hour-to-date performance from the hourly SSO export (usa_amz_sso_hourly -- usa.xlsx, sheet usa).

One row per ASIN per hour (date_time_local = the hour's start). GMV = ordered_nmv + lightning_deal_spend (AB) + best_deal_spend
(AC) + promotion (AD) (feedback #81, found by name), RS = ordered_units,
Ads Spend = SP + SB + SD spend, TACOS = Ads Spend / GMV. Optional traffic (feedback #55): impressions and clicks =
SP + SB + SD, glance views; a column missing from the file only drops that series.
Time gone is counted on 24 hours: the latest data hour H of the last day → (H + 1) / 24 of that day gone.
Filters as on Performance Review and combined with AND: PIC ∧ Sales Leader ∧ Product line ∧ SKU, plus the date range
(within the hourly file's days). Targets are the KPI month targets spread per day with the Summary %Contribution
(GMV & RS: GMV row; spend: PPC row), else evenly. The full-month tables ignore the date range: actuals are raw_sso_us
(daily) for the days before the last hourly day that it covers, plus the hourly file for the rest (always the last day)."""
import calendar
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

from .loaders import InputError
from .xlsx import read_sheet, rows, sheet_names
from .performance import _div, _iso, _many, _product_names, _scope, change_drivers, ineligible_fn, sku_stock_fn

FILE_NAME = "usa_amz_sso_hourly -- usa.xlsx"  # SSO's; each team's own: layouts.Layout.hourly_file
SHEET = "usa"
NEED = ("date_time_local", "product_id", "ordered_nmv", "ordered_units", "sp_spend")
SPEND = ("sp_spend", "sb_spend", "sd_spend")
METRICS = ("gmv", "rs", "spend")
# feedback #55: optional traffic columns, first name found wins (the real export's names are guessed from sp_spend / glance_view)
# feedback #81: deal amounts added to GMV with the promotion (AD); a column missing from the file adds nothing
DEALS = ("lightning_deal_spend", "best_deal_spend")  # columns AB, AC
TRAFFIC = {"impressions": [(f"{p}_impressions", f"{p}_impression") for p in ("sp", "sb", "sd")],
           "clicks": [(f"{p}_clicks", f"{p}_click") for p in ("sp", "sb", "sd")],
           "glance_views": [("glance_view", "glance_views")]}


def _promo_col(cols: list[str]) -> str | None:
    """feedback #81: the promotion amount (column AD of the export); column AD if its name says promo, else the first such."""
    promo = [c for c in cols if "promo" in str(c).lower()]
    return cols[29] if len(cols) > 29 and cols[29] in promo else next(iter(promo), None)


def _sheet_of(path: Path) -> str:
    names = sheet_names(path)
    return next((n for n in names if n.lower() == SHEET), names[0])  # SSO: usa, SFO: USA


def _head(path: Path) -> tuple[str, list[str]]:
    sheet = _sheet_of(path)
    got = rows(path, sheet, 1, 1)
    return sheet, [str(h).strip() for h in (got[0] if got else ()) if h is not None]


def is_hourly(path: Path) -> bool:
    try:
        return path.suffix.lower() == ".xlsx" and set(NEED) <= set(_head(path)[1])
    except Exception:
        return False


def load_hourly(path: Path) -> pd.DataFrame:
    """→ one row per (date, hour, asin): gmv, rs, spend + the TRAFFIC metrics the file has."""
    df = read_sheet(path, _sheet_of(path))
    missing = [c for c in NEED if c not in df.columns]
    if missing:
        raise InputError(f"File hourly thiếu cột: {', '.join(missing)}", {"file": path.name, "sheet": SHEET, "columns": missing})
    num = lambda c: pd.to_numeric(df[c], errors="coerce").fillna(0.0) if c in df.columns else 0.0  # noqa: E731
    promo = _promo_col(list(df.columns))
    dt = pd.to_datetime(df["date_time_local"], errors="coerce").dt.floor("h")
    out = pd.DataFrame({"dt": dt, "asin": df["product_id"].astype(str).str.strip(), "gmv": num("ordered_nmv") + sum(num(c) for c in DEALS) + (num(promo) if promo else 0.0),
                        "rs": num("ordered_units"), "spend": sum(num(c) for c in SPEND)})
    for k, groups in TRAFFIC.items():
        cols = [next(c for c in g if c in df.columns) for g in groups if any(c in df.columns for c in g)]
        if cols:
            out[k] = sum(num(c) for c in cols)
    out = out[out["dt"].notna()]
    out = out.assign(date=out["dt"].dt.date, hour=out["dt"].dt.hour.astype(int))
    return out.groupby(["date", "hour", "asin"], as_index=False)[[*METRICS, *(k for k in TRAFFIC if k in out.columns)]].sum()


def _m(v: dict | None) -> dict:
    v = v or {}
    g, s = float(v.get("gmv", 0.0)), float(v.get("spend", 0.0))
    return {"gmv": g, "rs": float(v.get("rs", 0.0)), "spend": s, "tacos": _div(s, g)}


def _tav(tgt: dict, act: dict) -> dict:
    t, a = _m(tgt), _m(act)
    return {"target": t, "actual": a, "achieve": {k: _div(a[k], t[k]) for k in ("gmv", "rs", "spend", "tacos")}}


def _hr_scope(inputs, rj: dict, team_label: str, day: date, pic: list, leader: list, pl: list, sku: list):
    """(scope: asin / sku / pl / pic of team ∧ PIC ∧ Sales Leader ∧ Product line ∧ SKU, PIC options, leader options,
    PL options, SKU options) – Performance Review's scope (performance._scope) + the SKU filter; shared by the tab and
    its change drivers (feedback #84)."""
    team, amap, pics, leaders = _scope(inputs, rj, team_label, day, pic, leader, pl)
    sku_opts = [[a, f"{s} ({a})"] for a, s in sorted(zip(amap["asin"], amap["sku"]), key=lambda x: str(x[1]))]
    if sku:
        amap = amap[amap["asin"].isin(sku)]
    return amap[["asin", "sku", "pl", "pic"]], pics, leaders, sorted(set(team["pl"])), sku_opts


def _last(hr: pd.DataFrame) -> tuple[date, int]:  # the latest data day and hour of the hourly frame
    last = hr[["date", "hour"]].sort_values(["date", "hour"]).iloc[-1]
    return last["date"], int(last["hour"])


def hourly_drivers(inputs, hr: pd.DataFrame, rj: dict, team_label: str = "", pic=None, leader=None, pl=None, sku=None,
                   day: str | None = None) -> dict:
    """feedback #84: Performance Review's change drivers (performance.change_drivers) on the hourly file – the day (default:
    the latest) vs the day before, same filters as the tab. The latest day is partial (data up to hour H), so it is compared
    hour-to-date: both days cut at hour H (hour = H; None = full days). partial = the day before is not in the file."""
    if hr is None or not len(hr):
        raise ValueError("File hourly chưa có dữ liệu")
    last_day, last_hour = _last(hr)
    dmin = hr["date"].min()
    d = min(max(date.fromisoformat(day), dmin), last_day) if day else last_day
    prev = d - timedelta(days=1)
    scope, *_ = _hr_scope(inputs, rj, team_label, last_day, _many(pic), _many(leader), _many(pl), _many(sku))
    cut = last_hour if d == last_day and last_hour < 23 else None
    r = hr[(hr["date"] >= prev) & (hr["date"] <= d) & ((hr["hour"] <= cut) if cut is not None else True)]
    r = r.merge(scope[["asin", "pl"]], on="asin").rename(columns={"rs": "units"})
    out = change_drivers(r, (d, d), (prev, prev), dict(zip(scope["asin"], scope["sku"])), _product_names(inputs.products))
    return {**out, "day": _iso(d), "period": "day", "hour": cut, "partial": prev < dmin}


def hourly(inputs, hr: pd.DataFrame, rj: dict, team_label: str = "", pic=None, leader=None, pl=None, sku=None,
           start: str | None = None, end: str | None = None) -> dict:
    if hr is None or not len(hr):
        raise ValueError("File hourly chưa có dữ liệu")
    last_day, last_hour = _last(hr)
    dmin = hr["date"].min()
    clamp = lambda d: min(max(d, dmin), last_day)  # noqa: E731
    end_d = clamp(date.fromisoformat(end)) if end else last_day
    start_d = min(clamp(date.fromisoformat(start)) if start else end_d, end_d)

    pic, leader, pl, sku = _many(pic), _many(leader), _many(pl), _many(sku)
    scope, pics, leaders, pls_all, sku_opts = _hr_scope(inputs, rj, team_label, last_day, pic, leader, pl, sku)

    # ---- hour-of-day matrices over the date range (several days: each hour summed over them)
    h = hr[(hr["date"] >= start_d) & (hr["date"] <= end_d)].merge(scope, on="asin")

    def matrix(by: str, extra=None) -> list[dict]:
        cells = h.groupby([by, "hour"])[list(METRICS)].sum().to_dict("index")
        rows = []
        for key, tot in h.groupby(by)[list(METRICS)].sum().to_dict("index").items():
            rows.append({by: key, **(extra(key) if extra else {}), "total": _m(tot),
                         "hours": [_m(cells[(key, x)]) if (key, x) in cells else None for x in range(24)]})
        return sorted(rows, key=lambda r: -r["total"]["gmv"])

    sku_of, name_of = dict(zip(scope["asin"], scope["sku"])), _product_names(inputs.products)  # feedback #78: Product name
    by_hour = h.groupby("hour")[list(METRICS)].sum().to_dict("index")
    total = {"total": _m(h[list(METRICS)].sum().to_dict()), "hours": [_m(by_hour[x]) if x in by_hour else None for x in range(24)]}
    # feedback #43: the same hours over the period just before (as many days), for the comparison chart
    n = (end_d - start_d).days + 1
    p0, p1 = start_d - timedelta(days=n), start_d - timedelta(days=1)
    hp = hr[(hr["date"] >= p0) & (hr["date"] <= p1)].merge(scope, on="asin")
    by_prev = hp.groupby("hour")[list(METRICS)].sum().to_dict("index")
    # feedback #55: impressions (bars) · glance views · clicks per hour; missing = series the file has no column for
    tk = [k for k in TRAFFIC if k in h.columns]
    by_tr = h.groupby("hour")[tk].sum().to_dict("index") if tk else {}
    traffic = {"hours": [by_tr.get(x) for x in range(24)],
               "missing": [k for k in TRAFFIC if k not in tk], "columns": {k: [g[0] for g in TRAFFIC[k]] for k in TRAFFIC}}
    prev = {"start": _iso(p0), "end": _iso(p1), "hours": [_m(by_prev[x]) if x in by_prev else None for x in range(24)]} if by_prev else None
    # feedback #85: CPC = Σ Ads Spend / Σ clicks per hour (never an average of ratios; 0 clicks → None), this period vs the
    # one just before as above (default: today vs yesterday); totals over the hours with data so far (hour-to-date on the last day)
    upto = last_hour if end_d == last_day else 23

    def cpc(f: pd.DataFrame) -> dict:
        by = f.groupby("hour")[["spend", "clicks"]].sum().to_dict("index")
        cell = lambda v: {"spend": float(v["spend"]), "clicks": float(v["clicks"]), "cpc": _div(float(v["spend"]), float(v["clicks"]))}  # noqa: E731
        t = f[f["hour"] <= upto][["spend", "clicks"]].sum()
        return {"hours": [cell(by[x]) if x in by else None for x in range(24)], "total": cell(t)}

    cpc_h = {"missing": True} if "clicks" not in hr.columns else {
        "missing": False, "upto": upto, **cpc(h), "prev": cpc(hp) if by_prev else None}

    # ---- targets: KPI month × day share; time gone on 24 h
    contrib = inputs.contrib or {}
    kpi = inputs.kpi[inputs.kpi["asin"].isin(set(scope["asin"]))]

    def share(d: date, k: str) -> float:
        c = contrib.get(d)
        return c[k] if c else 1 / calendar.monthrange(d.year, d.month)[1]

    def day_gone(d: date) -> float:
        return 1.0 if d < last_day else (last_hour + 1) / 24 if d == last_day else 0.0

    def targets(days: list[date]) -> pd.DataFrame:  # per ASIN: gmv, rs, spend for these days
        parts = []
        for month in sorted({d.month for d in days}):
            md = [d for d in days if d.month == month]
            wg, wp = sum(share(d, "gmv") for d in md), sum(share(d, "ppc") for d in md)
            k = kpi[kpi["month"] == month].groupby("asin")[["gmv", "rs", "spend"]].sum()
            parts.append(pd.DataFrame({"gmv": k["gmv"] * wg, "rs": k["rs"] * wg, "spend": k["spend"] * wp}))
        return pd.concat(parts).groupby(level=0).sum() if parts else pd.DataFrame(columns=["gmv", "rs", "spend"])

    def tables(tgt: pd.DataFrame, act: pd.DataFrame) -> dict:
        t_a, a_a = tgt.to_dict("index"), act.groupby("asin")[list(METRICS)].sum().to_dict("index")
        skus = [{"sku": s, "asin": a, "pl": p, "product": name_of.get(a, ""), **_tav(t_a.get(a), a_a.get(a))}
                for a, s, p in sorted(zip(scope["asin"], scope["sku"], scope["pl"]), key=lambda x: (x[2], str(x[1])))]
        t_p = tgt.join(scope.set_index("asin")["pl"]).groupby("pl")[["gmv", "rs", "spend"]].sum().to_dict("index") if len(tgt) else {}
        a_p = act.merge(scope[["asin", "pl"]], on="asin").groupby("pl")[list(METRICS)].sum().to_dict("index") if len(act) else {}
        pls = [{"pl": p, **_tav(t_p.get(p), a_p.get(p))} for p in sorted(set(scope["pl"]))]
        tot = _tav(tgt[["gmv", "rs", "spend"]].sum().to_dict() if len(tgt) else {}, act[list(METRICS)].sum().to_dict() if len(act) else {})
        return {"skus": skus, "pls": pls, "total": tot}

    days = [start_d + timedelta(days=i) for i in range((end_d - start_d).days + 1)]
    rng = tables(targets(days), h[["asin", *METRICS]])
    gone_range = sum(day_gone(d) for d in days) / len(days)

    # ---- full month of the last data day: raw_sso_us (daily) where it has the day, the hourly file after it
    m0 = last_day.replace(day=1)
    dim = calendar.monthrange(last_day.year, last_day.month)[1]
    raw = inputs.raw
    # The last hourly day (today, hour-to-date) always comes from the hourly file – raw_sso_us may hold a partial copy.
    raw_m = raw[(raw["date"] >= m0) & (raw["date"] < last_day) & raw["asin"].isin(set(scope["asin"]))]
    raw_last = raw_m["date"].max() if len(raw_m) else None
    hr_m = hr[(hr["date"] >= m0) & (hr["date"] <= last_day) & hr["asin"].isin(set(scope["asin"]))]
    if raw_last is not None:
        hr_m = hr_m[hr_m["date"] > raw_last]
    act_m = pd.concat([raw_m.assign(rs=raw_m["units"])[["asin", *METRICS]], hr_m[["asin", *METRICS]]], ignore_index=True)
    month_days = [m0 + timedelta(days=i) for i in range(dim)]
    mon = tables(targets(month_days), act_m)
    # feedback #39: as on Performance Review; the ineligible status is judged up to its last log (today's may not exist yet)
    logs = [d for d in inputs.ineligible["date"].dropna() if m0 <= d <= last_day] if len(inputs.ineligible) else []
    stock, inelig = sku_stock_fn(inputs, last_day.month), ineligible_fn(inputs, m0, max(logs, default=last_day))
    for r in mon["skus"]:
        r["stock"], r["ineligible"] = stock(r["asin"], r["sku"]), inelig(r["asin"])
    gone_month = sum(day_gone(d) for d in month_days) / dim

    return {"filters": {"pic": pic, "leader": leader, "pl": pl, "sku": sku, "pics": pics, "leaders": leaders,
                        "pls": pls_all, "skus": sku_opts, "start": _iso(start_d), "end": _iso(end_d),
                        "min": _iso(dmin), "max": _iso(last_day)},
            "last": {"date": _iso(last_day), "hour": last_hour},
            "gone_day": (last_hour + 1) / 24, "gone_range": gone_range, "gone_month": gone_month,
            "month": m0.strftime("%m/%Y"), "raw_last": _iso(raw_last),
            "sku_hours": matrix("asin", lambda a: {"sku": sku_of.get(a, a), "product": name_of.get(a, "")}),
            "pl_hours": matrix("pl"), "pic_hours": matrix("pic"), "total_hours": total, "prev_hours": prev,
            "traffic_hours": traffic, "cpc_hours": cpc_h, "range": rng, "month_tbl": mon}
