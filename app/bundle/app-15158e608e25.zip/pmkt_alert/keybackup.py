"""Server-side backup of a person's device keys, locked with their app password, so signing in on another computer
brings the keys along (no key file to carry).

The server only ever holds the locked copy: AES-256-GCM with a key derived from the password by scrypt (n = 2^17 –
costly on purpose, the copy sits in the team database), bound to the account's email. Without the password it is
noise; a database leak leaves offline guessing, which a random Lead-generated or 10+ character password resists.
A Lead resetting someone's password makes their copy unreadable: their next sign-in on a computer that still has
the keys locks them again with the new password."""
import base64
import json
import os

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

VERSION = 1
N, R, P = 2 ** 17, 8, 1


def _key(password: str, salt: bytes, n: int, r: int, p: int) -> bytes:
    return Scrypt(salt=salt, length=32, n=n, r=r, p=p).derive(password.encode("utf-8"))


def _aad(email: str) -> bytes:
    return f"pmkt-key-backup:v{VERSION}:{email.strip().lower()}".encode()


def lock(keys: dict, password: str, email: str) -> str:
    """keys ({"lead": b64, "member": b64}) → the text stored on the server."""
    salt, nonce = os.urandom(16), os.urandom(12)
    ct = AESGCM(_key(password, salt, N, R, P)).encrypt(nonce, json.dumps(keys, sort_keys=True).encode(), _aad(email))
    b64 = lambda b: base64.b64encode(b).decode()  # noqa: E731
    return json.dumps({"v": VERSION, "kdf": "scrypt", "n": N, "r": R, "p": P, "salt": b64(salt), "nonce": b64(nonce), "ct": b64(ct)})


def unlock(blob: str | None, password: str, email: str) -> dict | None:
    """The keys, or None: no backup, another format, a wrong / changed password or another account's copy."""
    try:
        d = json.loads(blob or "")
        if d.get("v") != VERSION or d.get("kdf") != "scrypt" or not (2 ** 14 <= int(d["n"]) <= 2 ** 20):
            return None
        raw = AESGCM(_key(password, base64.b64decode(d["salt"]), int(d["n"]), int(d["r"]), int(d["p"]))).decrypt(
            base64.b64decode(d["nonce"]), base64.b64decode(d["ct"]), _aad(email))
        keys = json.loads(raw)
        return {k: v for k, v in keys.items() if k in ("lead", "member") and isinstance(v, str)} or None
    except Exception:
        return None
