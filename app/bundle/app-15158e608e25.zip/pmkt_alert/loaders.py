"""Detect the input workbooks by content and load them into normalized frames.
v4: one Data workbook (raw_sso_us, Product Info, KPI, INELIGIBLE ASIN, ads_camp, Summary, Listing Issue) + Activity
Log + Logic. Older sets (separate tracker / ads files, CSV tables, Defind) still load."""
import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd

from .layouts import LAYOUTS, SSO, Layout
from .progress import check
from .xlsx import csv_format, csv_header, is_csv, read_sheet, read_sheet_with_rows, sheet_names, to_num
from .xlsx import rows as xlsx_rows

ROLES = ("tracker", "ads", "activity", "logic")
OPTIONAL_ROLES = ("defind",)
# Optional inputs that feed a page: the newest file wins when several are found.
EXTRA_ROLES = ("converted",)
# Converted product export (Amazon Ads "purchased product" report): the columns read. SSO's SharePoint report
# (SSO USA AMS Converted Cross Sale Report -- usa.xlsx) is USA only; the older all-market CSV keeps only its USD rows.
CONVERTED = ("report_date", "campaign_id", "advertised_product_id", "converted_product_id", "sales", "units_sold")
CONVERTED_OPTIONAL = ("department", "budget_currency")  # department SSO / SFO / blank: see team_converted
# The tracker workbook's tables; each may instead come as its own CSV.
TRACKER_SHEETS = {"raw": "raw_sso_us", "products": "Product Info", "kpi": "KPI", "ineligible": "INELIGIBLE ASIN",
                  "listing": "Listing Issue", "inventory": "Inventory"}
# The same table as its own SharePoint export (synced by OneDrive) sits on a differently named sheet.
EXPORT_SHEETS = {"listing": "Data", "inventory": "report"}  # USA Inventory Y4A-AMZ.xlsx › report
STOCK = ("SKU", "INV Y4A AMZ", "INV Y4A", "INV AMZ")  # Inventory: total (= Y4A + AMZ), and the two parts
# Data older than this many days before the as-of day (today) is stale. Measured: a refresh on the evening of 05/11
# had raw / INELIGIBLE / Y4A stock / Keepa up to 05/11, ads_camp 04/11, Amazon stock 03/11 – one day of slack each.
MAX_LAG_DAYS = {"raw": 2, "ads": 2, "ineligible": 2, "inv_y4a": 1, "inv_amz": 3, "listing": 2}
LABELS = {"ads": "ads_camp", "inv_y4a": "Inventory (INV Y4A)", "inv_amz": "Inventory (INV AMZ)"}
KEEPA = ("ASIN", "Buy Box: Current", "Buy Box: 30 days avg.", "Availability of the Amazon offer")
TRACKER_REQUIRED = ("raw", "products", "kpi")
CSV_COLUMNS = {  # a CSV's table is recognised by these header columns
    "raw": {"report_date", "asin", "sp_spend"}, "products": {"asin", "product_line_old", "status"},
    "kpi": {"Month", "ASIN", "Spend_final"}, "ineligible": {"asin", "delivery_status"},
    "ads": {"campaign_id", "spend_usd", "account_name"}, "activity": {"Level", "username"}, "defind": {"Tên File"},
    "converted": {"converted_product_id", "advertised_product_id", "sales", "units_sold"},
}
ROLE_HINT = {
    "tracker": "file Data: cần sheet raw_sso_us, Product Info, KPI, ads_camp",
    "ads": "sheet ads_camp (trong file Data)",
    "activity": "file Activity Log: cần cột Level, username",
    "logic": "file Logic: cần sheet Config, Matrix_Product Line",
    "defind": "file Defind: cần cột Tên File",
    "converted": "file Converted product: cần cột converted_product_id, advertised_product_id, sales, units_sold",
}
BLANK = {"#N/A", "0", "0.0", "None", "nan"}


class InputError(Exception):
    """A structural problem the user must fix before a run can work. `location` points at it:
    {"file", "sheet", "columns" | "cell", "row"}."""

    def __init__(self, message: str, location: dict | None = None):
        super().__init__(message)
        self.location = location


@dataclass
class Inputs:
    raw: pd.DataFrame
    products: pd.DataFrame
    kpi: pd.DataFrame
    ineligible: pd.DataFrame
    ads: pd.DataFrame
    activity: pd.DataFrame
    event_days: dict[date, str] = field(default_factory=dict)
    defind_text: str = ""
    sources: dict = field(default_factory=dict)  # name → {"file", "sheet", "letters"} for evidence
    inventory: pd.DataFrame = field(default_factory=lambda: pd.DataFrame(columns=["date", "asin", "sku", "stock"]))
    contrib: dict = field(default_factory=dict)  # date → {"gmv", "ppc"} share of the month (Summary sheet)
    latest: dict = field(default_factory=dict)  # table → (file name, latest date in it) for the staleness check
    incoming: dict = field(default_factory=dict)  # SKU key → nearest arrival {"qty", "window", "arrival"} (_incoming)
    keepa: dict = field(default_factory=dict)  # asin → today's Keepa values (_keepa_values); undated like Listing Issue
    # Converted product export, USD rows: date, campaign_id, adv (advertised ASIN), conv (converted ASIN), sales, units.
    # None = no file given (the cross-sale / halo columns stay hidden).
    converted: pd.DataFrame | None = None


def _first_row(path: Path, sheet: str | None = None, row: int = 1) -> list[str]:
    if is_csv(path):
        return csv_header(path)
    got = xlsx_rows(path, sheet, row, row)
    return [str(v).strip() for v in (got[0] if got else ()) if v is not None]


def role_of(path: Path, layout: Layout = SSO) -> str | None:
    """Workbook → tracker / ads / logic / activity / defind; CSV → its table (raw, products, kpi, ineligible, ads…).
    By the team's layout: another team's Data workbook or exports are not recognised (None)."""
    if is_csv(path):
        head = set(_first_row(path))
        return next((t for t, cols in CSV_COLUMNS.items() if cols <= head), None)
    sheets, sh = set(sheet_names(path)), layout.sheets
    if {sh["raw"], sh["products"], sh["kpi"]} <= sheets:
        return "tracker"
    if sheets & set(layout.ads_sheets):
        return "ads"
    if any(other.sheets["raw"] in sheets for other in LAYOUTS.values() if other.sheets["raw"] != sh["raw"]):
        return None  # another team's Data workbook / export (its INELIGIBLE ASIN sheet is not this team's)
    for table in ("raw", "ineligible"):  # one table per workbook: the SharePoint exports
        if sh[table] in sheets:
            return table
    if "report" in sheets and _header_row(path, "report", STOCK[:2]):  # USA Inventory Y4A-AMZ
        return "inventory"
    if layout.keepa and "Data" in sheets and set(KEEPA) <= set(_first_row(path, "Data", 2)):  # Keepa (header on row 2)
        return "listing"
    if "Config" in sheets and any(n.startswith("Matrix") for n in sheets):
        return "logic"
    head = _first_row(path)
    if "Level" in head and "username" in head:
        return "activity"
    if "Tên File" in head:
        return "defind"
    if CSV_COLUMNS["converted"] <= set(head):
        return "converted"
    return None


def input_files(paths: list[Path]) -> list[Path]:
    files: list[Path] = []
    for p in map(Path, paths):
        files += sorted([*p.glob("*.xlsx"), *p.glob("*.csv")]) if p.is_dir() else [p]
    seen, out = set(), []
    for f in files:  # the same file picked twice (e.g. via two slots) is one file
        key = f.resolve()
        if key not in seen and not f.name.startswith("~$"):
            seen.add(key)
            out.append(f)
    return out


def ads_sheet_of(path: Path, layout: Layout = SSO) -> str | None:
    """The Ads by Campaign sheet of a workbook (the export's, else the Data workbook's copy); None if it has none."""
    sheets = sheet_names(path)
    return next((n for n in layout.ads_sheets if n in sheets), None)


def detect_inputs(paths: list[Path], layout: Layout = SSO) -> dict[str, Path]:
    """role/table → file. The tracker is one workbook, or its tables as CSVs (raw, products, kpi[, ineligible]);
    a CSV table also overrides the matching sheet of a tracker workbook."""
    files = input_files(paths)
    found: dict[str, list[Path]] = {}
    for f in files:
        try:
            role = role_of(f, layout)
        except Exception:
            continue
        if role:
            found.setdefault(role, []).append(f)
    for role in ("activity", *EXTRA_ROLES):  # daily exports pile up in Downloads: use the newest
        if len(found.get(role, [])) > 1:
            found[role] = [max(found[role], key=lambda f: f.stat().st_mtime)]
    export = max(found.get("ads", []), key=lambda f: f.stat().st_mtime, default=None)  # SSO AMZ Ads by Campaign
    if len(found.get("tracker", [])) == 1 and ads_sheet_of(found["tracker"][0], layout):
        found["ads"] = [export if layout.ads_export_wins and export is not None
                        else newer_ads(found["tracker"][0], found.get("ads", []))]
    if "tracker" not in found and any(t in found for t in TRACKER_SHEETS):
        missing = [layout.sheets[t] for t in TRACKER_REQUIRED if t not in found]
        if missing:
            raise InputError("Thiếu file Tracking dạng CSV: " + ", ".join(missing)
                             + f" (hoặc dùng 1 file .xlsx có các sheet {', '.join(layout.sheets[t] for t in TRACKER_REQUIRED)})")
    needed = [r for r in ROLES if not (r == "tracker" and all(t in found for t in TRACKER_REQUIRED))]
    for role in needed + [t for t in TRACKER_SHEETS if t in found]:
        hint = role_hint(role, layout)
        if role not in found:
            raise InputError(f"Thiếu {hint}")
        if len(found[role]) > 1:
            name = hint.split(':')[0] if role in ROLE_HINT else f"file {layout.sheets[role]}"
            raise InputError(f"Có nhiều hơn một {name}: " + ", ".join(f.name for f in found[role]))
    out = {role: files_[0] for role, files_ in found.items()
           if role in needed or role in TRACKER_SHEETS or role in EXTRA_ROLES or (role in OPTIONAL_ROLES and len(files_) == 1)}
    if export is not None and out.get("ads") != export:  # the Data workbook's ads_camp won: still name campaigns
        out["ads_names"] = export
    return out


def role_hint(role: str, layout: Layout = SSO) -> str:
    """ROLE_HINT in the team's sheet names."""
    sh = layout.sheets
    if role == "tracker":
        return f"file Data: cần sheet {sh['raw']}, {sh['products']}, {sh['kpi']}, {layout.ads_sheets[-1]}"
    if role == "ads":
        return f"sheet {layout.ads_sheets[-1]} (trong file Data) hoặc file Ads by Campaign"
    return ROLE_HINT.get(role, f"file {sh.get(role, role)}")


def newer_ads(tracker: Path, ads: list[Path]) -> Path:
    """The Data workbook carries ads_camp. A separate ads_camp file replaces it only when newer on disk – a
    OneDrive-synced SharePoint export is; an old Ads file left in Downloads is not."""
    newest = max(ads, key=lambda f: f.stat().st_mtime, default=None)
    return newest if newest and newest.stat().st_mtime > tracker.stat().st_mtime else tracker


def _text_dates(s: pd.Series) -> pd.Series:
    """Date text from CSVs, vectorised: ISO, or d/m/y vs m/d/y decided from the values (default day-first)."""
    iso = pd.to_datetime(s, errors="coerce", format="ISO8601")
    if iso.notna().mean() >= 0.9:
        return iso
    parts = s.str.extract(r"^\s*(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})")
    a, b = pd.to_numeric(parts[0], errors="coerce"), pd.to_numeric(parts[1], errors="coerce")
    dayfirst = bool((a > 12).any()) or not bool((b > 12).any())
    day, month = (a, b) if dayfirst else (b, a)
    year = pd.to_numeric(parts[2], errors="coerce")
    year = year.where(year >= 100, year + 2000)
    out = pd.to_datetime(pd.DataFrame({"year": year, "month": month, "day": day}), errors="coerce")
    return out.where(out.notna(), iso)


def _to_date(s: pd.Series) -> pd.Series:
    texts = s.map(lambda v: isinstance(v, str))
    if texts.any():
        parsed = _text_dates(s[texts].astype(str))
        out = s.copy().astype(object)
        out[texts] = [None if pd.isna(v) else v.date() for v in parsed]
        rest = ~texts
        if rest.any():
            out[rest] = _to_date_values(s[rest])
        return out
    return _to_date_values(s)


def _to_date_values(s: pd.Series) -> pd.Series:
    def one(v):
        if v is None or v is pd.NaT:  # a blank date cell is NaT, which is also a datetime
            return None
        if isinstance(v, datetime):
            return v.date()
        if isinstance(v, date):
            return v
        if isinstance(v, (int, float)) and not pd.isna(v):
            return (pd.Timestamp("1899-12-30") + pd.Timedelta(days=float(v))).date()
        t = pd.to_datetime(v, errors="coerce")
        return None if pd.isna(t) else t.date()
    return s.map(one)


def _clean_text(s: pd.Series) -> pd.Series:
    return s.map(lambda v: "" if v is None or str(v).strip() in BLANK else str(v).strip())


def _str(s: pd.Series) -> pd.Series:
    """Cells as text, blank → "" (pandas 3's astype(str) keeps blanks as NaN, and #N/A cells now read as blank:
    a float among the text breaks sorting and merging)."""
    return s.map(lambda v: "" if v is None or (isinstance(v, float) and pd.isna(v)) else str(v))


def _need(df: pd.DataFrame, cols: list[str], where: str, path: Path | None = None, sheet: str | None = None) -> None:
    missing = [c for c in cols if c not in df.columns]
    if missing:
        file = Path(path).name if path else None
        raise InputError(f"{where} thiếu cột: {', '.join(missing)} – thêm cột (đúng tên) vào dòng tiêu đề (dòng 1)"
                         + (f" của {file} › {sheet or where}" if file else ""),
                         {"file": file, "sheet": sheet or where, "columns": missing, "row": 1})


def _contributions(path: Path) -> dict:
    """Summary sheet: date → {"gmv": %Contribution GMV, "ppc": %Contribution PPC} (daily phasing of the month)."""
    if "Summary" not in sheet_names(path):
        return {}
    rows = xlsx_rows(path, "Summary", 1, 12)
    label = lambda r: str(r[3]).strip().lower() if len(r) > 3 and r[3] is not None else ""  # noqa: E731
    days = next((r for r in rows if label(r) == "day"), None)
    gmv = next((r for r in rows if label(r) == "%contribution gmv"), None)
    ppc = next((r for r in rows if label(r) == "%contribution ppc"), None)
    if not days or not gmv:
        return {}
    out = {}
    for i in range(4, len(days)):
        d = days[i]
        if isinstance(d, (datetime, date)):
            num = lambda r: float(r[i]) if r and i < len(r) and isinstance(r[i], (int, float)) else 0.0  # noqa: E731
            out[d.date() if isinstance(d, datetime) else d] = {"gmv": num(gmv), "ppc": num(ppc) if ppc else num(gmv)}
    return out


def fill_campaign_names(ads: pd.DataFrame) -> pd.DataFrame:
    """Blank campaign_name cells stay missing in pandas (the UI then showed an empty name): use the newest name another
    row of the same campaign_id carries, else the campaign_id itself. A name equal to its campaign_id is that fallback
    (filled when the file was read, or stored by an earlier run), so it counts as blank: a real name from history wins."""
    name = ads["campaign"].astype(object).where(ads["campaign"].notna(), "").map(lambda v: str(v).strip())
    blank = name.isin(["", "nan", "None"]) | (name == ads["campaign_id"].astype(str).str.strip())  # "nan"/"None": older versions
    if blank.any():
        named = ads[~blank].assign(campaign=name[~blank]).sort_values("date", kind="stable")
        ids = ads.loc[blank, "campaign_id"]
        found = ids.map(named.groupby("campaign_id")["campaign"].last()).astype(object)
        name[blank] = found.where(found.notna(), ids)
    return ads.assign(campaign=name)


def _cid(v) -> str:
    return str(int(v)) if isinstance(v, (int, float)) and not pd.isna(v) else str(v).strip()


def export_campaign_names(path: Path, sheets: tuple = ("ads_camp",)) -> dict[str, str]:
    """campaign_id → name from the SSO AMZ Ads by Campaign export: ids in column E, names in column F (feedback #33,
    the Lead's source of truth). Newest non-blank name per id; {} when the file has another layout."""
    if is_csv(path):
        df = read_sheet(path)
        cols = list(df.columns)
        rows = df.itertuples(index=False, name=None)
    else:
        names = sheet_names(path)
        got = xlsx_rows(path, next((n for n in sheets if n in names), names[0]))
        cols, rows = [str(h).strip() for h in (got[0] if got else ())], [r[:6] + (None,) * (6 - len(r[:6])) for r in got[1:]]
    if len(cols) < 6 or cols[4] != "campaign_id":
        return {}
    df = pd.DataFrame([r[:6] for r in rows], columns=cols[:6]).iloc[:, [0, 4, 5]]
    df.columns = ["date", "id", "name"]
    df = df[df["id"].notna() & df["name"].notna()].assign(date=lambda d: _to_date(d["date"]))
    df["id"], df["name"] = df["id"].map(_cid), df["name"].map(lambda v: str(v).strip())
    df = df[(df["name"] != "") & (df["name"] != df["id"])].sort_values("date", kind="stable", na_position="first")
    return df.groupby("id")["name"].last().to_dict()


def _campaign_id(name: str) -> str:
    """New ads_camp exports have no campaign_id: Amazon names end with it ("…_1782098480")."""
    tail = str(name).strip().rsplit("_", 1)[-1]
    return tail if tail.isdigit() else str(name).strip()


def _event_days(path: Path) -> dict[date, str]:
    if "Summary" not in sheet_names(path):
        return {}
    rows = xlsx_rows(path, "Summary", 1, 4)
    if len(rows) < 4:
        return {}
    labels, days = rows[1], rows[3]
    out, current = {}, None
    for i in range(4, len(days)):
        lab = labels[i] if i < len(labels) else None
        current = lab if lab not in (None, "") else current
        d = days[i]
        if isinstance(d, (datetime, date)) and current:
            out[d.date() if isinstance(d, datetime) else d] = str(current)
    return out


def _excel_text(v) -> str:
    return f"{v:.15g}" if isinstance(v, (int, float)) else str(v)  # how Excel joins a number into text


# Keepa columns kept per ASIN for the one-SKU listing chart (Performance Review): key → header
KEEPA_VALUES = {"bb": "Buy Box: Current", "bb30": "Buy Box: 30 days avg.", "new": "New: Current",
                "list": "List Price: Current", "amazon": "Amazon: Current", "rank": "Sales Rank: Current",
                "seller": "Buy Box: Buy Box Seller", "avail": "Availability of the Amazon offer",
                "bb_avail": "Availability of the Buy Box", "rating": "Reviews: Rating", "reviews": "Reviews: Rating Count",
                "updated": "Last update"}


def _keepa_values(li: pd.DataFrame) -> dict[str, dict]:
    """{asin: {bb, bb30, new, list, amazon, rank, seller, …}} – today's Keepa row of each ASIN (blank → None)."""
    def val(v):
        if v is None or (isinstance(v, float) and pd.isna(v)) or v == "":
            return None
        if isinstance(v, (datetime, date)):
            return v.isoformat(timespec="minutes") if isinstance(v, datetime) else v.isoformat()
        return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else str(v).strip()
    cols = {k: c for k, c in KEEPA_VALUES.items() if c in li.columns}
    out = {}
    for row in li[["ASIN", *cols.values()]].itertuples(index=False):
        asin = row[0]
        if asin is not None and str(asin).strip() and not (isinstance(asin, float) and pd.isna(asin)):
            out[str(asin).strip()] = dict.fromkeys(KEEPA_VALUES) | {k: val(v) for k, v in zip(cols, row[1:])}
    return out


def _listing_flags(path: Path, sheet: str) -> tuple[dict[str, str], date | None, dict[str, dict]]:
    """Keepa table (header on row 2) → ({asin: "Mất buybox · Tăng giá từ …"} for ASINs with any flag, last update,
    {asin: today's Keepa values} – see _keepa_values). Same as the
    Listing Issue sheet's formulas: CG Mất buybox = 30-day Buy Box avg but no current Buy Box, CH Long Shipping Time
    = Amazon offer delayed, CI Bị tăng giá = current Buy Box > 1.15 × the 30-day avg."""
    li = _first_of_each(read_sheet(path, sheet, header_row=2))  # "ASIN" twice (input, Keepa output): column B
    if not set(KEEPA) <= set(li.columns):
        return {}, None, {}
    blank = lambda v: v is None or (isinstance(v, float) and pd.isna(v)) or v == ""  # noqa: E731
    num = lambda v: isinstance(v, (int, float)) and not isinstance(v, bool) and not pd.isna(v)  # noqa: E731
    out = {}
    for asin, now, avg, avail in zip(*(li[c] for c in KEEPA)):
        parts = (["Mất buybox"] if not blank(avg) and blank(now) else []) \
            + (["Long Shipping Time"] if avail == "Amazon offer shipping is delayed" else []) \
            + ([f"Tăng giá từ {_excel_text(avg)} lên {_excel_text(now)}"] if num(now) and num(avg) and avg > 0 and now > avg * 1.15 else [])
        if not blank(asin) and parts:
            out[str(asin).strip()] = " · ".join(parts)
    return out, _latest(li["Last update"]) if "Last update" in li.columns else None, _keepa_values(li)


def _latest(s: pd.Series) -> date | None:
    days = [d for d in _to_date(s) if d]
    return max(days) if days else None


def us_today(now: datetime | None = None) -> date:
    """Today on the data's clock: every date in the sources is a US (Pacific) date, ~14 h behind Vietnam."""
    from datetime import timedelta, timezone
    try:
        from zoneinfo import ZoneInfo
        tz = ZoneInfo("America/Los_Angeles")
    except Exception:  # no time-zone data in this build: Pacific standard time
        tz = timezone(timedelta(hours=-8))
    return (now or datetime.now(timezone.utc)).astimezone(tz).date()


def freshness(latest: dict, today: date) -> list[dict]:
    """Every table's newest day and whether it is recent enough (shown on each run's results)."""
    out = []
    for table, (file, day) in latest.items():
        lag = MAX_LAG_DAYS.get(table)
        if lag is not None and day is not None:
            out.append({"table": LABELS.get(table) or TRACKER_SHEETS[table], "file": file, "day": day.isoformat(),
                        "need": (today - pd.Timedelta(days=lag)).isoformat(), "ok": (today - day).days <= lag})
    return out


def stale(latest: dict, today: date) -> list[str]:
    """Tables whose newest day is too old: the export job did not run, or OneDrive did not sync."""
    return [f"{f['file']} › {f['table']}: mới đến {date.fromisoformat(f['day']):%d/%m}, "
            f"cần từ {date.fromisoformat(f['need']):%d/%m}" for f in freshness(latest, today) if not f["ok"]]


def _header_row(path: Path, sheet: str, need: tuple, scan: int = 12) -> int | None:
    """Row number of the header holding all of `need` (refresh notes and dates sit above it)."""
    for n, row in enumerate(xlsx_rows(path, sheet, 1, scan), 1):
        if set(need) <= {str(v).strip() for v in row if v is not None}:
            return n
    return None


def _stock(path: Path, sheet: str) -> tuple[pd.Series, date | None, date | None, dict]:
    """Inventory sheet → (INV Y4A AMZ per SKU – the SKU's first row, like XLOOKUP –, Y4A as-of day, AMZ as-of day,
    incoming per SKU). The as-of days are the dates above the INV Y4A / INV AMZ headers."""
    head = _header_row(path, sheet, STOCK)
    if not head:
        raise InputError(f"{sheet} thiếu dòng tiêu đề có cột: {', '.join(STOCK)}",
                         {"file": Path(path).name, "sheet": sheet, "columns": list(STOCK)})
    full = read_sheet(path, sheet, header_row=head)
    cols = list(full.columns)
    df = _first_of_each(full)
    df = df[_sku_key(df["SKU"]) != ""]
    stock = to_num(df["INV Y4A AMZ"]).groupby(_sku_key(df["SKU"])).first()
    top, _ = read_sheet_with_rows(path, sheet, header_row=1)
    top = top[top["_row"] < head]  # the rows between row 1 and the header
    day = lambda name: _latest(top.iloc[:, cols.index(name)]) if len(top) else None  # noqa: E731
    return stock, day("INV Y4A"), day("INV AMZ"), _incoming(full, top, day("INV Y4A"))


INCOMING = range(22, 48)  # Excel columns W..AV of the inventory report: incoming units per arrival window


def _nearest(ref: date, md: list[tuple[int, int]]) -> date | None:
    """The real date nearest ref among (month, day) readings, in ref's year or the one before / after."""
    days = []
    for mo, dd in md:
        for y in (ref.year - 1, ref.year, ref.year + 1):
            try:
                days.append(date(y, mo, dd))
            except ValueError:
                pass
    return min(days, key=lambda d: abs((d - ref).days), default=None)


def _window(label: str, above: date | None, ref: date) -> tuple[str, date | None, date | None]:
    """(label, first day, last day) of an incoming column: its header – a date, "11/10-11/16" (d/m or m/d: the
    reading nearest the data day), "W46" (ISO week) – else the date above the header (label = that date)."""
    if label.startswith("col"):  # blank header
        return (f"{above:%d/%m}", above, above) if above else ("", None, None)
    if m := re.fullmatch(r"(\d{4}-\d{2}-\d{2})( 00:00:00)?", label):  # a date cell
        d = date.fromisoformat(m[1])
        return f"{d:%d/%m}", d, d
    if m := re.search(r"\bW(?:K|eek)?\s*(\d{1,2})\b", label, re.I):
        weeks = []
        for y in (ref.year - 1, ref.year, ref.year + 1):
            try:
                weeks.append(date.fromisocalendar(y, int(m[1]), 1))
            except ValueError:
                pass
        if weeks:
            d = min(weeks, key=lambda d: abs((d - ref).days))
            return label, d, d + timedelta(days=6)
    days = [_nearest(ref, [(int(b), int(a)), (int(a), int(b))]) for a, b in re.findall(r"(\d{1,2})/(\d{1,2})", label)]
    days = [d for d in days if d]
    return (label, days[0], days[-1]) if days else (label, above, above)


def _incoming(df: pd.DataFrame, top: pd.DataFrame, today: date | None) -> dict:
    """{SKU key: {"qty", "window", "arrival"}}: per SKU (first row), the left-most column of W..AV holding units whose
    window has not ended before the data day. arrival = the window's first day (ISO), None if the header is no date.
    ponytail: the layout of W..AV is assumed (no sample file yet) – one column per arrival window, the header a date,
    a range ("11/10-11/16") or a week ("W46"), or a date above the header; fix _window once the real file is seen."""
    out = {}
    keys = _sku_key(df.iloc[:, list(df.columns).index("SKU")])
    for i in (i for i in INCOMING if i < df.shape[1]):
        above = _latest(top.iloc[:, i]) if len(top) else None
        label, first, last = _window(str(df.columns[i]), above, today or date.today())
        if not label or (today and last and last < today):
            continue  # a blank column, or a window already over
        for sku, q in zip(keys, to_num(df.iloc[:, i])):
            if sku and q > 0 and sku not in out:
                out[sku] = {"qty": float(q), "window": label, "arrival": first.isoformat() if first else None}
    return out


def load_converted(path: Path) -> pd.DataFrame:
    """Converted product export → rows (date, campaign_id, adv, conv, sales, units). sales = NMV, units_sold = RS;
    the ads spend column repeats the ad group's whole spend on every converted row, so it is not read. The workbook
    (SSO's SharePoint report, USA only) is read whole; the older CSV export (~130 MB, read with pandas) covers every
    market, so only its USD rows are kept."""
    if is_csv(path):
        enc, sep = csv_format(path)
        head = csv_header(path)
        _need(pd.DataFrame(columns=head), list(CONVERTED), "Converted product", path, None)
        cols = list(CONVERTED) + [c for c in CONVERTED_OPTIONAL if c in head]
        df = pd.read_csv(path, usecols=cols, dtype=str, sep=sep, encoding=enc, encoding_errors="replace",
                         keep_default_na=False)
    else:
        df = read_sheet(path)
        _need(df, list(CONVERTED), "Converted product", path, sheet_names(path)[0])
    if is_csv(path) and "budget_currency" in df.columns:
        df = df[df["budget_currency"].astype(str).str.strip().str.upper() == "USD"]
    out = pd.DataFrame({"date": _to_date(df["report_date"]), "campaign_id": df["campaign_id"].map(_cid),
                        "adv": df["advertised_product_id"].astype(str).str.strip(),
                        "conv": df["converted_product_id"].astype(str).str.strip(),
                        "sales": to_num(df["sales"]), "units": to_num(df["units_sold"]),
                        "dept": df["department"].astype(str).str.strip().str.upper() if "department" in df.columns else ""})
    return out.dropna(subset=["date"]).reset_index(drop=True)


def team_converted(conv: pd.DataFrame | None, layout: Layout, asins: set) -> pd.DataFrame | None:
    """The Converted product rows of one team: its department (SSO / SFO); a row without department only when its
    advertised or converted ASIN is the team's. Another team's rows never reach this team's numbers or report files."""
    if conv is None:
        return None
    dept = conv["dept"] if "dept" in conv.columns else pd.Series("", index=conv.index)
    mine = (dept == layout.name.upper()) | ((dept == "") & (conv["adv"].isin(asins) | conv["conv"].isin(asins)))
    out = conv[mine].drop(columns="dept", errors="ignore").reset_index(drop=True)
    out.attrs["team"] = layout.team  # the inputs cache is only reused for the same team (api._load_cached)
    return out


def _first_of_each(df: pd.DataFrame) -> pd.DataFrame:
    return df.loc[:, ~df.columns.duplicated()]


def _sku_text(s: pd.Series) -> pd.Series:
    """SKU text as typed: SFO's exports keep Excel's text marker ('ETPW) – the SKU is ETPW."""
    return s.map(lambda v: "" if v is None or (isinstance(v, float) and pd.isna(v)) else _excel_text(v).strip().lstrip("'"))


def _col(df: pd.DataFrame, name: str, letter: int | None = None) -> str | None:
    """A header by its text with line breaks / double spaces folded ("Group\n(PMKT Custom)"), else the column at
    position `letter` (0 = A)."""
    want = " ".join(name.split()).casefold()
    hit = next((c for c in df.columns if " ".join(str(c).split()).casefold() == want), None)
    if hit is None and letter is not None and letter < len(df.columns) - 1:  # the last column is _row
        hit = df.columns[letter]
    return hit


def _sfo_products(info: pd.DataFrame, kpi: pd.DataFrame, raw: pd.DataFrame) -> pd.DataFrame:
    """SFO Product_info → Product Info's shape. Product line = column J "Group (PMKT Custom)" (the Lead's choice; the
    KPI's Product Variant, column C, is the same grouping). Every ASIN Active (no status column – the Lead's choice).
    PIC (PMKT PIC_Final) = the KPI's MKT PIC of the SKU, latest month; #N/A → the raw data's PIC on its last day."""
    _need(info, ["ASIN", "AMZ SKU"], "Product_info")
    pl_col = _col(info, "Group (PMKT Custom)", 9)
    kp = kpi[kpi["pic"] != ""].sort_values("month").drop_duplicates("sku", keep="last").set_index("sku")["pic"]
    rp = raw[raw["pic"] != ""].sort_values("date").drop_duplicates("sku", keep="last").set_index("sku")["pic"]
    sku = _sku_text(info["AMZ SKU"])
    pic = sku.map(kp)
    pic = pic.where(pic.notna(), sku.map(rp)).fillna("")
    out = pd.DataFrame({"asin": _clean_text(info["ASIN"]), "sku": sku,
                        "pl": _clean_text(info[pl_col]) if pl_col else "", "status": "Active",
                        "PMKT PIC_Final": pic.values, "_row": info["_row"]})
    if "product_name" in info.columns:
        out["product_name"] = _clean_text(info["product_name"])
    label = _col(info, "ASIN Label")
    out["main"] = (_clean_text(info[label]) == "Main ASIN") if label else False
    return out[out["asin"] != ""].reset_index(drop=True)


def _sfo_kpi(k: pd.DataFrame, info: pd.DataFrame) -> pd.DataFrame:
    """SFO KPI (one row per SKU, header on row 2) → KPI's shape: the SKU's target goes to its Main ASIN (Product_info
    ASIN Label), else its first ASIN there. SKUs without an ASIN in Product_info carry no target."""
    _need(k, ["Month", "SKU", "PPC Spend", "Total GMV"], "KPI")
    sku = _sku_text(k["SKU"])
    first = info.sort_values("main", ascending=False, kind="stable").drop_duplicates("sku").set_index("sku")["asin"]
    pic = _col(k, "MKT PIC")
    out = pd.DataFrame({"month": to_num(k["Month"]), "sku": sku, "asin": sku.map(first),
                        "gmv": to_num(k["Total GMV"]), "spend": to_num(k["PPC Spend"]),
                        "rs": to_num(k["Total RS"]) if "Total RS" in k.columns else 0.0,
                        "stock": float("nan"), "pic": _clean_text(k[pic]) if pic else "", "_row": k["_row"]})
    out = out[out["month"].notna() & (out["month"] > 0)]
    out["month"] = out["month"].astype(int)
    out.attrs["no_asin"] = sorted(set(out.loc[out["asin"].isna(), "sku"]) - {""})
    return out[out["asin"].notna()].reset_index(drop=True)


def _sku_key(s: pd.Series) -> pd.Series:
    """SUMIFS matching: case-insensitive, and SKU 9 (number) = "9" = 9.0."""
    return s.map(lambda v: _excel_text(v).strip().upper() if v is not None and not pd.isna(v) else "")


def load_inputs(roles: dict[str, Path], account: str | None = None, layout: Layout = SSO, cancel=None) -> Inputs:
    """account: ads_camp account_name to keep; None = the account with the most rows (a layout with all_accounts:
    every account). layout: the team's sheet names and shapes (SFO's are turned into SSO's tables). cancel: a
    threading.Event looked at before each table is read (progress.Cancelled once Stop is pressed)."""
    t = roles.get("tracker")
    sources = {}
    sheets = layout.sheets

    def table(name: str):
        """(path, sheet) for a tracker table: its own CSV if given, else the workbook sheet (None if absent)."""
        check(cancel)  # every sheet read starts here: a Stop press ends the loading between two sheets
        if name in roles:  # a CSV, or a one-table workbook (SharePoint export)
            return roles[name], None if is_csv(roles[name]) else EXPORT_SHEETS.get(name, sheets[name])
        if t is not None and sheets[name] in sheet_names(t):
            return t, sheets[name]
        return None

    def src(name: str, path: Path, sheet: str, letters: dict) -> None:
        sources[name] = {"file": Path(path).name, "sheet": sheet, "letters": letters}

    raw, letters = read_sheet_with_rows(*table("raw"))
    src("raw", table("raw")[0], table("raw")[1], letters)
    _need(raw, ["report_date", "asin", "sku", "ordered_gmv_usd", "ppc_ordered_gmv_usd", "sp_spend", "sb_spend",
                "sd_spend", "ppc_clicks", "ppc_orders"], sheets["raw"], *table("raw"))
    raw = pd.DataFrame({
        "date": _to_date(raw["report_date"]), "asin": _str(raw["asin"]), "sku": _sku_text(raw["sku"]),
        "gmv": to_num(raw["ordered_gmv_usd"]), "ads_gmv": to_num(raw["ppc_ordered_gmv_usd"]),
        "spend": to_num(raw["sp_spend"]) + to_num(raw["sb_spend"]) + to_num(raw["sd_spend"]),
        "clicks": to_num(raw["ppc_clicks"]), "orders": to_num(raw["ppc_orders"]),
        "units": to_num(raw["ordered_units"]) if "ordered_units" in raw.columns else 0.0,
        "ads_units": to_num(raw["ppc_ordered_units"]) if "ppc_ordered_units" in raw.columns else 0.0,
        "promo": to_num(raw["total_promotion"]) if "total_promotion" in raw.columns else 0.0,  # > 0 = deal day
        "sessions": to_num(raw["glance_views"]) if "glance_views" in raw.columns else 0.0,  # est GMV lost baseline
        "pic": _clean_text(raw["PIC"]) if "PIC" in raw.columns else "",
        "_row": raw["_row"],
    }).dropna(subset=["date"])
    if raw.empty:
        raise InputError(f"{sheets['raw']} không có dòng nào đọc được ngày ở cột report_date",
                         {"file": Path(table("raw")[0]).name, "sheet": table("raw")[1] or sheets["raw"], "columns": ["report_date"], "row": 2})
    raw_pic = raw[["date", "sku", "pic"]]
    raw = raw.drop(columns="pic")

    if layout.kpi_by_sku:  # SFO: KPI per SKU (header on row 2) → per Main ASIN of Product_info
        info, letters = read_sheet_with_rows(*table("products"))
        src("products", table("products")[0], table("products")[1], letters)
        k, kletters = read_sheet_with_rows(*table("kpi"), header_row=layout.kpi_header_row)
        src("kpi", table("kpi")[0], table("kpi")[1], kletters)
        products = _sfo_products(info, _kpi_pics(k), raw_pic)
        kpi = _sfo_kpi(k, products)
        products = products.drop(columns="main")
    else:
        products, kpi, k = None, None, None
    info = None if products is not None else read_sheet_with_rows(*table("products"))
    if info is not None:
        info, letters = info
        src("products", table("products")[0], table("products")[1], letters)
        products = _sso_products(info, table("products"))

    latest, keepa = {}, {}
    if layout.keepa and table("listing"):
        flags, latest["listing"], keepa = _listing_flags(*table("listing"))
        products["listing"] = products["asin"].map(flags).fillna("")

    if kpi is None:
        k, letters = read_sheet_with_rows(*table("kpi"))
        src("kpi", table("kpi")[0], table("kpi")[1], letters)
        _need(k, ["Month", "ASIN", "GMV", "Spend_final"], "KPI", *table("kpi"))
        kpi = pd.DataFrame({"month": to_num(k["Month"]).astype(int), "asin": _str(k["ASIN"]),
                            "gmv": to_num(k["GMV"]), "spend": to_num(k["Spend_final"]),
                            "rs": to_num(k["RS"]) if "RS" in k.columns else 0.0,
                            "stock": to_num(k["Current Stock"]) if "Current Stock" in k.columns else float("nan"),
                            "_row": k["_row"]})
        kpi_sku = _sku_text(k["sku"]) if "sku" in k.columns else None
    else:
        kpi_sku = kpi["sku"]
        kpi = kpi.drop(columns=["sku", "pic"])
    incoming = {}
    if table("inventory") and kpi_sku is not None:  # Current Stock = INV Y4A AMZ (Y4A + Amazon) of the SKU
        stock, latest["inv_y4a"], latest["inv_amz"], incoming = _stock(*table("inventory"))
        kpi["stock"] = _sku_key(kpi_sku).map(stock).fillna(0).values

    if table("ineligible"):
        ie = read_sheet(*table("ineligible"))
        ineligible = pd.DataFrame({"date": _to_date(ie.get("log_date", pd.Series(dtype=object))),
                                   "asin": _str(ie.get("asin", pd.Series(dtype=object))),
                                   "status": ie.get("delivery_status", pd.Series(dtype=object)),
                                   "reason": ie.get("delivery_reasons", pd.Series(dtype=object))})
    else:
        ineligible = pd.DataFrame(columns=["date", "asin", "status", "reason"])

    ads_sheet = None if is_csv(roles["ads"]) else ads_sheet_of(roles["ads"], layout)
    a, letters = read_sheet_with_rows(roles["ads"], ads_sheet)
    src("ads", roles["ads"], ads_sheet, letters)
    _need(a, ["report_date", "account_name", "campaign_type", "campaign_name", "asin",
              "spend_usd", "clicks", "sales_14d", "order_14d"], ads_sheet or "ads_camp", roles["ads"], ads_sheet)
    if "campaign_id" not in a.columns:
        a["campaign_id"] = a["campaign_name"].map(_campaign_id)
    names = a["account_name"].astype(str).str.strip()
    accounts = names.value_counts()
    if account and account not in accounts.index:
        raise InputError(f"ads_camp không có account '{account}' – chọn lại trong Cài đặt → Tài khoản Ads")
    chosen = account or ("" if layout.all_accounts else accounts.index[0] if len(accounts) else "")
    a = a[names == chosen] if chosen else a  # all_accounts: every account (SFO runs several)
    ads = pd.DataFrame({
        "date": _to_date(a["report_date"]), "type": _str(a["campaign_type"]),
        "campaign_id": a["campaign_id"].map(_cid),
        # the export's column F (after campaign_id in E) is the name – whatever its header says (feedback #33)
        "campaign": a.iloc[:, 5] if list(a.columns).index("campaign_id") == 4 else a["campaign_name"],
        "asin": _str(a["asin"]),
        "spend": to_num(a["spend_usd"]), "clicks": to_num(a["clicks"]),
        "sales": to_num(a["sales_14d"]), "orders": to_num(a["order_14d"]), "_row": a["_row"],
    }).dropna(subset=["date"]).reset_index(drop=True)
    if roles.get("ads_names"):  # the Data workbook's ads_camp may lack names: the export's column F has them
        named = ads["campaign_id"].map(export_campaign_names(roles["ads_names"], layout.ads_sheets))
        ads["campaign"] = named.where(named.notna(), ads["campaign"])
    ads = fill_campaign_names(ads)
    ads.attrs["accounts"], ads.attrs["account"] = list(accounts.index), chosen

    log, letters = read_sheet_with_rows(roles["activity"])
    src("activity", roles["activity"], None if is_csv(roles["activity"]) else sheet_names(roles["activity"])[0], letters)
    cols = ["id", "level", "type", "action", "from_", "to", "time", "user"]
    if log.empty:
        activity = pd.DataFrame(columns=cols + ["_row"])
    else:
        activity = log.drop(columns="_row").iloc[:, :8].copy()
        activity.columns = cols[: activity.shape[1]]
        activity = activity.reindex(columns=cols)
        activity["_row"] = log["_row"].values

    defind_text = ""
    if roles.get("defind"):
        d = read_sheet(roles["defind"])
        defind_text = "\n".join(" | ".join(str(v) for v in row if v not in (None, "") and not pd.isna(v))
                                for row in [list(d.columns)] + d.values.tolist())
        defind_text = defind_text.replace("col0 | ", "")

    # Stock = KPI Current Stock (undated, like the Listing Issue sheet) → dated at the last raw day, so the inventory
    # guard, the "Hết hàng" lists and the listing history all read the same number. Blank = unknown (not guarded).
    last = raw["date"].max()
    # Current Stock is the same SUMIFS on every month's row → any row of the ASIN will do (latest month wins).
    k_now = kpi[kpi["stock"].notna()].sort_values("month").drop_duplicates("asin", keep="last")
    inventory = pd.DataFrame({"date": last, "asin": k_now["asin"].str.strip(), "sku": "", "stock": k_now["stock"],
                              "_row": k_now["_row"]})
    sources["inventory"] = sources["kpi"]

    latest |= {"raw": raw["date"].max(), "ads": ads["date"].max() if len(ads) else None,
               "ineligible": _latest(ineligible["date"]) if table("ineligible") else None}
    file = lambda name: Path(roles["ads"] if name == "ads" else table("inventory" if name.startswith("inv_") else name)[0]).name  # noqa: E731
    converted = team_converted(load_converted(roles["converted"]) if roles.get("converted") else None, layout,
                               set(products["asin"]))
    return Inputs(raw, products, kpi, ineligible, ads, activity, _event_days(t) if t is not None else {}, defind_text,
                  sources, inventory, _contributions(t) if t is not None else {},
                  {name: (file(name), day) for name, day in latest.items() if day is not None}, incoming, keepa, converted)


def _kpi_pics(k: pd.DataFrame) -> pd.DataFrame:
    """SFO KPI → (sku, month, pic) for the PIC of each SKU (MKT PIC; #N/A is blank)."""
    pic = _col(k, "MKT PIC")
    return pd.DataFrame({"sku": _sku_text(k["SKU"]) if "SKU" in k.columns else pd.Series(dtype=str),
                         "month": to_num(k["Month"]) if "Month" in k.columns else 0.0,
                         "pic": _clean_text(k[pic]) if pic else ""})


def _sso_products(info: pd.DataFrame, where: tuple) -> pd.DataFrame:
    """SSO Product Info → the products table (PL = product_line_old; PIC columns PIC <Mon> / PMKT PIC_Final)."""
    _need(info, ["asin", "sku", "product_line_old", "status"], "Product Info", *where)
    pic_cols = [c for c in info.columns if c.startswith("PIC ") or c == "PMKT PIC_Final"]
    products = pd.DataFrame({"asin": _clean_text(info["asin"]), "sku": _str(info["sku"]),
                             "pl": _clean_text(info["product_line_old"]), "status": _clean_text(info["status"]),
                             "_row": info["_row"]})
    for c in ("lifecycle", "product_name"):
        if c in info.columns:
            products[c] = _clean_text(info[c])
    for c in pic_cols:
        products[c] = _clean_text(info[c])
    if "Team Label" in info.columns:  # scope for the score model
        products["team"] = _clean_text(info["Team Label"])
    if "Sales Leader" in info.columns:  # Performance Review filter
        products["leader"] = _clean_text(info["Sales Leader"])
    return products[products["asin"] != ""].reset_index(drop=True)  # no ASIN (blank / #N/A): nothing to map
