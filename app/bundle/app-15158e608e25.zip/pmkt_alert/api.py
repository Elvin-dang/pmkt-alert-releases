"""Everything the UI can call (exposed to JavaScript via pywebview's js_api).
Every public method returns JSON-serializable data and never raises."""
import base64
from concurrent.futures import ThreadPoolExecutor
import contextlib
import functools
import hashlib
import math
import json
import os
import pickle
import re
import secrets
import threading
import time
import traceback
import unicodedata
import uuid
import urllib.request
from datetime import date, datetime
from pathlib import Path

from . import __version__
from .ai import evaluate_logic, generate, offline, pic_rows, planned_calls
from .aggregate import asin_map
from .changelog import bundled_text, parse as parse_changelog
from .backtest import apply_approved, propose_from_feedback, proposals_from_review
from .claude import ClaudeError, ask, cancel as cancel_claude, cancel_scope as claude_scope, check_status, grounded, open_login
from . import onedrive, sharepoint
from .layouts import SSO as SSO_LAYOUT, Layout, layout_of
from .cognix import (PROFILE_ID, REDIRECT, Cognix, CognixError, ad_group_url, asin_states, budget_of, code_from, email_of, login_url,
                     merge_activity, pkce, state_of)
from .claude import usage as cc_usage
from .claude import _exe as claude_exe
from .claude import install as install_claude_cli
from . import deck as deckmod
from .evidence import evidence
from .export import export_pic
from .performance import OOS, day_issues, listing_issue_asins, listing_issues, performance, period_drivers
from . import hourly as hourlymod
from .identity import LeadKeys, MemberKey, protect, raw_public, unprotect
from .package import EXT, PackageError, add_readers, reader_id
from .package import build as build_package
from .package import read as read_package
from .progress import Cancelled, Eta, check
from .share import _frame_bytes, _frame_from, build_parts, unpack_run
from .sharepoint import SharePointError, link_of
from .supabase import HOURLY_DIR, LEAD_FILE, Supabase, TeamError, pic_file
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


HR_FETCH_EVERY = 3600  # s between SharePoint downloads of the hourly file (the data team updates it about hourly)
EMAIL_RE = re.compile(r"[^@\s']+@[^@\s']+\.[^@\s']+")
_pub64 = lambda pub: base64.b64encode(raw_public(pub)).decode()  # noqa: E731
HR_SHARE_REPORTS = 3  # viewers look for the Lead's hourly data in the newest reports (a new upload has none for a moment)


def _in_team(r: dict, team: str, default: str) -> bool:
    """A member row reads a team's reports: an Admin (role lead) every team; anyone else their own (no team on the row:
    a server from before teams = the default team)."""
    return r["role"] == "lead" or (r.get("team") or default) == team


def _report_readers(rows: list[dict], lead: LeadKeys, team: str = "", default: str = "") -> tuple[dict[str, list], dict[str, int], list]:
    """Active member rows → ({PIC: its members' device keys}, {PIC: members with a device}, the keys of the other
    staff: Admins, and the team's Team Leads / Operators). Only that team's people. The signing Lead's own key is added
    to every part by package.build."""
    pub = lambda k: X25519PublicKey.from_public_bytes(base64.b64decode(k))  # noqa: E731
    rows = [r for r in rows if _in_team(r, team, default)]
    readers: dict[str, list] = {}
    counts: dict[str, int] = {}
    for r in rows:
        if r["role"] == "member" and r.get("pic") and r.get("enc_keys"):
            readers.setdefault(r["pic"], []).extend(pub(k) for k in r["enc_keys"])
            counts[r["pic"]] = counts.get(r["pic"], 0) + 1
    others = [pub(k) for r in rows if r["role"] in STAFF for k in r.get("enc_keys") or [] if k != _pub64(lead.enc_public)]
    return readers, counts, others


FOLDER_TEAM = re.compile(r"^PMKT-Alert-([A-Za-z0-9]+)_")


def folder_team(name: str, default: str) -> str:
    """The team a report folder belongs to (as the SQL pmkt_folder_team): PMKT-Alert-<TEAM>_<date>, else the default."""
    m = FOLDER_TEAM.match(name or "")
    return m.group(1).lower() if m else default


def _mtime(f: Path) -> str:
    return datetime.fromtimestamp(f.stat().st_mtime).isoformat(timespec="seconds")


def _hr_last(df) -> str:
    """The latest hour in an hourly frame as 'YYYY-MM-DDTHH' (sorts like time); '' when empty."""
    if df is None or not len(df):
        return ""
    d = df["date"].max()
    return f"{d.isoformat()}T{int(df.loc[df['date'] == d, 'hour'].max()):02d}"


def _local_iso(stamp: str) -> str:
    """Storage time stamp (UTC, '…Z' / '+00:00') → local 'YYYY-MM-DDTHH:MM:SS' as the UI shows file times."""
    try:
        return datetime.fromisoformat(stamp.replace("Z", "+00:00")).astimezone().replace(tzinfo=None).isoformat(timespec="seconds")
    except (ValueError, AttributeError):
        return stamp or ""


def _cell(v):
    if v is None or (isinstance(v, float) and v != v):
        return None
    if isinstance(v, (datetime, date)):
        return v.isoformat()[:10] if not isinstance(v, datetime) or (v.hour, v.minute) == (0, 0) else v.isoformat(timespec="minutes")
    if isinstance(v, float):
        return round(v, 4)
    if hasattr(v, "item"):
        return _cell(v.item())
    return v if isinstance(v, (int, bool)) else str(v)[:80]


@functools.lru_cache(maxsize=32)
def _file_detail_cached(path: str, mtime: float, size: int) -> dict:
    import pandas as pd
    from .xlsx import is_csv, read_sheet, sheet_names
    p = Path(path)
    sheets = []
    for name in ([None] if is_csv(p) else sheet_names(p)):
        df = read_sheet(p, name)
        dates = {"column": None, "min": None, "max": None}
        for col in df.columns:
            if "date" in col.lower() or "ngày" in col.lower():
                first = next((str(v) for v in df[col] if v not in (None, "")), "")
                iso = bool(re.match(r"\d{4}-\d{2}-\d{2}", first))  # 2026-10-02 vs 02/10/2026 (day first, VN)
                d = pd.to_datetime(df[col], errors="coerce", format="mixed", dayfirst=not iso).dropna()
                if len(d):
                    dates = {"column": col, "min": d.min().date().isoformat(), "max": d.max().date().isoformat()}
                    break
        cols = list(df.columns)[:30]
        sheets.append({"name": name or p.stem, "rows": int(len(df)), "columns": list(df.columns), "dates": dates,
                       "preview": {"columns": cols, "rows": [[_cell(v) for v in r] for r in df[cols].head(8).itertuples(index=False)]}})
    return {"name": p.name, "path": str(p), "folder": str(p.parent), "size": size,
            "modified": datetime.fromtimestamp(mtime).isoformat(timespec="seconds"), "sheets": sheets}


def _latest_day(s) -> str | None:
    """Newest timestamp in the Activity Log's time column (ISO, minutes)."""
    import pandas as pd
    t = pd.to_datetime(s, errors="coerce", format="mixed").dropna()
    return t.max().isoformat(timespec="minutes") if len(t) else None


def _file_detail(p: Path, layout: Layout = SSO_LAYOUT) -> dict:
    if not p.is_file():
        raise ValueError(f"Không thấy file: {p}")
    st = p.stat()
    try:
        role = role_of(p, layout)
    except Exception:
        role = None
    return {**_file_detail_cached(str(p), st.st_mtime, st.st_size), "role": role}


def _new_password() -> str:
    """Readable first password, e.g. 'kq7m-x3vt-p9da' (no 0/o/1/l)."""
    abc = "abcdefghijkmnpqrstuvwxyz23456789"
    return "-".join("".join(secrets.choice(abc) for _ in range(4)) for _ in range(3))


def _bundled_team() -> dict:
    """Optional team.json shipped in the release build (Supabase URL + anon key – public by design)."""
    p = Path(__file__).with_name("team.json")
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except ValueError:
        return {}


def _kdf(password: str, salt: bytes) -> bytes:
    return Scrypt(salt=salt, length=32, n=2 ** 15, r=8, p=1).derive(password.encode("utf-8"))
from . import keybackup
from .history import History
from .loaders import EXTRA_ROLES, OPTIONAL_ROLES, ROLES, TRACKER_REQUIRED, TRACKER_SHEETS, InputError, ads_sheet_of, detect_inputs, input_files, freshness, load_inputs, newer_ads, role_of, stale, us_today
from .logic import LogicError, load_logic, valid_change, version_from_name
from .pipeline import result_to_json, run_rules
from .prompts import STYLE_SCHEMA, TEAM_SCHEMA, style_prompt, team_prompt
from .scorecard import METRICS, daily_pic, scorecard, weekly
from .rules.actions import suggest_email_map
from .store import Store, replace, write_atomic
from .updater import DEFAULT_REPO, apply_update, download_verified, is_newer, latest_release, latest_tag, recent_releases
from .windows import Windows
from .xlsx import session as xlsx_session, sheet_names


STOPPED = "Đã dừng theo yêu cầu"


class _RunCtx:
    """One run: its own cancel event, and the token (this object) its progress and saves are checked against – once
    Stop is pressed or a newer run starts, a late thread of this run changes nothing."""

    def __init__(self):
        self.cancel = threading.Event()
        self.eta: Eta | None = None
        self.run_id: str | None = None  # rule results saved
        self.on_stop = None  # set while Claude works on a saved run: marks its Claude part as stopped


def always_fail(prompt, schema):
    raise ClaudeError("Claude Code chưa sẵn sàng")


SIGN_IN_FIRST = "Đăng nhập trước khi dùng app"
LEAD_ONLY = "Chỉ Lead được làm việc này – bạn đang ở chế độ Thành viên (chỉ xem)"
# Roles: lead = Admin (every team); team_lead = runs one team and manages its Operators / Members; operator; member.
RUNNERS = ("lead", "team_lead")  # run, upload, hourly, logic; sign reports
STAFF = ("lead", "team_lead", "operator")  # read their team's full report (an Admin: every team's)
VIEWERS = ("member", "operator")  # no local runs: data comes from an uploaded report (Operator: the full one)
ROLE_LABEL = {"lead": "Admin", "team_lead": "Team Lead", "operator": "Operator", "member": "Thành viên"}
DEFAULT_TEAMS = [{"id": "sso", "name": "SSO", "is_default": True}]  # a server from before teams
MEMBER_SETTINGS = {"language", "ui_lang", "nav_mini", "ui_zoom", "auto_update_check", "last_seen_version", "layouts"}


def lead_only(fn):
    """Refused in Member mode, and before sign-in in the app (enforced here, not only hidden in the UI)."""
    @functools.wraps(fn)
    def wrapper(self, *a, **k):
        if self._role() == "member":
            raise PermissionError(LEAD_ONLY)
        if self._require_login and not (self._role() in STAFF and self._secrets().get("session")):
            raise PermissionError(SIGN_IN_FIRST)
        return fn(self, *a, **k)
    return wrapper


ADS_TTL = 600  # s: product ads read on expand are reused for an ASIN on/off this long
OPERATOR_VIEW = "Operator chỉ xem báo cáo Lead đã tải lên – chạy dữ liệu và chỉnh logic là việc của Lead"


def runner_only(fn):
    """Lead only: running, uploading, logic / style / lessons. Refused for Member and Operator."""
    @functools.wraps(fn)
    def wrapper(self, *a, **k):
        self._sync_role(max_age=60)
        if self._role() == "operator":
            raise PermissionError(OPERATOR_VIEW)
        return lead_only(fn)(self, *a, **k)
    return wrapper


ACCOUNTS_LEAD = "Chỉ Admin / Team Lead được xem và quản lý tài khoản"
ADMIN_ONLY = "Chỉ Admin được làm việc này"


def team_lead_only(fn):
    """Accounts: the Admin (every team) or a Team Lead (its own team – the server enforces the scope)."""
    @functools.wraps(fn)
    def wrapper(self, *a, **k):
        if self._role() == "operator":
            raise PermissionError(ACCOUNTS_LEAD)
        return lead_only(fn)(self, *a, **k)
    return wrapper


def admin_only(fn):
    """The Admin alone: feedback review, teams."""
    @functools.wraps(fn)
    def wrapper(self, *a, **k):
        if self._role() in ("operator", "team_lead"):
            raise PermissionError(ADMIN_ONLY)
        return lead_only(fn)(self, *a, **k)
    return wrapper


def _error(e: Exception, message: str) -> dict:
    """UI error: the message, plus where to fix it (file › sheet › cells) and the run step that failed, if known."""
    out = {"error": message}
    for k in ("location", "step"):
        if getattr(e, k, None):
            out[k] = getattr(e, k)
    return out


FEEDBACK_MAX_FILES, FEEDBACK_MAX_BYTES = 5, 10 * 1024 * 1024
_OLE, _ZIP = b"\xd0\xcf\x11\xe0", b"PK\x03\x04"
# Allowed attachments: extension → (content type, leading bytes; None = plain text, no NUL bytes).
FEEDBACK_TYPES = {
    "png": ("image/png", b"\x89PNG"), "jpg": ("image/jpeg", b"\xff\xd8\xff"), "jpeg": ("image/jpeg", b"\xff\xd8\xff"),
    "webp": ("image/webp", b"RIFF"), "gif": ("image/gif", b"GIF8"), "pdf": ("application/pdf", b"%PDF"),
    "docx": ("application/vnd.openxmlformats-officedocument.wordprocessingml.document", _ZIP),
    "xlsx": ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", _ZIP),
    "pptx": ("application/vnd.openxmlformats-officedocument.presentationml.presentation", _ZIP),
    "zip": ("application/zip", _ZIP), "doc": ("application/msword", _OLE), "xls": ("application/vnd.ms-excel", _OLE),
    "ppt": ("application/vnd.ms-powerpoint", _OLE), "csv": ("text/csv", None), "txt": ("text/plain", None),
    "log": ("text/plain", None), "md": ("text/markdown", None), "json": ("application/json", None),
}
FEEDBACK_IMAGES = {"png", "jpg", "jpeg", "webp", "gif"}


def _profile_ids(text) -> list[str]:
    """"123, 456" / "123 456" / "123;456" → ["123", "456"]; None / "" → []."""
    return [x for x in re.split(r"[\s,;]+", str(text or "")) if x]


def _feedback_ext(name: str) -> str:
    return str(name).rsplit(".", 1)[-1].lower() if "." in str(name) else ""


def _feedback_file(item: dict) -> tuple[str, bytes]:
    """{name, data: data URL} → (storage-safe file name, bytes); rejects other types, oversize and mislabelled files."""
    name, data = str(item.get("name") or ""), str(item.get("data") or "")
    ext = _feedback_ext(name)
    if ext not in FEEDBACK_TYPES:
        raise ValueError(f"Không đính kèm được {name or 'tệp này'} – chỉ nhận ảnh, PDF, Word, Excel, PowerPoint, CSV, TXT, ZIP")
    head, _, b64 = data.partition(",")
    try:
        if not (head.startswith("data:") and head.endswith(";base64")):
            raise ValueError
        blob = base64.b64decode(b64, validate=True)
    except ValueError:
        raise ValueError(f"{name}: tệp bị lỗi – chọn lại") from None
    if len(blob) > FEEDBACK_MAX_BYTES:
        raise ValueError(f"{name}: quá lớn (tối đa {FEEDBACK_MAX_BYTES // 1024 // 1024} MB)")
    magic = FEEDBACK_TYPES[ext][1]
    if not blob or (blob[:4096].count(b"\x00") if magic is None else not blob.startswith(magic)):
        raise ValueError(f"{name}: nội dung không đúng loại tệp")
    stem = unicodedata.normalize("NFKD", name.rsplit(".", 1)[0].replace("đ", "d").replace("Đ", "D"))
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", stem.encode("ascii", "ignore").decode()).strip("._")[:80] or "file"
    return f"{stem}.{ext}", blob


def _finite(o):
    """NaN / inf → None. pywebview hands results to JS's JSON.parse, which rejects NaN: the call's promise then
    never settles and the page waits forever (e.g. Performance Review stuck on "Đang tính…")."""
    if isinstance(o, float):
        return o if math.isfinite(o) else None
    if isinstance(o, dict):
        return {k: _finite(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_finite(v) for v in o]
    return o


def safe(fn):
    @functools.wraps(fn)
    def wrapper(self, *a, **k):
        try:
            return _finite(fn(self, *a, **k))
        except (InputError, LogicError, ClaudeError, CognixError, SharePointError, ValueError, RuntimeError, PermissionError, PackageError,
                TeamError) as e:
            return _error(e, str(e))
        except Exception as e:  # never let a traceback reach the UI
            self._log(traceback.format_exc())
            return _error(e, f"Lỗi không mong đợi: {e} (chi tiết: {self._home.base / 'error.log'})")
    return wrapper


class Api:
    def __init__(self, store: Store, ask_fn=ask, status_fn=check_status, release_fn=latest_release,
                 recent_fn=recent_releases, tag_fn=latest_tag, sb_opener=urllib.request.urlopen, require_login: bool = False):
        self._home = store  # the person's own store: sign-in, settings, style – and the default team's data
        self._store, self._status = store, status_fn  # the work team's data (runs, logic, history...): see _use_team
        self._workspaces: dict[str, Store] = {}
        self._ask = self._with_note(ask_fn)
        self._release, self._recent, self._tag = release_fn, recent_fn, tag_fn
        self._window = None
        self._cancel = threading.Event()  # the current run's cancel event (set by cancel_run(); each run has its own)
        self._live: _RunCtx | None = None  # the run in progress – None once it ends or Stop is pressed
        self._commit = threading.Lock()  # a run's saves vs. cancel_run(): a stopped run never saves after the Stop
        self._running = False
        self._inputs = None
        self._paths: list[str] = []
        self._eta: Eta | None = None  # time-left estimate of the run in progress
        self._step = ""  # step of the run in progress (named in errors)
        self._member: dict | None = None  # Member mode: the opened .pmkt (run, inputs, logic path, file)
        self._require_login = require_login  # the app: nothing works before sign-in (tests: off)
        self._sb_opener, self._sb_cache = sb_opener, None  # Supabase HTTP opener (tests: a fake), signed-in client
        self._synced_at = float("-inf")  # last check (monotonic() starts near 0 after boot) of this account's role / PIC on the server
        self._startup_file: str | None = None  # a .pmkt double-clicked to start the app
        self._deck: dict | None = None  # the presentation being edited / shown (with its facts; the UI gets it without)
        self._show = {"i": 0, "pop": None}  # what the audience sees: slide index + open popup
        self._audience = None  # full-screen slide window on the external monitor while presenting
        self._full = False  # one screen: the main window went full-screen for the show
        self._hr: tuple | None = None  # Hourly tab: ((path, mtime_ns, size), parsed hourly frame)
        self._hr_lock = threading.Lock()  # one read of the hourly workbook at a time (~15 s)
        self._hr_searched = False  # the OneDrive / Downloads search for the hourly file ran this session
        self._hr_dl = threading.Lock()  # one SharePoint download of the hourly file at a time
        self._hr_fetched, self._hr_err = float("-inf"), None  # last SharePoint download (monotonic) and its error
        self._hr_shared: tuple | None = None  # viewers: (signature, frame, meta) of the Lead's last hourly push read
        self._hr_push = threading.Lock()  # Lead: one hourly push at a time
        self._ads: Cognix | None = None  # Ads tool session shared by the on/off calls (one refresh-token rotation at a time)
        self._activity_skipped: list[str] = []  # the last Activity Log fetch's profiles that failed (the others merged)
        self._ads_lock = threading.Lock()
        self._ads_ids: dict[str, str] = {}  # Amazon campaign id → the Ads tool's own campaign id
        self._ads_prod: dict[str, tuple] = {}  # Amazon campaign id → (monotonic time, its product ads) read on expand
        self._use_team()

    # ------------------------------------------------------------- helpers
    def _with_note(self, ask_fn):
        """Every Claude request starts with the user's note from Settings."""
        def ask_with_note(prompt: str, schema: dict) -> dict:
            note = (self._store.get_settings().get("claude_note") or "").strip()
            prefix = f"GHI CHÚ CỦA NGƯỜI DÙNG (bắt buộc tuân theo, ưu tiên hơn mọi gợi ý khác):\n{note}\n\n" if note else ""
            return ask_fn(prefix + prompt, schema)
        return ask_with_note

    def _log(self, text: str) -> None:
        with open(self._home.base / "error.log", "a", encoding="utf-8") as f:
            f.write(f"--- {datetime.now().isoformat()}\n{text}\n")

    def _progress(self, step: str, state: str, detail: str = "", call_finished: bool = False, run_id: str | None = None,
                  ctx: _RunCtx | None = None) -> None:
        """ctx: the run reporting – dropped when that run was stopped (or a newer run started)."""
        if ctx is not None and ctx is not self._live:
            return
        if state == "running" and ":" not in step and step != "review":
            self._step = step
        eta = self._eta
        if eta is not None:
            if call_finished:
                eta.calls_done()
            elif ":" not in step and step != "review":
                (eta.start if state == "running" else eta.done)(step)
        if self._window is not None:
            extra = {"eta": round(eta.remaining()) if eta else None}
            if run_id:  # rules saved: the UI starts Performance Review now, alongside the Claude step
                extra["run_id"] = run_id
            self._window.evaluate_js(f"window.onProgress && onProgress({json.dumps(step)}, {json.dumps(state)}, "
                                     f"{json.dumps(detail)}, {json.dumps(extra)})")

    # ------------------------------------------------------------- team (Supabase) & sharing
    def _role(self) -> str | None:
        return self._store.get_settings().get("role")

    def _viewer(self) -> bool:
        return self._role() in VIEWERS

    def _team(self) -> dict:
        return self._store.get_settings().get("team") or {}

    def _secrets(self) -> dict:
        p = self._home.base / "secrets.bin"
        return json.loads(unprotect(p.read_bytes())) if p.exists() else {}

    def _save_secrets(self, d: dict) -> None:
        p = self._home.base / "secrets.bin"
        write_atomic(p, protect(json.dumps(d).encode("utf-8")))
        try:
            p.chmod(0o600)
        except OSError:
            pass

    def _keys(self, email: str | None = None) -> dict:
        return (self._secrets().get("keys") or {}).get(email or self._team().get("email") or "", {})

    def _save_keys(self, email: str, keys: dict) -> None:
        sec = self._secrets()
        sec.setdefault("keys", {})[email] = keys
        self._save_secrets(sec)

    def _lead_keys(self) -> LeadKeys:
        raw = self._keys().get("lead")
        if not raw:
            if self._role() == "operator":
                raise PermissionError("Máy này chưa có khoá đọc báo cáo của bạn – đăng xuất rồi đăng nhập lại (Cài đặt → Nhóm)")
            raise PermissionError("Máy này chưa có khoá ký của Lead – đăng nhập một lần trên máy cũ bằng bản app mới (khoá sẽ "
                                  "tự theo tài khoản), hoặc nhập file khoá Lead / tạo khoá mới (Cài đặt → Nhóm)")
        return LeadKeys.from_bytes(base64.b64decode(raw))

    def _my_reader_key(self):
        if self._role() in STAFF:
            return self._lead_keys().enc_private
        raw = self._keys().get("member")
        if not raw:
            raise PermissionError("Chưa đăng nhập nhóm (Cài đặt → Nhóm)")
        return MemberKey.from_bytes(base64.b64decode(raw)).private

    def _server(self) -> tuple[str, str]:
        t, b = self._team(), _bundled_team()
        return (t.get("url") or b.get("url") or "", t.get("anon") or b.get("anon") or "")

    def _sb(self) -> Supabase:
        """Signed-in client; the access token is refreshed at most every 45 minutes."""
        sb_cfg = self._server()
        if self._sb_cache and self._sb_cache[0] == sb_cfg and time.monotonic() - self._sb_cache[1] < 45 * 60:
            return self._sb_cache[2]
        session = self._secrets().get("session")
        if not session or not sb_cfg[0]:
            raise PermissionError("Chưa đăng nhập nhóm (Cài đặt → Nhóm)")
        sb = Supabase(*sb_cfg, opener=self._sb_opener)
        try:
            new_rt = sb.refresh(session["refresh"])
        except TeamError as e:
            raise PermissionError(f"Phiên đăng nhập đã hết hạn – đăng nhập lại ({e})") from None
        self._save_secrets({**self._secrets(), "session": {**session, "refresh": new_rt}})
        self._sb_cache = (sb_cfg, time.monotonic(), sb)
        return sb

    def _lead_signs(self, sb: Supabase | None = None) -> list:
        """Public signing keys of the active Leads (members may read Lead rows); cached for offline file opens."""
        try:
            sb = sb or self._sb()
            signs = [r["sign_pub"] for r in sb.members() if r["role"] in RUNNERS and r["active"] and r.get("sign_pub")]
            self._store.save_settings({"team": {**self._team(), "lead_signs": signs}})
        except (PermissionError, TeamError):
            signs = self._team().get("lead_signs") or []
        return [Ed25519PublicKey.from_public_bytes(base64.b64decode(x)) for x in signs]

    def _register_device(self, sb: Supabase, row: dict, email: str) -> bool:
        """Create/keep this device's keys and publish their public halves. Returns needs_key (Lead without the
        signing key the team trusts: import the Lead key file or reset it; a Team Lead too). An Operator only reads – it never signs
        (upload / hourly / reshare are the Lead's) – so a computer without its key just gets a new one, like a Member's;
        the server keeps the Operator's first signing key and the Lead's app adds the new key to recent reports."""
        keys = self._keys(email)
        if row["role"] in STAFF:
            lead_role = row["role"] in RUNNERS
            if not keys.get("lead"):
                if lead_role and row.get("sign_pub"):
                    return True
                keys = {**keys, "lead": base64.b64encode(LeadKeys.new().to_bytes()).decode()}
                self._save_keys(email, keys)
            lead = LeadKeys.from_bytes(base64.b64decode(keys["lead"]))
            sign = _pub64(lead.sign_public)
            if lead_role and row.get("sign_pub") not in (None, sign):
                return True
            sb.register_keys(_pub64(lead.enc_public), sign)
            return False
        if not keys.get("member"):
            keys = {**keys, "member": base64.b64encode(MemberKey.new().to_bytes()).decode()}
            self._save_keys(email, keys)
        sb.register_keys(_pub64(MemberKey.from_bytes(base64.b64decode(keys["member"])).public), None)
        return False

    def _read_blob(self, blob: bytes) -> tuple[dict, dict[str, bytes]]:
        """(meta, files) of a .pmkt signed by one of the team's Leads and readable with this device's key."""
        key, err = self._my_reader_key(), None
        for sign in self._lead_signs():
            try:
                return read_package(blob, key, sign)
            except PackageError as e:
                err = e
                if "chữ ký" not in str(e):
                    raise
        raise err or PackageError("Chưa có khoá ký của Lead – đăng nhập nhóm trước")

    def _open_blob(self, blob: bytes, name: str) -> dict:
        meta, files = self._read_blob(blob)
        run, inputs, logic_bytes, logic_name = unpack_run(files)
        logic_path = self._store.base / "shared" / logic_name
        logic_path.parent.mkdir(parents=True, exist_ok=True)
        logic_path.write_bytes(logic_bytes)
        if self._viewer():
            self._member = {"run": {**run, "file": name, "published_by": meta.get("by"), "published_at": meta.get("at"),
                                    "as_of_meta": meta.get("as_of")}, "inputs": inputs, "logic_path": logic_path}
            return self._member
        return {"run": {**run, "file": name, "published_by": meta.get("by"), "published_at": meta.get("at")}}

    def _teams(self) -> list[dict]:
        """The server's teams (cached: offline / a server from before teams → the one default team)."""
        return self._team().get("teams") or DEFAULT_TEAMS

    def _default_team(self) -> str:
        return next((t["id"] for t in self._teams() if t.get("is_default")), self._teams()[0]["id"])

    def _load_teams(self, sb: Supabase) -> None:
        try:
            teams = sb.teams() or DEFAULT_TEAMS
        except TeamError:
            teams = DEFAULT_TEAMS
        self._store.save_settings({"team": {**self._team(), "teams": teams}})

    def _work_team(self) -> str:
        """The team whose reports this computer uploads and reads: a Team Lead's / Operator's / Member's own team; the
        Admin's picked team (default: the default team)."""
        if self._role() == "lead":
            picked = self._store.get_settings().get("work_team")
            return picked if any(t["id"] == picked for t in self._teams()) else self._default_team()
        return self._team().get("team") or self._default_team()

    def _use_team(self) -> None:
        """Point the data store at the work team's workspace: the default team's data stays in the person's own store
        (as before teams), another team's in teams/<id>/. Whatever was loaded for another team is dropped."""
        team = self._work_team() if self._role() in RUNNERS else self._default_team()
        ws = self._home if team == self._default_team() else self._workspaces.setdefault(
            team, Store(self._home.base / "teams" / team, home=self._home))
        if ws is self._store:
            return
        self._store = ws
        self._inputs, self._paths, self._member, self._deck = None, [], None, None
        self._hr, self._hr_shared, self._hr_searched = None, None, False
        self._ads_ids, self._ads_prod = {}, {}

    @safe
    @admin_only
    def set_work_team(self, team: str) -> dict:
        """Admin: the team this computer runs, uploads and reads reports for (each team keeps its own data here)."""
        if self._running:
            raise RuntimeError("Đang chạy dữ liệu – chờ xong rồi đổi nhóm")
        if not any(t["id"] == team for t in self._teams()):
            raise ValueError("Không có nhóm này")
        self._store.save_settings({"work_team": team})
        self._use_team()
        return self.team_info()

    @safe
    @admin_only
    def team_set_ads_profile(self, team: str, profile: str) -> dict:
        """Admin: the Ads profile(s) a team's campaigns live in (on/off, budget, Activity Log) – kept on the server, so
        the team's Team Lead and Operators get it too. Several profiles: numbers separated by commas."""
        ids = _profile_ids(profile)
        if any(not x.isdigit() for x in ids):
            raise ValueError("Ads profile là một dãy số (nhiều profile: cách nhau bằng dấu phẩy)")
        profile = ",".join(dict.fromkeys(ids))
        sb = self._sb()
        sb.update_team(team, {"ads_profile": profile or None})
        self._load_teams(sb)
        self._ads_ids, self._ads_prod = {}, {}
        return self.team_info()

    def _layout(self) -> Layout:
        """The work team's input files (names, sheets, shapes)."""
        return layout_of(self._work_team())

    def _folder_name(self, team: str, now: datetime, seconds: bool = False) -> str:
        """PMKT-Alert_<date> for the default team (as before teams – older apps keep reading it), else
        PMKT-Alert-<TEAM>_<date>."""
        stamp = f"{now:%Y-%m-%d_%H-%M-%S}" if seconds else f"{now:%Y-%m-%d_%H-%M}"
        return f"PMKT-Alert_{stamp}" if team == self._default_team() else f"PMKT-Alert-{team.upper()}_{stamp}"

    def _team_reports(self, sb: Supabase) -> list[str]:
        """The work team's report folders, newest first (an Admin sees every team's on the server)."""
        team, default = self._work_team(), self._default_team()
        return [n for n in sb.reports() if folder_team(n, default) == team]

    def _readers(self, rows: list[dict], lead: LeadKeys):
        return _report_readers(rows, lead, self._work_team(), self._default_team())

    def _report_path(self, name: str) -> str:
        if self._role() in STAFF:
            return f"{name}/{LEAD_FILE}"
        return f"{name}/{pic_file(self._team().get('pic') or '')}"

    def _member_state(self) -> dict:
        if self._member:
            return self._member
        reports = self._team_reports(self._sb())
        if not reports:
            raise ValueError("Chưa có báo cáo nào – chờ Lead tải lên")
        return self._open_blob(self._sb().download(self._report_path(reports[0])), reports[0])

    @safe
    def team_info(self) -> dict:
        t, st = self._team(), self._store.get_settings()
        url, anon = self._server()
        out = {"url": url, "configured": bool(url and anon), "bundled": bool(_bundled_team()), "signed_in": bool(self._secrets().get("session")), "role": st.get("role"),
               **{k: t.get(k) for k in ("email", "pic", "name", "team")}, "needs_key": bool(t.get("needs_key")),
               "teams": [{k: x.get(k) for k in ("id", "name", "is_default", "ads_profile")} for x in self._teams()]}
        if out["signed_in"]:
            out["work_team"] = self._work_team()
            lay = self._layout()
            out["files"] = {"team": lay.name, "guide": list(lay.guide), "hourly": lay.hourly_file, "data_file": lay.data_file,
                            "raw": lay.sheets["raw"], "products": lay.sheets["products"], "ads": lay.ads_sheets[0],
                            "keepa": lay.keepa}
        if self._member:
            out["opened"] = {k: self._member["run"].get(k) for k in ("file", "published_by", "published_at")}
        return out

    @safe
    def team_connect(self, url: str = "", anon: str = "") -> dict:
        bundled = _bundled_team()
        t = self._team()
        url = (url or t.get("url") or bundled.get("url") or "").strip()
        anon = (anon or (t.get("anon") if url == t.get("url") else None) or bundled.get("anon") or "").strip()
        Supabase(url, anon)  # validates
        self._store.save_settings({"team": {**self._team(), "url": url, "anon": anon}})
        self._sb_cache = None
        return self.team_info()

    @safe
    def team_sign_in(self, email: str, password: str) -> dict:
        url, anon = self._server()
        if not url:
            raise ValueError("App chưa có máy chủ nhóm – cập nhật app lên bản mới nhất")
        email = email.strip().lower()
        sb = Supabase(url, anon, opener=self._sb_opener)
        refresh = sb.sign_in(email, password)
        if (self._team().get("email") or "").lower() not in ("", email):
            self._drop_logins()  # another person than last time (e.g. the session ran out without signing out)
        row = sb.member(email)
        if not row or not row["active"]:
            raise PermissionError("Tài khoản này chưa được Lead kích hoạt")
        self._save_secrets({**self._secrets(), "session": {"email": email, "refresh": refresh}})
        self._sb_cache = ((url, anon), time.monotonic(), sb)
        self._restore_keys(sb, row, email, password)  # another computer of this account: its keys come along
        needs_key = self._register_device(sb, row, email)
        if not needs_key:
            self._backup_keys(sb, email, password)
        self._member = None
        self._store.save_settings({"role": row["role"], "team": {**self._team(), "email": email, "pic": row.get("pic"),
                                                                  "name": row.get("name"), "team": row.get("team"),
                                                                  "needs_key": needs_key}})
        self._load_teams(sb)
        self._use_team()
        self._lead_signs(sb)
        return self.team_info()

    @safe
    def team_change_password(self, password: str) -> dict:
        if len(password or "") < 10:
            raise ValueError("Mật khẩu cần ít nhất 10 ký tự")
        sb = self._sb()
        sb.change_password(password)
        email = (self._team().get("email") or "").lower()
        if email and not self._team().get("needs_key"):
            self._backup_keys(sb, email, password)  # the old copy only opens with the old password
        return {"ok": True}

    def _restore_keys(self, sb: Supabase, row: dict, email: str, password: str) -> None:
        """No key on this computer for what the account needs (Lead / Operator: the signing key; Member: a device
        key) → take them from the server backup, unlocked with the password just typed. Keys already here win."""
        mine = self._keys(email)
        if mine.get("lead" if row["role"] in STAFF else "member"):
            return
        try:
            keys = keybackup.unlock(sb.key_backup(), password, email)
        except TeamError as e:  # offline, or the server has no backup table yet: carry on as before
            self._log(f"key backup: {e}")
            return
        if keys:
            self._save_keys(email, {**keys, **mine})

    def _backup_keys(self, sb: Supabase, email: str, password: str) -> None:
        """Keep the server copy of this account's keys current and locked with the current password (re-locks after
        a password change or a Lead reset; uploads keys new on this computer). Never blocks signing in."""
        keys = self._keys(email)
        if not keys:
            return
        try:
            if keybackup.unlock(sb.key_backup(), password, email) == keys:
                return
            sb.save_key_backup(keybackup.lock(keys, password, email))
        except TeamError as e:
            self._log(f"key backup: {e}")

    def _sync_role(self, max_age: float = 0) -> dict:
        """Re-read this account on the server; apply a role / PIC / name change or a lock. Offline → keep as is."""
        email = (self._team().get("email") or "").lower()
        if not email or not self._secrets().get("session") or time.monotonic() - self._synced_at < max_age:
            return {"changed": False}
        try:
            sb = self._sb()
            row = sb.member(email)
        except (PermissionError, TeamError) as e:
            if "khoá" not in str(e):  # offline / server hiccup / expired session: leave it to the normal flow
                return {"changed": False}
            row = None  # banned by the Lead (Khoá)
        self._synced_at = time.monotonic()
        if row and row["active"]:
            self._load_teams(sb)  # teams added / renamed by the Admin
        if not row or not row["active"]:
            self.team_sign_out()
            return {"changed": True, "signed_out": True, "message": "Tài khoản đã bị Lead khoá hoặc xoá – bạn đã được đăng xuất"}
        old = {"role": self._role(), "pic": self._team().get("pic"), "name": self._team().get("name"), "team": self._team().get("team")}
        new = {"role": row["role"], "pic": row.get("pic"), "name": row.get("name"), "team": row.get("team")}
        if old == new:
            return {"changed": False}
        needs_key = self._register_device(sb, row, email) if new["role"] != old["role"] else self._team().get("needs_key", False)
        self._member = None  # the opened report may no longer be readable (other PIC / role / team)
        self._store.save_settings({"role": new["role"], "team": {**self._team(), **{k: new[k] for k in ("pic", "name", "team")},
                                                                 "needs_key": needs_key}})
        self._use_team()
        label = {"lead": "Admin", "team_lead": "Team Lead", "operator": "Operator (xem mọi PIC)",
                 "member": f"Thành viên · PIC {new['pic'] or '—'}"}
        tname = next((t["name"] for t in self._teams() if t["id"] == new["team"]), (new["team"] or "").upper())
        msg = (f"Lead đã đổi vai trò của bạn thành {label.get(new['role'], new['role'])}" if new["role"] != old["role"]
               else f"Lead đã chuyển bạn sang nhóm {tname}" if new["team"] != old["team"]
               else f"Lead đã đổi PIC của bạn thành {new['pic'] or '—'}" if new["pic"] != old["pic"] else "")
        return {"changed": True, "role_changed": new["role"] != old["role"], "old_role": old["role"],
                "role": new["role"], "message": msg}

    @safe
    def team_sync(self) -> dict:
        """Called by the page at start, on focus and every few minutes."""
        return self._sync_role()

    @safe
    def team_sign_out(self) -> dict:
        self._sign_out()
        return self.team_info()

    def _sign_out(self) -> None:
        """End the team session and the other logins saved on this computer (Ads / Activity Log, SharePoint): the
        next person signs in to those with their own account. The account's device keys stay (team_forget_device)."""
        try:
            self._sb().sign_out()
        except (PermissionError, TeamError):
            pass
        sec = self._secrets()
        sec.pop("session", None)
        self._save_secrets(sec)
        self._drop_logins()
        self._sb_cache, self._member, self._synced_at = None, None, float("-inf")
        self._store.save_settings({"role": None})
        self._use_team()

    def _drop_logins(self) -> None:
        """Forget the Ads and SharePoint sessions, and the login windows' browser cookies - otherwise the next login
        window would sign straight back in as the previous person."""
        self._drop_ads()
        sec = self._secrets()
        if sec.pop("sharepoint", None) is not None:
            self._save_secrets(sec)
        if self._window is not None:
            try:
                self._window.clear_cookies()
            except Exception as e:  # never blocks signing out
                self._log(f"clear cookies: {e}")

    @safe
    def team_forget_device(self, password: str) -> dict:
        """Sign out and remove this account's keys from this computer (shared PCs). Only once the server backup is
        confirmed to open with the account's password - signing in again brings the keys back; a Lead never loses the
        team's signing key this way."""
        email = (self._team().get("email") or "").lower()
        if not email or not self._secrets().get("session"):
            raise PermissionError("Chưa đăng nhập nhóm (Cài đặt → Nhóm)")
        keys = self._keys(email)
        if keys:
            url, anon = self._server()
            check = Supabase(url, anon, opener=self._sb_opener)
            try:
                check.sign_in(email, password or "")  # the password itself, not just this computer's session
            except TeamError:
                raise ValueError("Sai mật khẩu") from None
            try:
                check.sign_out()
            except TeamError:
                pass
            sb = self._sb()
            self._backup_keys(sb, email, password)
            try:
                ok = keybackup.unlock(sb.key_backup(), password, email) == keys
            except TeamError:
                ok = False
            if not ok:
                raise ValueError("Chưa lưu được bản sao khoá lên máy chủ – giữ khoá trên máy này. Thử lại khi có mạng.")
        self._sign_out()
        sec = self._secrets()
        (sec.get("keys") or {}).pop(email, None)
        self._save_secrets(sec)
        self._store.save_settings({"team": {k: v for k, v in self._team().items()
                                            if k not in ("email", "pic", "name", "needs_key", "lead_signs")}})
        return self.team_info()

    @safe
    @team_lead_only
    def members(self) -> dict:
        rows = self._sb().members()
        if self._role() == "team_lead":  # it also reads the Admins' rows (signing keys): not its accounts to manage
            rows = [r for r in rows if r.get("team") == self._team().get("team")]
        for r in rows:
            r["status"] = "disabled" if not r["active"] else "ready" if r.get("enc_keys") else "invited"
            r.pop("enc_keys", None)
        return {"members": rows}

    @safe
    @team_lead_only
    def add_member(self, email: str, name: str, pic: str, role: str = "member", team: str | None = None) -> dict:
        """Create a login + member row (inside Supabase). Returns the first password to hand over. A Team Lead creates
        Operators / Members of its own team; the Admin any role in any team (the server enforces both)."""
        email = email.strip().lower()
        if not EMAIL_RE.fullmatch(email):
            raise ValueError("Email không hợp lệ")
        if role not in (*STAFF, "member") or (role == "member" and not pic.strip()):
            raise ValueError("Thành viên cần có PIC")
        if self._role() == "team_lead":
            if role in RUNNERS:
                raise PermissionError("Team Lead chỉ tạo Operator / Thành viên trong nhóm của mình")
            team = self._team().get("team")
        elif role == "lead":
            team = None
        elif not team:
            team = self._default_team()
        elif not any(t["id"] == team for t in self._teams()):
            raise ValueError("Không có nhóm này")
        password = _new_password()
        self._sb().admin("create", email=email, name=name.strip() or email, role=role,
                         pic=pic.strip() if role == "member" else None, team=team, password=password)
        return {**self.members(), "password": password}

    @safe
    @team_lead_only
    def reset_password(self, email: str) -> dict:
        password = _new_password()
        self._sb().admin("reset_password", email=email, password=password)
        return {"password": password}

    @safe
    @team_lead_only
    def update_member(self, email: str, fields: dict) -> dict:
        sb = self._sb()
        if "active" in fields:
            sb.admin("set_active", email=email, active=bool(fields["active"]))
        allowed = ("pic", "name", "role", "team") if self._role() == "lead" else ("pic", "name", "role")
        clean = {k: v for k, v in fields.items() if k in allowed}
        if self._role() == "team_lead" and clean.get("role") in RUNNERS:
            raise PermissionError("Team Lead chỉ đổi giữa Operator và Thành viên")
        if clean:
            sb.update_member(email, clean)
        return self.members()

    @safe
    @team_lead_only
    def remove_member(self, email: str) -> dict:
        self._sb().admin("delete", email=email)
        return self.members()

    @safe
    @runner_only
    def upload_report(self, run_id: str | None = None) -> dict:
        """Lead, after reviewing a run: one file per PIC (encrypted for that PIC's members) + the full file for
        Leads, all signed, uploaded under PMKT-Alert_<date>_<time>/."""
        sb = self._sb()
        lead = self._lead_keys()
        me = sb.member(self._team().get("email") or "")
        if not me or me.get("sign_pub") != _pub64(lead.sign_public):
            raise PermissionError("khoá Lead trên máy này không còn là khoá của nhóm – nhập file khoá Lead mới")
        run = self._store.load_run(run_id) if run_id else self._latest()
        if not run:
            raise ValueError("Không tìm thấy lần chạy")
        rows = [r for r in sb.members() if r["active"]]
        readers, counts, other_leads = self._readers(rows, lead)
        logic_path = self._run_logic_path(run["result"])
        sc = scorecard(run["result"], self._store.get_settings().get("score_weights") or {})
        # Viewers have no local runs: ship the "today" listing baseline and the listing history with the report
        run = {**run, "prev_listing": self._prev_listing(run), "listing_history": self._store.listing_history(),
               "keepa_history": self._store.keepa_history()}
        parts = build_parts(run, self._ensure_inputs(), logic_path, list(readers), {p["pic"]: p for p in sc["pics"]})
        now = datetime.now()
        meta = {"by": self._team().get("name") or "Lead", "at": now.isoformat(timespec="seconds"),
                "as_of": run["result"]["as_of"], "app": __version__}
        team = self._work_team()
        name = self._folder_name(team, now)
        if name in set(sb.reports()):
            name = self._folder_name(team, now, seconds=True)
        size = 0
        for path, part, who in [(LEAD_FILE, "lead", other_leads)] + [(pic_file(p), f"pic:{p}", readers[p]) for p in readers]:
            blob = build_package({part: (parts[part], who)}, meta, lead)
            sb.upload(f"{name}/{path}", blob)
            size += len(blob)
        pics = {d["pic"] for d in run["result"]["digest"]}
        self._store.save_run_field(run["run_id"], "uploaded", (run.get("uploaded") or []) + [name])
        waiting = sorted(r["email"] for r in rows if r["role"] == "member" and not r.get("enc_keys")
                         and _in_team(r, team, self._default_team()))
        return {"team": team, "name": name, "size": size, "readers": counts, "no_readers": sorted(pics - set(counts)), "waiting": waiting}

    @safe
    @runner_only
    def reshare_reports(self, limit: int = 10) -> dict:
        """Feedback #1: a device that signed in after an upload had no key in it. The Lead's app (on start / sync)
        wraps the part keys of the latest reports for those devices – no re-upload. Files are only downloaded when
        the set of devices that should read them changed since the last check."""
        sb, lead = self._sb(), self._lead_keys()
        pub = lambda k: X25519PublicKey.from_public_bytes(base64.b64decode(k))  # noqa: E731
        team, default = self._work_team(), self._default_team()
        rows = [r for r in sb.members() if r["active"] and _in_team(r, team, default)]
        want = {LEAD_FILE: [pub(k) for r in rows if r["role"] in STAFF for k in r.get("enc_keys") or []
                            if k != _pub64(lead.enc_public)]}
        for r in rows:
            if r["role"] == "member" and r.get("pic"):
                want.setdefault(pic_file(r["pic"]), []).extend(pub(k) for k in r.get("enc_keys") or [])
        seen, checked, fixed, failed = self._store.get_settings().get("reshared") or {}, {}, [], []
        signers = None  # other Leads' / Team Leads' signing keys, fetched once and only when a file needs a change
        for name in self._team_reports(sb)[:limit]:
            for f in sb.files(f"{name}/"):
                path, readers = f"{name}/{f.get('name')}", want.get(f.get("name"), [])
                ids = sorted(reader_id(k) for k in readers)
                if not readers or seen.get(path) == ids:
                    checked[path] = ids
                    continue
                if signers is None:
                    signers = self._lead_signs(sb)
                # Feedback #75: a file another Lead signed (Admin resharing a Team Lead's upload, an old key) used
                # to stop the whole loop – later reports never got the new devices and the Operator couldn't open
                # them. Skip that file (not marked checked: retried next sync) and keep going.
                try:
                    old = sb.download(path)
                    new = add_readers(old, lead, readers, signers)
                except PackageError as e:
                    self._log(f"reshare {path}: {e}")
                    failed.append(path)
                    continue
                checked[path] = ids
                if new:
                    sb.replace(path, new, old)
                    fixed.append(path)
        self._store.save_settings({"reshared": checked})
        return {"fixed": fixed, "failed": failed}

    def _my_opens(self) -> dict[str, str]:
        """{report: last time I opened it}; empty when the server has no opens table yet."""
        try:
            return {r["report"]: r["last_opened_at"] for r in self._sb().report_opens()
                    if r["email"] == (self._team().get("email") or "").lower()}
        except TeamError:
            return {}

    @safe
    def list_reports(self) -> dict:
        mine = self._my_opens()
        return {"reports": [{"name": n, "opened_at": mine.get(n)} for n in self._team_reports(self._sb())]}

    @safe
    def open_report(self, name: str) -> dict:
        run = self._open_blob(self._sb().download(self._report_path(name)), name)["run"]
        if self._viewer():  # the Lead sees who opened what (best effort – never blocks opening)
            try:
                self._sb().record_open(name, (self._team().get("email") or "").lower(),
                                       datetime.now().astimezone().isoformat(timespec="seconds"))
            except TeamError:
                pass
        return run

    @safe
    def save_report(self, name: str, path: str | None = None) -> dict:
        """Save the report file this person may open (still encrypted – only the right people can open it)."""
        if not name:
            raise ValueError("Chọn báo cáo trước")
        blob = self._sb().download(self._report_path(name))
        if not path:
            if self._window is None:
                raise RuntimeError("Chưa mở cửa sổ app")
            import webview
            picked = self._window.create_file_dialog(webview.FileDialog.SAVE, save_filename=f"{name}.pmkt")
            if not picked:
                return {"cancelled": True}
            path = picked if isinstance(picked, str) else picked[0]
        Path(path).write_bytes(blob)
        return {"path": str(path)}

    @safe
    def save_table(self, title: str, header: list, rows: list, path: str | None = None) -> dict:
        """Any role: save the rows a table shows right now (after its column filters / sort) as .xlsx."""
        if not path:
            if self._window is None:
                raise RuntimeError("Chưa mở cửa sổ app")
            import webview
            name = re.sub(r'[\\/:*?"<>|\s]+', " ", title or "").strip()[:80] or "PMKT Alert"
            picked = self._window.create_file_dialog(webview.FileDialog.SAVE, save_filename=f"{name} {date.today().isoformat()}.xlsx")
            if not picked:
                return {"cancelled": True}
            path = picked if isinstance(picked, str) else picked[0]
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        for r in [header, *rows]:
            ws.append([str(v) for v in r])
        for row in ws.iter_rows():
            for c in row:
                c.data_type = "s"  # table text like "=…" stays text, never a formula
        wb.save(path)
        return {"path": str(path)}

    @safe
    @runner_only
    def uploads_overview(self, limit: int = 20) -> dict:
        """Lead: the latest uploads with who could open each (a file for their PIC / Operator) and who did, when."""
        sb = self._sb()
        names = self._team_reports(sb)[:limit]
        team, default = self._work_team(), self._default_team()
        people = [r for r in sb.members() if r["active"] and r["role"] in VIEWERS and _in_team(r, team, default)]
        try:
            opens, opens_error = sb.report_opens(), None
        except TeamError:
            opens, opens_error = [], "Máy chủ nhóm chưa ghi lượt mở – Lead cần chạy lại SQL thiết lập"
        out = []
        for n in names:
            files = {f["name"] for f in sb.files(f"{n}/") if f.get("name") and f.get("id") and "/" not in f["name"]}
            readers = [p for p in people if p["role"] == "operator" or (p.get("pic") and pic_file(p["pic"]) in files)]
            seen = {o["email"]: o for o in opens if o["report"] == n}
            who = lambda p: {"email": p["email"], "name": p.get("name") or p["email"], "role": p["role"], "pic": p.get("pic")}  # noqa: E731
            out.append({"name": n, "pics": len(files - {LEAD_FILE}),
                        "opened": [{**who(p), "first": seen[p["email"]]["first_opened_at"], "last": seen[p["email"]]["last_opened_at"]}
                                   for p in readers if p["email"] in seen],
                        "not_opened": [who(p) for p in readers if p["email"] not in seen]})
        return {"reports": out, "opens_error": opens_error}

    @safe
    @runner_only
    def delete_report(self, name: str) -> dict:
        self._sb().delete_report(name)
        return {"ok": True}

    @safe
    @runner_only
    def export_lead_key(self, path: str | None, password: str) -> dict:
        if len(password or "") < 8:
            raise ValueError("Mật khẩu file khoá cần ít nhất 8 ký tự")
        raw = self._lead_keys().to_bytes()
        if not path:
            import webview
            picked = self._window.create_file_dialog(webview.FileDialog.SAVE, save_filename="PMKT-Lead.pmktkey")
            if not picked:
                return {"cancelled": True}
            path = picked if isinstance(picked, str) else picked[0]
        payload = json.dumps({"keys": base64.b64encode(raw).decode(), "email": self._team().get("email")}).encode()
        salt, nonce = os.urandom(16), os.urandom(12)
        Path(path).write_bytes(b"PMKTKEY3" + salt + nonce + AESGCM(_kdf(password, salt)).encrypt(nonce, payload, b"PMKTKEY3"))
        return {"path": str(path)}

    @safe
    def import_lead_key(self, path: str, password: str) -> dict:
        blob = Path(path).read_bytes()
        if not blob.startswith(b"PMKTKEY3"):
            raise ValueError("Không phải file khoá Lead (.pmktkey) của phiên bản này")
        try:
            d = json.loads(AESGCM(_kdf(password, blob[8:24])).decrypt(blob[24:36], blob[36:], b"PMKTKEY3"))
        except Exception:
            raise ValueError("Sai mật khẩu file khoá") from None
        if self._role() not in STAFF:
            raise PermissionError("Đăng nhập bằng tài khoản Lead trước khi nhập khoá")
        email = self._team()["email"]
        self._save_keys(email, {**self._keys(email), "lead": d["keys"]})
        sb = self._sb()
        needs = self._register_device(sb, sb.member(email), email)
        self._store.save_settings({"team": {**self._team(), "needs_key": needs}})
        if needs:
            raise ValueError("File khoá này không phải khoá hiện tại của nhóm")
        return self.team_info()

    @safe
    @runner_only
    def team_reset_lead_key(self) -> dict:
        """New signing key for the team (lost key file). Reports signed with the old key no longer open."""
        if self._role() not in STAFF:
            raise PermissionError(LEAD_ONLY)
        email = self._team()["email"]
        lead = LeadKeys.new()
        self._save_keys(email, {**self._keys(email), "lead": base64.b64encode(lead.to_bytes()).decode()})
        sb = self._sb()
        sb.register_keys(_pub64(lead.enc_public), _pub64(lead.sign_public), reset=True)
        self._store.save_settings({"team": {**self._team(), "needs_key": False}})
        self._lead_signs(sb)
        return self.team_info()

    @safe
    def pick_file(self, label: str, pattern: str) -> dict:
        if self._window is None:
            raise RuntimeError("Chưa mở cửa sổ app")
        import webview
        picked = self._window.create_file_dialog(webview.FileDialog.OPEN, file_types=(f"{label} ({pattern})",))
        return {"path": (picked[0] if isinstance(picked, (list, tuple)) else picked) if picked else None}

    @safe
    def startup_open(self) -> dict:
        """Open the .pmkt the app was launched with (double-click), once."""
        path, self._startup_file = self._startup_file, None
        if not path:
            return {"opened": None}
        run = self._open_blob(Path(path).read_bytes(), Path(path).name)["run"]
        return {"opened": {k: run.get(k) for k in ("file", "published_by", "published_at")}}

    @safe
    def open_local_report(self, path: str) -> dict:
        return self._open_blob(Path(path).read_bytes(), Path(path).name)["run"]

    def _latest(self) -> dict:
        if self._viewer():
            return self._member_state()["run"]
        runs = self._store.list_runs()
        if not runs:
            raise ValueError("Chưa có lần chạy nào")
        return self._store.load_run(runs[0]["run_id"])

    def _logic(self):
        """Active logic; problems in it fall back to the newest other stored version that loads cleanly."""
        active = self._store.active_logic()
        if not active:
            raise ValueError("Chưa có file Alert_Logic")
        fallback = None
        for _, p in reversed(self._store.logic_versions()):
            if p != active:
                cand = load_logic(p)
                if not any(i["hint"] == "error" for i in cand.issues):
                    fallback = cand
                    break
        return load_logic(active, fallback=fallback)

    def _ensure_inputs(self):
        if self._viewer():
            return self._member_state()["inputs"]
        if self._inputs is None:
            paths = self._paths or self._store.get_settings().get("last_inputs", {}).get("paths", [])
            if not paths:
                raise ValueError("Chưa chọn file data")
            self._paths = paths
            self._inputs = self._history().merge(self._load_cached(paths))
        return self._inputs

    def _cache_key(self, paths: list[str]) -> list:
        files = sorted(input_files([Path(p) for p in paths]))
        return [__version__, self._store.get_settings().get("ads_account") or "",
                [(str(f), f.stat().st_mtime_ns, f.stat().st_size) for f in files]]

    def _load_cached(self, paths: list[str]):
        """The files as read by the last run (inputs.pkl, written by the app itself): reading a big Data workbook
        takes ~30s, so pages that need the data after a restart use this copy while the files are unchanged."""
        cache = self._store.base / "inputs.pkl"
        try:
            key = self._cache_key(paths)
            with open(cache, "rb") as fh:
                saved_key, inputs = pickle.load(fh)
            conv = getattr(inputs, "converted", False)
            # read again: a copy from before the converted product file, or one with another team's converted rows
            if saved_key == key and conv is not False and (conv is None or conv.attrs.get("team") == self._layout().team):
                return inputs
        except Exception:  # no cache, files changed / gone, older app version: read the files
            pass
        layout = self._layout()
        with xlsx_session():  # each sheet read from disk once
            inputs = load_inputs(detect_inputs([Path(p) for p in paths], layout), self._store.get_settings().get("ads_account") or None, layout)
        self._save_cache(paths, inputs)
        return inputs

    def _save_cache(self, paths: list[str], inputs) -> None:
        cache = self._store.base / "inputs.pkl"
        tmp = cache.with_name(f"inputs.{uuid.uuid4().hex[:6]}.tmp")
        try:
            with open(tmp, "wb") as fh:
                pickle.dump((self._cache_key(paths), inputs), fh, protocol=pickle.HIGHEST_PROTOCOL)
            replace(tmp, cache)
        except OSError:
            tmp.unlink(missing_ok=True)  # a cache only – the run itself is unaffected

    def _history(self) -> History:
        return History(self._store.base / "history.db")

    def _repo(self) -> str:
        return self._store.get_settings().get("github_repo") or DEFAULT_REPO

    # ------------------------------------------------------------- run
    @safe
    def pick_folder(self) -> dict:
        if self._window is None:
            raise RuntimeError("Chưa mở cửa sổ app")
        import webview
        picked = self._window.create_file_dialog(webview.FileDialog.FOLDER)
        return {"paths": list(picked) if picked else []}

    @safe
    def pick_files(self) -> dict:
        if self._window is None:
            raise RuntimeError("Chưa mở cửa sổ app")
        import webview
        picked = self._window.create_file_dialog(webview.FileDialog.OPEN, allow_multiple=True,
                                                 file_types=("Excel / CSV (*.xlsx;*.xlsm;*.csv)",))
        return {"paths": list(picked) if picked else []}

    def _on_drop(self, event: dict) -> None:
        """Native drop handler (registered in app.py): only Python sees the dropped files' full paths."""
        files = (event.get("dataTransfer") or {}).get("files", [])
        paths = [f["pywebviewFullPath"] for f in files if f.get("pywebviewFullPath")]
        if paths and self._window is not None:
            self._window.evaluate_js(f"window.onDropPaths && onDropPaths({json.dumps(paths)})")

    # ------------------------------------------------------------- Activity Log from the Ads tool
    def _save_cognix(self, **kw) -> None:
        sec = self._secrets()
        self._save_secrets({**sec, "cognix": {**(sec.get("cognix") or {}), **kw}})

    def _cognix_login(self) -> Cognix:
        """Yes4All login page in an app window; its code is read from the window's address after the redirect."""
        if self._window is None:
            raise RuntimeError("Chưa mở cửa sổ app")
        import webview
        verifier, challenge = pkce()
        state = secrets.token_urlsafe(16)
        win = webview.create_window("Đăng nhập Ads", login_url(state, challenge), width=520, height=760)
        closed = threading.Event()
        win.events.closed += closed.set
        code, deadline = None, time.monotonic() + 300
        try:
            while not code and not closed.is_set() and time.monotonic() < deadline:
                try:
                    code = code_from(win.get_current_url(), state)
                except CognixError:
                    raise
                except Exception:  # window still opening
                    pass
                time.sleep(0.4)
        finally:
            if not closed.is_set():
                win.destroy()
        if not code:
            raise CognixError("Chưa đăng nhập Ads (đã đóng cửa sổ hoặc quá 5 phút)")
        c = Cognix.sign_in(code, verifier, lambda rt: self._save_cognix(refresh=rt))
        self._save_cognix(email=email_of(c.token()))
        return c

    @safe
    def activity_status(self) -> dict:
        return {"email": (self._secrets().get("cognix") or {}).get("email")}

    @safe
    @runner_only
    def activity_fetch(self) -> dict:
        """Export the last 7 days of the Activity Log from the Ads tool and download it (sign in first if needed)."""
        path = self._fetch_activity()
        return {"path": str(path), "email": (self._secrets().get("cognix") or {}).get("email"), "skipped": self._activity_skipped}

    def _fetch_activity(self, login: bool = True, cancel: threading.Event | None = None) -> Path:
        """login=False (inside a run): use the saved session only – a run never stops to show a login window.
        cancel: the run's Stop (the export wait and the download give up at once)."""
        if self._ads_other():  # someone else's Ads login: never fetch with it (as _ads_call)
            if not login:
                raise CognixError(f"Ads đang đăng nhập bằng {self._ads_other()} – không phải tài khoản của bạn")
            self._drop_ads()
        c = self._ads_client(login, "chưa đăng nhập Ads – bấm “Lấy Activity Log từ Ads” một lần để đăng nhập")
        if self._ads_other():
            other = self._ads_other()
            self._drop_ads()
            raise CognixError(f"Bạn vừa đăng nhập Ads bằng {other} – cần đúng tài khoản app ({self._team().get('email')})")
        self._activity_skipped = []
        dest, profiles = self._store.base / "activity", self._ads_profiles()
        if len(profiles) == 1:
            return c.fetch_activity(dest, profiles[0], cancel=cancel)

        def one(p: str) -> Path | Exception:  # one profile's failure (no access, slow export) never loses the others'
            try:
                return c.fetch_activity(dest / "profiles" / p, p, cancel=cancel)
            except (CognixError, OSError) as e:
                return e
        # several profiles (SFO): one export each, at the same time, then one workbook for the run
        with ThreadPoolExecutor(len(profiles)) as pool:
            got = dict(zip(profiles, pool.map(one, profiles)))
        failed = {p: r for p, r in got.items() if isinstance(r, Exception)}
        if len(failed) == len(profiles):
            raise CognixError("; ".join(f"profile {p}: {e}" for p, e in failed.items()))
        self._activity_skipped = [f"profile {p}: {e}" for p, e in failed.items()]
        out = merge_activity([r for r in got.values() if not isinstance(r, Exception)], dest / "Activity Log.xlsx")
        for old in dest.glob("*.xlsx"):  # a single-profile export from before: only the merged workbook stays
            if old != out:
                old.unlink(missing_ok=True)
        return out

    def _ads_profiles(self) -> list[str]:
        """The work team's Ads profile(s): set by the Admin on the server; else this computer's setting; the default
        team falls back to the built-in profile. Another team without one never acts on the default team's campaigns."""
        team = self._work_team()
        server = next((t.get("ads_profile") for t in self._teams() if t["id"] == team), None)
        local = self._store.get_settings().get("ads_profile_id")
        if ids := _profile_ids(server or local):
            return list(dict.fromkeys(ids))
        if team != self._default_team():
            raise CognixError(f"Nhóm {team.upper()} chưa có Ads profile – Admin đặt trong Cài đặt → Nhóm")
        return [PROFILE_ID]

    def _ads_profile(self) -> str:
        """The team's first Ads profile (one-profile callers and tests)."""
        return self._ads_profiles()[0]

    def _ads_client(self, login: bool = True, why: str = "chưa đăng nhập Ads") -> Cognix:
        """The saved Ads session (renewed as needed), else the login window – or CognixError(why) with login=False."""
        sec = self._secrets().get("cognix") or {}
        c = self._ads if self._ads is not None and self._ads.refresh == sec.get("refresh") else None
        if c is None and sec.get("refresh"):
            c = Cognix(sec["refresh"], lambda rt: self._save_cognix(refresh=rt))
        if c is not None:
            try:
                c.token()
            except CognixError:  # session over → log in again
                c = None
        if c is None and not login:
            raise CognixError(why)
        self._ads = c or self._cognix_login()
        return self._ads

    # ------------------------------------------------------------- campaign / ASIN on-off from the Campaign table
    # Every role (Lead, Member, Operator) may act – always with their OWN Ads login: the Ads session saved on this
    # computer must belong to the account signed in to the app, so nobody acts through a colleague's leftover session
    # on a shared PC. The Ads tool then decides what they may change and logs it under their name.
    def _ads_other(self) -> str | None:
        """The Ads login's email when it is not the app account's (None = same person, or no app account – tests)."""
        me = (self._team().get("email") or "").strip().lower()
        ads = ((self._secrets().get("cognix") or {}).get("email") or "").strip().lower()
        return ads if me and ads and ads != me else None

    def _ads_call(self, fn, login: bool = False, aws_id: str | None = None):
        """fn(client, profile): with aws_id, the profile holding that campaign; else the team's first profile."""
        with self._ads_lock:
            if self._ads_other():
                if not login:
                    raise PermissionError(f"Ads đang đăng nhập bằng {self._ads_other()} – không phải tài khoản của bạn "
                                          f"({self._team().get('email')}). Đăng nhập Ads bằng tài khoản của bạn trước.")
                self._drop_ads()  # someone else's session: sign in with your own
            c = self._ads_client(login, "ADS_LOGIN")
            if self._ads_other():
                other = self._ads_other()
                self._drop_ads()
                raise PermissionError(f"Bạn vừa đăng nhập Ads bằng {other} – cần đúng tài khoản app ({self._team().get('email')})")
            return fn(c, self._ads_where(c, aws_id) if aws_id is not None else self._ads_profile())

    def _drop_ads(self) -> None:
        sec = self._secrets()
        sec.pop("cognix", None)
        self._save_secrets(sec)
        self._ads, self._ads_ids, self._ads_prod = None, {}, {}

    def _ads_campaigns(self, c: Cognix) -> list[tuple[str, dict]]:
        """(profile, campaign row) over every profile of the team; refreshes the Amazon id → (tool id, profile) map."""
        rows = [(p, x) for p in self._ads_profiles() for x in c.campaigns(p)]
        self._ads_ids = {str(x.get("awsCampaignID")): (str(x.get("campaignID")), p) for p, x in rows}
        return rows

    def _ads_where(self, c: Cognix, aws_id: str) -> str:
        """The profile a campaign lives in (a team can have several)."""
        if str(aws_id) not in self._ads_ids:
            self._ads_campaigns(c)
        if str(aws_id) not in self._ads_ids:
            raise CognixError(f"Không thấy campaign {aws_id} trên Ads (profile {', '.join(self._ads_profiles())})")
        return self._ads_ids[str(aws_id)][1]

    def _ads_id(self, c: Cognix, profile: str, aws_id: str) -> str:
        self._ads_where(c, aws_id)
        return self._ads_ids[str(aws_id)][0]

    def _product_ads(self, c: Cognix, profile: str, aws_id: str, fresh: bool = False) -> list[dict]:
        """The campaign's product ads – the ones read when its row was expanded if under ADS_TTL old (a big campaign
        takes a minute to read; switching an ASIN only changes its state, and every write updates the copy)."""
        at, ads = self._ads_prod.get(str(aws_id), (float("-inf"), None))
        if fresh or ads is None or time.monotonic() - at > ADS_TTL:
            ads = c.product_ads(self._ads_id(c, profile, aws_id), profile)
            self._ads_prod[str(aws_id)] = (time.monotonic(), ads)
        return ads

    @safe
    def ads_campaign_states(self, login: bool = False) -> dict:
        """Amazon campaign id → ENABLED / PAUSED / ARCHIVED for every campaign of the profile. Without a saved Ads
        session: {"login": True} (login=True opens the login window instead)."""
        def go(c, _profile):
            rows = [x for _, x in self._ads_campaigns(c)]  # every profile of the team
            return {"states": {str(x.get("awsCampaignID")): state_of(x) for x in rows},
                    "budgets": {str(x.get("awsCampaignID")): budget_of(x) for x in rows},
                    # the tool's own names: the Campaign table falls back to them when the input files only gave the id
                    "names": {str(x.get("awsCampaignID")): str(n).strip() for x in rows
                              if (n := x.get("name") or x.get("campaignName")) and str(n).strip()},
                    "email": (self._secrets().get("cognix") or {}).get("email")}
        if not login and self._ads_other():  # a colleague's Ads session on this computer: ask for your own login
            return {"login": True, "other": self._ads_other()}
        try:
            return self._ads_call(go, login)
        except CognixError as e:
            if str(e) == "ADS_LOGIN":
                return {"login": True}
            raise

    @safe
    def ads_asin_states(self, aws_id: str) -> dict:
        """ASIN → ENABLED / PAUSED / MIXED / ARCHIVED inside one campaign (all its ad groups), and ASIN → how many of
        its ad groups are not archived (the "n nhóm" link that lists them)."""
        def go(c, profile):
            ads = self._product_ads(c, profile, aws_id, fresh=True)
            groups: dict[str, int] = {}
            for a in ads:
                if a.get("asin") and state_of(a) != "ARCHIVED":
                    groups[a["asin"]] = groups.get(a["asin"], 0) + 1
            return {"asins": asin_states(ads), "groups": groups}
        return self._ads_call(go, aws_id=aws_id)

    @safe
    def ads_asin_groups(self, aws_id: str, asin: str, start: str | None = None, end: str | None = None) -> dict:
        """The ad groups of the campaign holding the ASIN – its product ad in each, with that ad's state (archived ones
        left out: they can't be switched) and, with start / end (the page's timeframe), the ASIN's stats in that group
        from the Ads tool, to compare the groups before switching one."""
        def go(c, profile):
            mine = [a for a in self._product_ads(c, profile, aws_id) if a.get("asin") == asin and state_of(a) != "ARCHIVED"]
            perf = c.ad_stats([str(a["adGroupID"]) for a in mine], start, end, profile) if start and end and mine else {}
            rows = []
            for a in mine:
                p = perf.get(str(a["adID"]))
                rows.append({"ad_id": str(a["adID"]), "group": a.get("adGroupName") or str(a.get("adGroupID")), "state": state_of(a),
                             "url": ad_group_url(a),
                             **({} if p is None else {"spend": p.get("spend", 0), "nmv": p.get("sale", 0), "orders": p.get("order", 0),
                                                      "clicks": p.get("click", 0), "impressions": p.get("impression", 0)})})
            return {"groups": sorted(rows, key=lambda g: (-(g.get("spend") or 0), g["group"].lower())), "start": start, "end": end}
        return self._ads_call(go, aws_id=aws_id)

    @safe
    def ads_set_ad(self, aws_id: str, ad_id: str, on: bool) -> dict:
        """One product ad (= the ASIN in one ad group) on / off. → its state and the ASIN's state over the campaign."""
        def go(c, profile):
            ads = self._product_ads(c, profile, aws_id)
            ad = next((a for a in ads if str(a.get("adID")) == str(ad_id)), None)
            if ad is None:
                raise CognixError("Không thấy ad group này trên Ads – mở lại campaign để tải lại")
            if state_of(ad) == "ARCHIVED":
                raise CognixError("Ad đã archive trên Ads – không bật/tắt được")
            c.set_ads([ad], bool(on), profile)
            return {"state": state_of(ad), "asin_state": asin_states([a for a in ads if a.get("asin") == ad.get("asin")]).get(ad.get("asin"))}
        return self._ads_call(go, aws_id=aws_id)

    @safe
    def ads_set_budget(self, aws_id: str, amount: float) -> dict:
        """New budget for one campaign. → its budget fields read back from the Ads tool."""
        return self._ads_call(lambda c, profile: c.set_budget(self._ads_id(c, profile, aws_id), float(amount), profile), aws_id=aws_id)

    @safe
    def ads_set_campaign(self, aws_id: str, on: bool) -> dict:
        return self._ads_call(lambda c, profile: {"state": c.set_campaign(self._ads_id(c, profile, aws_id), bool(on), profile)},
                              aws_id=aws_id)

    @safe
    def ads_set_asin(self, aws_id: str, asin: str, on: bool) -> dict:
        """Every product ad of the ASIN in the campaign (it can sit in several ad groups). → the ASIN's state, and its
        ad groups (as ads_asin_groups) so an open list redraws without another read."""
        def go(c, profile):
            mine = [a for a in self._product_ads(c, profile, aws_id) if a.get("asin") == asin]
            if not mine:
                raise CognixError(f"Không thấy ASIN {asin} trong campaign trên Ads")
            n = c.set_ads(mine, bool(on), profile)
            groups = sorted(({"ad_id": str(a["adID"]), "group": a.get("adGroupName") or str(a.get("adGroupID")), "state": state_of(a)}
                             for a in mine if state_of(a) != "ARCHIVED"), key=lambda g: g["group"].lower())
            return {"state": asin_states(mine).get(asin), "changed": n, "groups": groups}
        return self._ads_call(go, aws_id=aws_id)

    @safe
    def ads_open(self, url: str) -> dict:
        """Open an Ads website page (an ad group from the Campaign table) in the default browser – only pages of
        ads.yes4all.com/campaigns/, never an arbitrary address from the page."""
        if not (isinstance(url, str) and url.startswith(REDIRECT + "campaigns/") and all(c not in url for c in " \"'<>\n")):
            raise ValueError("Link không phải trang campaign trên ads.yes4all.com")
        import webbrowser
        webbrowser.open(url)
        return {"ok": True}

    def _found(self) -> list[Path]:
        """The SharePoint exports in OneDrive – synced files or `.url` shortcuts (found once, then remembered)."""
        found = [str(p) for p in onedrive.find(self._store.get_settings().get("synced_paths"), names=self._layout().exports)]
        if found != self._store.get_settings().get("synced_paths"):
            self._store.save_settings({"synced_paths": found})
        return [Path(p) for p in found]

    def _synced(self, problems: list[str] | None = None, ctx: _RunCtx | None = None) -> list[str]:
        """The SharePoint exports on this computer: OneDrive-synced files, and for `.url` shortcuts the copy downloaded
        from SharePoint. With `problems` (inside a run) the copies are downloaded fresh first; a failure is noted
        there and the last copies are used. ctx: the run (its Stop ends a download at once)."""
        progress = functools.partial(self._progress, ctx=ctx)
        found = self._found()
        links = [p for p in found if p.suffix == ".url"]
        if problems is not None:  # inside a run: one progress sub-step per file
            for p in found:
                if p.suffix != ".url" and p.exists():
                    progress(f"fetch:{p.name} (OneDrive)", "done", f"sync {datetime.fromtimestamp(p.stat().st_mtime):%d/%m %H:%M}")
            failed = None
            cancel = ctx.cancel if ctx else None
            for p in links:
                key = f"fetch:Tải {p.name.removesuffix('.url')} từ SharePoint"
                if failed:  # same session for every file – one failure means the rest fail too
                    progress(key, "warn", "bỏ qua – dùng bản đã tải trước")
                    continue
                check(cancel)
                progress(key, "running")
                try:
                    sharepoint.download([p], self._sp_cookies(), self._store.base / "sharepoint", cancel=cancel)
                    progress(key, "done")
                except (SharePointError, OSError) as e:
                    failed = e
                    progress(key, "warn", str(e))
            if failed:
                problems.append(f"SharePoint: không tải được file ({failed}) – dùng bản đã tải trước hoặc sheet trong file Data")
        copies = [self._store.base / "sharepoint" / p.name.removesuffix(".url") for p in links]
        return [str(p) for p in found if p.suffix != ".url"] + [str(c) for c in copies if c.exists()]

    def _sp_cookies(self) -> dict:
        return (self._secrets().get("sharepoint") or {}).get("cookies") or {}

    def _sharepoint_login(self, link: str) -> dict:
        """The file's SharePoint page in an app window; once Microsoft's login lands back on SharePoint, its
        sign-in cookies are kept (like the Ads login, a run never opens this window)."""
        if self._window is None:
            raise RuntimeError("Chưa mở cửa sổ app")
        import urllib.parse
        import webview
        host = urllib.parse.urlsplit(link).netloc
        win = webview.create_window("Đăng nhập SharePoint (Microsoft)", link + "?web=1", width=1000, height=760)
        closed = threading.Event()
        win.events.closed += closed.set
        cookies, deadline = {}, time.monotonic() + 300
        try:
            while not sharepoint.signed_in(cookies) and not closed.is_set() and time.monotonic() < deadline:
                time.sleep(0.5)
                try:
                    if urllib.parse.urlsplit(win.get_current_url() or "").netloc == host:
                        cookies = {k: m.value for c in win.get_cookies() for k, m in c.items()}
                except Exception:  # window still opening
                    pass
        finally:
            if not closed.is_set():
                win.destroy()
        if not sharepoint.signed_in(cookies):
            raise SharePointError("Chưa đăng nhập SharePoint (đã đóng cửa sổ hoặc quá 5 phút)")
        self._save_secrets({**self._secrets(), "sharepoint": {"cookies": cookies}})
        return cookies

    @safe
    @runner_only
    def sharepoint_fetch(self) -> dict:
        """Download the `.url`-shortcut exports now, signing in to SharePoint first if the session is missing or over."""
        links = [p for p in self._found() if p.suffix == ".url"]
        if not links:
            raise SharePointError("Không thấy shortcut file SharePoint trong OneDrive – trên SharePoint bấm "
                                  "“Add shortcut to My files” ở từng file nguồn rồi thử lại")
        dest = self._store.base / "sharepoint"
        try:
            files = sharepoint.download(links, self._sp_cookies(), dest)
        except SharePointError:
            files = sharepoint.download(links, self._sharepoint_login(link_of(links[0])), dest)
        return {"paths": [str(f) for f in files]}

    @safe
    def synced_files(self) -> dict:
        return {"paths": self._synced()}

    def _fetch_step(self, paths: list[str], ctx: _RunCtx | None = None) -> tuple[list[str], list[str]]:
        """Run step 1: a fresh Activity Log from Ads, and how recent the OneDrive-synced SharePoint exports are.
        → (paths with the new Activity Log first, problems for the results' stale-data bar). Never stops the run
        (only Stop does: progress.Cancelled)."""
        progress = functools.partial(self._progress, ctx=ctx)
        progress("fetch", "running", "Activity Log từ Ads · file SharePoint (OneDrive)")
        notes, problems, fresh = [], [], []
        progress("fetch:Activity Log từ Ads", "running")
        try:
            log = self._fetch_activity(login=False, cancel=ctx.cancel if ctx else None)
            fresh = [str(log)]  # first: the newest Activity Log wins (detect_inputs)
            notes.append(f"Activity Log mới: {log.name}")
            if skipped := self._activity_skipped:
                problems.append(f"Activity Log: thiếu {len(skipped)} profile ({'; '.join(skipped)})")
                notes.append(problems[-1])
            progress("fetch:Activity Log từ Ads", "warn" if skipped else "done", " · ".join([log.name, *skipped]))
        except (CognixError, RuntimeError, OSError) as e:
            problems.append(f"Activity Log: không lấy được từ Ads ({e}) – dùng file đang có")
            notes.append(problems[-1])
            progress("fetch:Activity Log từ Ads", "warn", str(e))
        n = len(problems)
        paths = [*fresh, *self._synced(problems, ctx), *paths]  # found OneDrive copies before older picks of the same table
        notes += problems[n:]
        synced = []
        for f in input_files([Path(p) for p in paths]):
            try:
                if role_of(f, self._layout()) in {*TRACKER_SHEETS, "ads"}:  # a one-table export, not the Data workbook
                    synced.append(f)
            except Exception:
                pass
        notes.append(f"SharePoint: {len(synced)} file, sync gần nhất {datetime.fromtimestamp(max(f.stat().st_mtime for f in synced)):%d/%m %H:%M}"
                     if synced else "SharePoint: chưa thêm file sync (dùng sheet trong file Data)")
        progress("fetch", "warn" if problems else "done", " · ".join(notes))
        return paths, problems

    @safe
    def activity_sign_out(self) -> dict:
        sec = self._secrets()
        self._drop_ads()
        return {"ok": True}

    @safe
    def detect(self, paths: list[str]) -> dict:
        """Classify picked files/folders (.xlsx or .csv). Earlier paths win per role, so the UI sends new picks
        first; inside a folder the newest file wins. The Tracking slot is one workbook or its CSV tables
        (raw_sso_us, Product Info, KPI[, INELIGIBLE ASIN] – the work team's sheet names). Partial picks are fine:
        missing roles are listed."""
        layout = self._layout()
        files: list[Path] = []
        for p in map(Path, paths):
            if p.is_dir():
                files += sorted(input_files([p]), key=lambda f: f.stat().st_mtime, reverse=True)
            elif p.exists():
                files.append(p)
        found, unknown = {}, []
        for f in files:
            try:
                role = role_of(f, layout)
            except Exception:
                role = None
            if role is None:
                unknown.append(f.name)
            elif role not in found:
                found[role] = f
        info = lambda f: {"path": str(f), "name": f.name, "size_mb": round(f.stat().st_size / 1e6, 1),  # noqa: E731
                          "modified": _mtime(f)}
        roles = {r: info(f) for r, f in found.items() if r in ROLES or r in EXTRA_ROLES}
        ignored = [f.name for r, f in found.items() if r in OPTIONAL_ROLES]  # Defind: no longer used
        if "tracker" in found and ads_sheet_of(found["tracker"], layout):
            ads = (found["ads"] if layout.ads_export_wins and "ads" in found
                   else newer_ads(found["tracker"], [found["ads"]] if "ads" in found else []))
            if ads != found["tracker"]:  # a newer ads_camp file (e.g. OneDrive-synced) replaces the workbook's sheet
                roles["ads"] = info(ads)
            else:
                if "ads" in roles:  # an older separate Ads file still names the campaigns (its column F, feedback #33)
                    t = roles["tracker"]
                    t["paths"] = [*(t.get("paths") or [t["path"]]), roles["ads"]["path"]]
                roles["ads"] = {**info(found["tracker"]), "same_as": "tracker"}  # v4: the Data workbook carries ads_camp
        parts = {t: found[t] for t in TRACKER_SHEETS if t in found}
        tracker_missing = []
        if parts and "tracker" not in roles:
            tracker_missing = [layout.sheets[t] for t in TRACKER_REQUIRED if t not in parts]
            if not tracker_missing:
                roles["tracker"] = {"path": str(parts["raw"]), "paths": [str(f) for f in parts.values()],
                                    "name": " + ".join(f.name for f in parts.values()),
                                    "size_mb": round(sum(f.stat().st_size for f in parts.values()) / 1e6, 1),
                                    "modified": max(_mtime(f) for f in parts.values())}
        elif parts and "tracker" in roles:  # CSV tables override the workbook's sheets
            roles["tracker"]["paths"] = [*(roles["tracker"].get("paths") or [roles["tracker"]["path"]]),
                                         *[str(f) for f in parts.values()]]
        if "tracker" in roles and "ads" in roles and not roles["ads"].get("same_as"):
            # an older set with a separate Ads file: show it as part of the one Data slot
            t, ad = roles["tracker"], roles["ads"]
            t.update(paths=[*(t.get("paths") or [t["path"]]), ad["path"]], name=f"{t['name']} + {ad['name']}",
                     size_mb=round(t["size_mb"] + ad["size_mb"], 1), modified=max(t["modified"], ad["modified"]))
            ad["same_as"] = "tracker"
        if "tracker" in roles:  # the one-table exports beside the Data workbook (SharePoint via OneDrive)
            t = roles["tracker"]
            t["synced"] = [{"name": Path(p).name, "modified": _mtime(Path(p))} for p in t.get("paths") or [] if p != t["path"]]
            t["workbook_modified"] = _mtime(Path(t["path"]))
        seen = self._store.get_settings().get("last_run_files") or {}
        for r in roles.values():  # "Mới": changed since the last finished run
            r["new"] = any(seen.get(p) != _mtime(Path(p)) for p in r.get("paths") or [r["path"]])
        return {"roles": roles, "missing": [r for r in ROLES if r not in roles], "unknown": unknown,
                "tracker_missing": tracker_missing, "ignored": ignored}

    @safe
    def file_detail(self, paths: list[str]) -> dict:
        """What is inside an input file: size, last modified, and per sheet the rows, columns, date range and
        the first rows. Cached per (path, modified time, size)."""
        return {"files": [_file_detail(Path(p), self._layout()) for p in paths]}

    @safe
    def cancel_run(self) -> dict:
        """Stop pressed: the run ends now for the UI. Its thread is cut loose (its progress and saves are dropped from
        here on), its downloads / Claude processes stop at once, and a new run can start straight away. When the rules
        were already saved, that run keeps its rule results with the Claude part marked as stopped → run_id."""
        live = self._live
        if live is None:
            return {"ok": False}
        live.cancel.set()  # first, without waiting: every loop of the run looks at it
        cancel_claude(live.cancel)
        with self._commit:  # a save already under way finishes first; none starts after this
            if self._live is live:
                self._live, self._running, self._eta = None, False, None
            on_stop, live.on_stop = live.on_stop, None
            if on_stop:
                on_stop()
        return {"ok": True, "run_id": live.run_id}

    @safe
    @runner_only
    def run(self, paths: list[str], as_of: str | None = None, use_claude: bool = True) -> dict:
        ctx = _RunCtx()
        with self._commit:
            self._live, self._cancel, self._running = ctx, ctx.cancel, True
            self._step = "load"
            self._eta = ctx.eta = Eta(self._store.get_settings().get("step_times"))
        ctx.eta.plan(["fetch", "load", "logic", "rules"] + (["claude", "logic_eval"] if use_claude else []), claude_calls=0)
        try:
            return self._run(ctx, paths, as_of, use_claude)
        except Exception as e:
            if ctx.cancel.is_set():  # whatever broke after Stop (a killed download, a Cancelled check) is the stop
                return {"cancelled": True}
            e.step = self._step  # which step stopped the run
            raise
        finally:
            with self._commit:
                if self._live is ctx:  # a stopped run's late finish leaves the next run alone
                    self._store.save_settings({"step_times": ctx.eta.learned()})
                    self._live, self._eta, self._running = None, None, False

    @contextlib.contextmanager
    def _saving(self, ctx: "_RunCtx"):
        """A run's results are written only while it is not stopped – never half before and half after a Stop."""
        with self._commit:
            check(ctx.cancel)
            yield

    def _run(self, ctx: "_RunCtx", paths: list[str], as_of: str | None, use_claude: bool) -> dict:
        progress = functools.partial(self._progress, ctx=ctx)

        def ask_unless_stopped(prompt: str, schema: dict) -> dict:
            if ctx.cancel.is_set():
                raise ClaudeError(STOPPED)
            with claude_scope(ctx.cancel):  # Stop kills this call's claude process
                out = self._ask(prompt, schema)
            if ctx.cancel.is_set():
                raise ClaudeError(STOPPED)
            return out

        paths, fetch_problems = self._fetch_step([str(p) for p in paths if Path(p).exists()], ctx)
        check(ctx.cancel)
        progress("load", "running", "Đọc & làm sạch data")
        layout = self._layout()
        with xlsx_session():  # finding the files and loading them read each sheet from disk once
            try:
                roles = detect_inputs([Path(p) for p in paths], layout)
            except InputError as e:  # no Activity Log at all: say why Ads gave none (else only on the fetch step)
                why = [p for p in fetch_problems if p.startswith("Activity Log")]
                if why and "Activity Log" in str(e):
                    raise InputError(f"{e}. Lấy từ Ads không được: {why[0].removeprefix('Activity Log: ')}", e.location) from e
                raise
            inputs = load_inputs(roles, self._store.get_settings().get("ads_account") or None, layout, cancel=ctx.cancel)
        check(ctx.cancel)
        today = date.fromisoformat(as_of) if as_of else us_today()  # the sources' dates are US dates
        old = fetch_problems + stale(inputs.latest, today)
        fresh = freshness(inputs.latest, today)
        log_day = _latest_day(inputs.activity["time"])
        fresh.append({"table": "Activity Log", "file": roles["activity"].name, "day": log_day,
                      "ok": not any(p.startswith("Activity Log") for p in fetch_problems)})
        self._save_cache([str(p) for p in paths], inputs)
        check(ctx.cancel)
        self._history().save(inputs)  # keep the file's days (3 months), then add the stored older days in front
        inputs = self._history().merge(inputs)
        with self._saving(ctx):
            self._inputs, self._paths = inputs, [str(p) for p in paths]
            self._store.save_settings({"last_inputs": {"paths": self._paths}})
            # The picked logic file is used unless an identical copy is already stored (then the active
            # version stays, e.g. a Ver N+1 the app created from approved proposals).
            picked = roles["logic"]
            same = self._store.base / "logic" / picked.name
            if not (same.exists() and same.read_bytes() == picked.read_bytes()):
                self._store.import_logic(picked)  # problems inside it are reported, never block the run
        out_paths = [str(p) for p in paths]
        logic = self._logic()
        rank = {"error": 0, "warn": 1, "info": 2}
        logic_issues = sorted(logic.issues, key=lambda i: rank[i["hint"]])
        errs = sum(i["hint"] == "error" for i in logic_issues)
        ctx.eta.start("logic")
        progress("logic", "warn" if errs else "done",
                 f"{logic.path.name}: {errs} lỗi (đã dùng giá trị dự phòng), "
                 f"{sum(i['code'] == 'UNUSED' for i in logic_issues)} tham số app chưa dùng" if logic_issues else logic.path.name)
        check(ctx.cancel)
        progress("load", "warn" if old else "done",
                 "Data cũ – " + " · ".join(old) if old else f"{len(inputs.raw):,} dòng raw · {len(inputs.ads):,} dòng ads_camp")

        progress("rules", "running", "Tầng 0–4")
        result = run_rules(inputs, logic, date.fromisoformat(as_of) if as_of else None)
        check(ctx.cancel)
        rj = result_to_json(result)
        rj["logic_issues"] = logic_issues
        rj["logic_file"] = logic.path.name
        rj["listing_asins"] = listing_issue_asins(inputs.products)  # backfills listing_history for days it lacks
        rj["listing_issues"] = listing_issues(inputs.products)  # + the issue text, so a backfilled day names the issue
        day = inputs.raw["date"].max()
        mine = set(inputs.products["asin"])  # the Keepa file also lists ASINs outside Product Info (~2×)
        rj["inputs"] = {
            "raw": {"rows": len(inputs.raw), "last": str(inputs.raw["date"].max())},
            "ads": {"rows": len(inputs.ads), "last": str(inputs.ads["date"].max()),
                    "account": inputs.ads.attrs.get("account"), "accounts": inputs.ads.attrs.get("accounts", [])},
            "activity": {"rows": len(inputs.activity), "users": int(inputs.activity["user"].nunique())},
            "files": {r: p.name for r, p in roles.items()},
            "stale": old,
            "fresh": fresh,
        }
        store = self._store

        def stopped_ai() -> dict:
            ai = offline(rj, STOPPED + " – kết quả rule vẫn đầy đủ")
            ai["logic_eval"] = evaluate_logic(logic_issues, logic, ask_fn=always_fail)
            return ai

        with self._saving(ctx):
            store.save_listing_day(day.isoformat(), day_issues(inputs, day))  # 30-day history
            store.save_keepa_day(day.isoformat(), {a: v for a, v in (getattr(inputs, "keepa", None) or {}).items() if a in mine})
            run_id = store.save_run(rj, None)
            used = {str(p) for p in roles.values()}  # results exist: these files are no longer "Mới"
            store.save_settings({"last_run_files": {p: _mtime(Path(p)) for p in used}})
            ctx.run_id = run_id  # a Stop from here on keeps the rule results (the UI opens them)
            if use_claude:  # … with the Claude part marked as stopped
                ctx.on_stop = lambda: store.update_run_ai(run_id, stopped_ai())
        progress("rules", "done", f"{len(rj['pl'])} PL · {len(rj['camp'])} campaign", run_id=run_id)
        ai = None
        status = self._status() if use_claude else None
        if use_claude and status.level != "ok":
            ai = offline(rj, status.error or "Claude Code chưa sẵn sàng")
            ai["logic_eval"] = evaluate_logic(logic_issues, logic, ask_fn=always_fail)
            with self._saving(ctx):
                store.update_run_ai(run_id, ai)
                ctx.on_stop = None
            progress("claude", "warn", ai["error"])
            ctx.eta.done("logic_eval")
        elif use_claude:
            careful = bool(store.get_settings().get("careful_mode", True))
            ctx.eta.calls_total = ctx.eta.calls_left = planned_calls(rj, careful)
            progress("claude", "running", "5 bước/PIC: dữ kiện → nháp → kiểm tra → biên tập → kiểm tra lại"
                     if careful else "Chế độ nhanh: nháp → kiểm tra")
            amap = asin_map(inputs.products, result.as_of)
            l7d = Windows(result.as_of).l7d
            inel = inputs.ineligible[(inputs.ineligible["date"] >= l7d[0]) & (inputs.ineligible["date"] <= l7d[1])]
            inel = inel.merge(amap, on="asin")[["asin", "pl", "pic", "reason"]].drop_duplicates("asin")
            ai = generate(rj, logic, store, inputs.event_days, inputs.defind_text,
                          inel.to_dict("records"), ask_fn=ask_unless_stopped, careful=careful, on_step=progress)
            if ctx.cancel.is_set():  # cancel_run already marked the saved run as stopped
                ai.update(claude_ok=False, error=STOPPED + " – kết quả rule vẫn đầy đủ")
                return {"run_id": run_id, "result": rj, "ai": ai, "stopped": True, "published": None, "paths": out_paths}
            ctx.eta.done("claude")
            progress("logic_eval", "running", "Claude đánh giá các vấn đề trong file logic")
            ai["logic_eval"] = evaluate_logic(logic_issues, logic, ask_fn=ask_unless_stopped)
            with self._saving(ctx):
                store.update_run_ai(run_id, ai)
                ctx.on_stop = None
            progress("logic_eval", "done", ai["logic_eval"]["summary"][:120])
            try:
                check(ctx.cancel)
                proposals_from_review(ai["review"], logic, store, inputs, result.as_of)
            except Cancelled:
                raise
            except Exception:  # a failed backtest must not hide the run
                self._log(traceback.format_exc())
            progress("claude", "done" if ai["claude_ok"] else "warn", ai["error"] or "")
        return {"run_id": run_id, "result": rj, "ai": ai, "stopped": False, "published": None, "paths": out_paths}

    @safe
    def evidence(self, unit_id: str, run_id: str | None = None) -> dict:
        run = self._run_or_latest(run_id)  # viewers: the opened report, not the (empty) local run store
        rj = run["result"]
        logic_path = self._run_logic_path(rj)
        ev = evidence(self._ensure_inputs(), load_logic(logic_path), rj, unit_id)
        return {**ev, "files": rj.get("inputs", {}).get("files", {}), "logic_file": Path(logic_path).name,
                "as_of": rj["as_of"]}

    def _run_logic_path(self, rj: dict) -> Path:
        """The logic file the run used – by the name it recorded: several files can share a version number
        ('Logic (1).xlsx' and 'Alert_Logic_Ver 1.xlsx' are both 1), and the wrong one drops the team scope.
        Older runs without the name: by version, else the active one. Viewers: the logic inside the report."""
        if self._viewer():
            return self._member_state()["logic_path"]
        named = self._store.base / "logic" / (rj.get("logic_file") or "")
        if rj.get("logic_file") and named.exists():
            return named
        return next((p for v, p in self._store.logic_versions() if v == rj["logic_version"]), None) or self._store.active_logic()

    def _run_label(self, rj: dict) -> str:
        """Team label the run is scoped to (score model only)."""
        return load_logic(self._run_logic_path(rj)).texts.get("team_label", "") if rj.get("model") == "score_v3" else ""

    def _weekly(self, rj: dict) -> list[dict]:
        return weekly(self._ensure_inputs(), date.fromisoformat(rj["as_of"]), model=rj.get("model"), label=self._run_label(rj))

    def _run_or_latest(self, run_id: str | None) -> dict:
        if self._viewer():
            return self._latest()
        run = self._store.load_run(run_id) if run_id else self._latest()
        if not run:
            raise ValueError("Không tìm thấy lần chạy")
        return run

    def _runs_history(self) -> list[dict]:
        if self._viewer():
            res = self._latest()["result"]
            return [{"run_id": self._latest().get("file"), "as_of": res.get("as_of"),
                     "by_pic": {d["pic"]: {"high": d["pl_high"] + d["camp_high"], "excess": round(d["excess_new"], 2)}
                                for d in res.get("digest", [])}}]
        out = []
        for r in reversed(self._store.list_runs()[:30]):
            res = (self._store.load_run(r["run_id"]).get("result") or {})
            out.append({"run_id": r["run_id"], "as_of": res.get("as_of"),
                        "by_pic": {d["pic"]: {"high": d["pl_high"] + d["camp_high"], "excess": round(d["excess_new"], 2)}
                                   for d in res.get("digest", [])}})
        return out

    @safe
    def dashboard(self, run_id: str | None = None) -> dict:
        run = self._run_or_latest(run_id)
        weights = self._store.get_settings().get("score_weights") or {}
        sc = scorecard(run["result"], weights)
        if self._role() == "member":  # the shared part only carries this PIC; scores come from the Lead's full run
            sc["pics"] = [run["my_scorecard"]] if run.get("my_scorecard") else []
        rj = run["result"]
        return {"run_id": run["run_id"], "scorecard": sc,
                "weekly": self._weekly(rj),
                "daily_pic": daily_pic(self._ensure_inputs(), date.fromisoformat(rj["as_of"]), rj.get("model"), self._run_label(rj)),
                "runs": self._runs_history(), "team_review": run.get("team_review")}

    @safe
    def performance(self, filters: dict | None = None, run_id: str | None = None) -> dict:
        """Performance Review page. Members always get their own PIC (their package holds nothing else);
        Operators pick any PIC of the full report."""
        f = dict(filters or {})
        run = self._run_or_latest(run_id)
        rj = run["result"]
        if self._role() == "member":
            f["pic"] = self._team().get("pic")
        logic = load_logic(self._run_logic_path(rj))
        label = logic.texts.get("team_label", "") if rj.get("model") == "score_v3" else ""
        out = performance(self._ensure_inputs(), rj, label, f.get("pic") or None, f.get("pl") or None,
                          f.get("start"), f.get("end"), inv_params=logic.params,
                          prev_listing=self._prev_listing(run),
                          listing_history=run.get("listing_history") if self._viewer() else self._store.listing_history(),
                          leader=f.get("leader") or None, chart_asin=f.get("sku") or None,
                          keepa_history=run.get("keepa_history") if self._viewer() else self._store.keepa_history())
        return {"run_id": run["run_id"], **out}

    @safe
    def performance_drivers(self, filters: dict | None = None, day: str | None = None, period: str = "day",
                            run_id: str | None = None) -> dict:
        """The Performance Review change-driver table for one day and period (day / week / month, feedback #51), on demand."""
        f = dict(filters or {})
        rj = self._run_or_latest(run_id)["result"]
        if self._role() == "member":
            f["pic"] = self._team().get("pic")
        label = load_logic(self._run_logic_path(rj)).texts.get("team_label", "") if rj.get("model") == "score_v3" else ""
        return period_drivers(self._ensure_inputs(), rj, label, f.get("pic") or None, f.get("pl") or None, f.get("end"),
                              f.get("leader") or None, f.get("sku") or None, day, period)

    # ------------------------------------------------------------- Hourly tab
    def _hourly_path(self) -> Path | None:
        """The hourly export: the remembered / picked file; else (once per session) a search by its name in OneDrive,
        Downloads and the folders picked for the run. Found → remembered."""
        p = self._store.get_settings().get("hourly_path")
        if p and Path(p).is_file():
            return Path(p)
        if self._hr_searched:
            return None
        self._hr_searched = True
        names = (self._layout().hourly_file,)
        dirs = [Path.home() / "Downloads", *[Path(x) for x in self._store.get_settings().get("last_inputs", {}).get("paths", [])]]
        near = [f for d in dirs if d.is_dir() for f in d.glob("*.xlsx") if f.name.lower() == names[0].lower()]
        found = sorted(near, key=lambda f: f.stat().st_mtime, reverse=True) or onedrive.find(names=names)
        if not found:
            return None
        self._store.save_settings({"hourly_path": str(found[0])})
        return found[0]

    def _hourly_copy(self, shortcut: Path, force: bool = False, login: bool = False) -> Path | None:
        """A `.url` shortcut to the hourly file on SharePoint → its downloaded copy, downloaded again every
        HR_FETCH_EVERY s (an unchanged file is not rewritten, so the parsed copy is kept). The sign-in window opens
        only with login=True; a failed download keeps the last copy and its error shows on the tab."""
        copy = self._store.base / "sharepoint" / shortcut.name.removesuffix(".url")
        due = force or time.monotonic() - self._hr_fetched >= HR_FETCH_EVERY
        if due and self._hr_dl.acquire(blocking=False):  # another call downloading → use the copy there is
            try:
                try:
                    sharepoint.download([shortcut], self._sp_cookies(), copy.parent)
                except SharePointError:
                    if not login:
                        raise
                    sharepoint.download([shortcut], self._sharepoint_login(link_of(shortcut)), copy.parent)
                self._hr_err = None
            except (SharePointError, OSError) as e:
                self._hr_err = str(e)
            finally:
                self._hr_fetched = time.monotonic()
                self._hr_dl.release()
        return copy if copy.is_file() else None

    def _hourly_status(self, force: bool = False, login: bool = False) -> dict:
        """Viewers: the Lead's latest hourly push when there is one, else their own file. Lead / Team Lead: its own
        file, when it was last shared with the team, and the team's shared copy (team_copy: another Lead may have
        pushed newer data – hourly() shows whichever is newer); the signature follows both."""
        runner = self._role() in RUNNERS
        shared = self._hourly_shared_entry() if runner or self._viewer() else None
        if shared and not runner:
            return shared
        st = self._hourly_file_status(force, login)
        if runner and (pushed := self._store.get_settings().get("hourly_share")):
            st["team_share"] = {k: pushed.get(k) for k in ("at", "folder", "pics")}
        if shared:
            st["team_copy"] = shared
            st["sig"] = f"{st.get('sig') or ''}|{shared['sig']}"
        return st

    def _hourly_shared_entry(self) -> dict | None:
        """Viewers: this device's file of the Lead's hourly push in the newest reports – listing only (cheap: the UI
        polls it every minute); the signature changes with every push. None = no push / offline."""
        try:
            sb = self._sb()
            mine = LEAD_FILE if self._role() in STAFF else pic_file(self._team().get("pic") or "")
            for folder in self._team_reports(sb)[:HR_SHARE_REPORTS]:
                e = next((f for f in sb.files(f"{folder}/{HOURLY_DIR}/") if f.get("name") == mine and f.get("id")), None)
                if e:
                    stamp = e.get("updated_at") or e.get("created_at") or ""
                    return {"shared": f"{folder}/{HOURLY_DIR}/{mine}", "path": None, "name": "Lead",
                            "sig": f"{folder}|{stamp}|{e['id']}", "modified": _local_iso(stamp)}
        except (PermissionError, TeamError, OSError):
            return None
        return None

    def _hourly_shared_frame(self, status: dict) -> tuple:
        """(frame, meta) of the Lead's push named by status – downloaded only when its signature changed."""
        if self._hr_shared and self._hr_shared[0] == status["sig"]:
            return self._hr_shared[1], self._hr_shared[2]
        meta, files = self._read_blob(self._sb().download(status["shared"]))
        df = _frame_from(files["hourly.json"])
        meta = {**meta, "last": meta.get("last") or _hr_last(df)}  # older pushes lack it
        self._hr_shared = (status["sig"], df, meta)
        return df, meta

    def _hourly_file_status(self, force: bool = False, login: bool = False) -> dict:
        p = self._hourly_path()
        if p is None:
            return {"path": None, "expected": self._layout().hourly_file}
        sp = {}
        if p.suffix.lower() == ".url":
            sp = {"sharepoint": link_of(p), "sp_error": None}
            p = self._hourly_copy(p, force, login)
            sp["sp_error"] = self._hr_err
            if p is None:
                return {"path": None, "expected": self._layout().hourly_file, **sp}
        st = p.stat()
        return {"path": str(p), "name": p.name, "modified": _mtime(p), "sig": f"{st.st_mtime_ns}:{st.st_size}", **sp}

    def _hourly_frame(self, p: Path):
        """The parsed hourly file, re-read only when it changed on disk (also kept in hourly.pkl across restarts).
        A file caught mid-sync that fails to read → the last good copy, with a note."""
        with self._hr_lock:
            st = p.stat()
            key = (str(p), st.st_mtime_ns, st.st_size, __version__)
            if self._hr and self._hr[0] == key:
                return self._hr[1], None
            cache = self._store.base / "hourly.pkl"
            try:
                with open(cache, "rb") as fh:
                    saved_key, df = pickle.load(fh)
                if saved_key == key:
                    self._hr = (key, df)
                    return df, None
            except Exception:  # no cache / other file / older app version
                pass
            try:
                df = hourlymod.load_hourly(p)
            except Exception as e:
                if self._hr:
                    return self._hr[1], f"Chưa đọc được bản mới của file hourly ({e}) – đang hiện bản trước"
                raise
            self._hr = (key, df)
            tmp = cache.with_name(f"hourly.{uuid.uuid4().hex[:6]}.tmp")
            try:
                with open(tmp, "wb") as fh:
                    pickle.dump((key, df), fh, protocol=pickle.HIGHEST_PROTOCOL)
                replace(tmp, cache)
            except OSError:
                tmp.unlink(missing_ok=True)
            return df, None

    @safe
    def hourly_status(self) -> dict:
        """Cheap check the UI polls: which hourly file, and its modified time / size signature (changes → reload)."""
        return self._hourly_status()

    @safe
    def hourly_refresh(self) -> dict:
        """“Làm mới”: a SharePoint hourly file is downloaded now, signing in first if the session is over."""
        return self._hourly_status(force=True, login=True)

    @safe
    def pick_hourly(self) -> dict:
        """Pick the hourly export by hand (remembered)."""
        if self._window is None:
            raise RuntimeError("Chưa mở cửa sổ app")
        import webview
        picked = self._window.create_file_dialog(webview.FileDialog.OPEN, file_types=(
            "Excel / SharePoint shortcut (*.xlsx;*.url)", "Excel (*.xlsx)"))
        path = (picked[0] if isinstance(picked, (list, tuple)) else picked) if picked else None
        if not path:
            return self._hourly_status()
        if path.lower().endswith(".url"):  # "Add shortcut to My files" on SharePoint → downloaded every hour
            link_of(Path(path))  # not a SharePoint shortcut → error
            copy = self._hourly_copy(Path(path), force=True, login=True)
            if copy is None:
                raise SharePointError(self._hr_err or "Không tải được file hourly từ SharePoint")
            if not hourlymod.is_hourly(copy):
                raise InputError(f"Không phải file hourly: cần sheet {hourlymod.SHEET} có cột {', '.join(hourlymod.NEED)}")
        elif not hourlymod.is_hourly(Path(path)):
            raise InputError(f"Không phải file hourly: cần sheet {hourlymod.SHEET} có cột {', '.join(hourlymod.NEED)}")
        self._store.save_settings({"hourly_path": str(path)})
        return self._hourly_status()

    def _hourly_data(self) -> tuple:
        """(status, hourly frame, note, signature) the Hourly tab reads – shared by hourly() and hourly_drivers()."""
        status, df, note = self._hourly_status(), None, None
        sig = status.get("sig")
        # Viewers read the push; a Lead / Team Lead reads it too when it holds newer data than its own file (another
        # Lead pushed) – so the Admin, Team Lead and Operators all see the same latest hour.
        shared = status if status.get("shared") else status.get("team_copy")
        if shared:
            try:
                sdf, meta = self._hourly_shared_frame(shared)
                mine = None
                if not status.get("shared") and status.get("path"):
                    try:
                        mine = self._hourly_frame(Path(status["path"]))
                    except Exception:  # noqa: BLE001 – own file unreadable: the team's copy is shown
                        mine = None
                if mine is None or meta["last"] > _hr_last(mine[0]):
                    df = sdf
                    status = {**shared, "by": meta.get("by"), "modified": meta.get("at") or shared["modified"],
                              "file_modified": meta.get("modified"), "team_share": status.get("team_share")}
                else:
                    df, note = mine
            except (PackageError, TeamError, PermissionError, KeyError, ValueError) as e:
                if status.get("shared"):
                    note = f"Chưa đọc được hourly Lead chia sẻ ({e}) – dùng file hourly trên máy này"
                    status = self._hourly_file_status()
        if df is None:
            if not status["path"] and status.get("sp_error"):
                raise SharePointError(f"File hourly trên SharePoint: {status['sp_error']} – bấm “Làm mới”")
            if not status["path"]:
                wait = " hoặc chờ Lead chia sẻ" if self._viewer() else ""
                raise ValueError(f"Chưa có file hourly – bấm “Chọn file hourly…”{wait} ({self._layout().hourly_file})")
            df, file_note = self._hourly_frame(Path(status["path"]))
            note = " · ".join(x for x in (note, file_note) if x) or None
        return status, df, note, sig

    @safe
    def hourly(self, filters: dict | None = None, run_id: str | None = None) -> dict:
        """Hourly tab. Product Info / KPI / raw_sso_us come from the latest run's files; the hourly export is read
        from disk (re-read when it changes). Members always get their own PIC."""
        f = dict(filters or {})
        run = self._run_or_latest(run_id)
        rj = run["result"]
        if self._role() == "member":
            f["pic"] = self._team().get("pic")
        status, df, note, sig = self._hourly_data()
        logic = load_logic(self._run_logic_path(rj))
        label = logic.texts.get("team_label", "") if rj.get("model") == "score_v3" else ""
        out = hourlymod.hourly(self._ensure_inputs(), df, rj, label, f.get("pic") or None, f.get("leader") or None,
                               f.get("pl") or None, f.get("sku") or None, f.get("start"), f.get("end"))
        status = {k: v for k, v in status.items() if k != "team_copy"}
        return {"run_id": run["run_id"], "source": {**status, "sig": sig}, "note": note, **out}

    @safe
    def hourly_drivers(self, filters: dict | None = None, day: str | None = None, run_id: str | None = None) -> dict:
        """feedback #84: the Performance Review change-driver table on the Hourly tab – one day vs the day before, from
        the hourly file, with the Hourly filters (PIC / Sales Leader / PL / SKU); on demand, like performance_drivers()."""
        f = dict(filters or {})
        rj = self._run_or_latest(run_id)["result"]
        if self._role() == "member":
            f["pic"] = self._team().get("pic")
        _, df, _, _ = self._hourly_data()
        label = load_logic(self._run_logic_path(rj)).texts.get("team_label", "") if rj.get("model") == "score_v3" else ""
        return hourlymod.hourly_drivers(self._ensure_inputs(), df, rj, label, f.get("pic") or None, f.get("leader") or None,
                                        f.get("pl") or None, f.get("sku") or None, day)

    @safe
    @runner_only
    def hourly_push(self) -> dict:
        """Lead: share the parsed hourly file with the team inside the newest report – one part per PIC (only its
        ASINs, for its members' devices) + the full one for Operators / other Leads, signed like reports. The UI
        calls it every few minutes and after an upload; it pushes only when the file, the newest report or the
        team's devices changed. Members / Operators read it on the Hourly tab instead of their own file."""
        if not self._hr_push.acquire(blocking=False):
            return {"pushed": False, "busy": True}
        try:
            return self._push_hourly()
        finally:
            self._hr_push.release()

    def _push_hourly(self) -> dict:
        status = self._hourly_file_status()
        if not status.get("path"):
            return {"pushed": False, "reason": "no_file"}
        sb = self._sb()
        reports = self._team_reports(sb)
        if not reports:
            return {"pushed": False, "reason": "no_report"}
        folder, lead = reports[0], self._lead_keys()
        rows = [r for r in sb.members() if r["active"]]
        me = next((r for r in rows if r["email"] == (self._team().get("email") or "").lower()), None)
        if not me or me.get("sign_pub") != _pub64(lead.sign_public):
            raise PermissionError("khoá Lead trên máy này không còn là khoá của nhóm – nhập file khoá Lead mới")
        readers, _, others = self._readers(rows, lead)
        devices = sorted(f"{p}:{reader_id(k)}" for p, ks in [*readers.items(), ("", others)] for k in ks)
        key = hashlib.sha256(json.dumps([folder, status["sig"], devices]).encode()).hexdigest()[:24]
        prev = self._store.get_settings().get("hourly_share") or {}
        if prev.get("key") == key:
            return {"pushed": False, "shared": prev}
        df, _ = self._hourly_frame(Path(status["path"]))
        last = _hr_last(df)
        # Admin and Team Lead both push into the same files: never replace newer data with an older file
        if shared := self._hourly_shared_entry():
            try:
                _, smeta = self._hourly_shared_frame(shared)
            except (PackageError, TeamError, PermissionError, KeyError, ValueError):
                smeta = None  # unreadable (an old key): this push replaces it
            if smeta and smeta["last"] > last:
                return {"pushed": False, "reason": "newer_shared", "shared": prev or None}
        rj, products = self._latest()["result"], self._ensure_inputs().products

        def asins_of(pic: str) -> set:  # as share.filter_inputs: the ASINs of this PIC's product lines
            return set(products.loc[products["pl"].isin({r["pl"] for r in rj["pl"] if r.get("pic") == pic}), "asin"])

        now = datetime.now()
        meta = {"kind": "hourly", "by": self._team().get("name") or "Lead", "at": now.isoformat(timespec="seconds"),
                "modified": status.get("modified"), "last": last, "app": __version__}
        size = 0
        for name, part, who in [(LEAD_FILE, df, others)] + [(pic_file(p), df[df["asin"].isin(asins_of(p))], readers[p]) for p in readers]:
            blob = build_package({"hourly": ({"hourly.json": _frame_bytes(part)}, who)}, meta, lead)
            sb.overwrite(f"{folder}/{HOURLY_DIR}/{name}", blob)
            size += len(blob)
        state = {"key": key, "folder": folder, "at": meta["at"], "pics": len(readers), "size": size}
        self._store.save_settings({"hourly_share": state})
        return {"pushed": True, "shared": state}

    def _prev_listing(self, run: dict) -> dict[str, str] | None:
        """{asin: issue} saved for the latest data day before this run's data day – the baseline for 'today' diffs.
        Hết hàng is stripped: it's tracked under OOS, not as a listing issue."""
        if self._viewer():  # saved into the report by upload_report (reports from before v0.1.23 lack it)
            return self._latest().get("prev_listing")
        day = ((run["result"].get("inputs") or {}).get("raw") or {}).get("last") or ""
        h = self._store.listing_history()
        prev = max((d for d in h if d < day), default=None)
        if prev is None:
            return None
        return {a: v for a, iss in h[prev].items() if (v := " · ".join(x for x in str(iss).split(" · ") if x != OOS))}

    @safe
    @runner_only
    def save_score_weights(self, weights: dict) -> dict:
        keys = {m["key"] for m in METRICS}
        clean = {k: max(0.0, float(v)) for k, v in weights.items() if k in keys}
        self._store.save_settings({"score_weights": clean})
        return {"weights": clean}

    @safe
    @runner_only
    def team_review(self, run_id: str | None = None) -> dict:
        run = self._run_or_latest(run_id)
        sc = scorecard(run["result"], self._store.get_settings().get("score_weights") or {})
        wk = self._weekly(run["result"])
        hist = self._runs_history()
        out = self._ask(team_prompt(sc, wk, hist), TEAM_SCHEMA)
        facts = [{**p["values"], **{f"score_{k}": v for k, v in p["scores"].items()}, "total": p["total"],
                  "rank": p["rank"]} for p in sc["pics"]] + wk + [{"time_gone": sc["time_gone"]}]
        facts += [v for h in hist for v in h["by_pic"].values()]
        dropped = 0
        if not grounded(out["summary"], facts):
            out["summary"], dropped = "", dropped + 1
        for key, fields in (("highlights", ("text",)), ("improve", ("text", "suggestion"))):
            kept = [x for x in out[key] if all(grounded(x.get(f, ""), facts) for f in fields)]
            dropped += len(out[key]) - len(kept)
            out[key] = kept
        review = {**out, "dropped": dropped, "created": datetime.now().isoformat(timespec="seconds")}
        self._store.save_run_field(run["run_id"], "team_review", review)
        return review

    # ------------------------------------------------------------- presentation
    def _deck_out(self) -> dict | None:
        d = self._deck
        return d and {**d, "slides": [{k: v for k, v in s.items() if k != "facts"} for s in d["slides"]]}

    def _save_deck(self, push: bool = True) -> None:
        if not self._viewer():  # a viewer's report is read-only; their deck lives for this session
            self._store.save_run_field(self._deck["run_id"], "deck", self._deck)
        if push:
            self._push()

    def _push(self) -> None:
        """Mirror the deck + slide state into every window that shows it."""
        js = f"window.deckSync && deckSync({json.dumps({'deck': self._deck_out(), 'show': self._show}, default=str)})"
        for w in (self._window, self._audience):
            if w is not None:
                try:
                    w.evaluate_js(js)
                except Exception:  # noqa: BLE001 – a closing window must not break the other one
                    pass

    @safe
    def deck(self, run_id: str | None = None) -> dict:
        run = self._run_or_latest(run_id)
        if not self._deck or self._deck.get("run_id") != run["run_id"]:
            self._deck = run.get("deck")
        return {"cats": [{"key": k, "label": v} for k, v in deckmod.CATEGORIES], "deck": self._deck_out(),
                "show": self._show, "presenting": self._audience is not None}

    @safe
    def deck_build(self, cats: list[str], run_id: str | None = None) -> dict:
        run = self._run_or_latest(run_id)
        sc = scorecard(run["result"], self._store.get_settings().get("score_weights") or {})
        if self._role() == "member":  # same rule as the dashboard: only this PIC's scores travel in the report
            sc["pics"] = [run["my_scorecard"]] if run.get("my_scorecard") else []
        self._deck = deckmod.build(run, sc, self._weekly(run["result"]), cats)
        self._show = {"i": 0, "pop": None}
        self._save_deck()
        return {"deck": self._deck_out()}

    @safe
    def deck_edit(self, instruction: str, index: int | None = None) -> dict:
        if not self._deck:
            raise ValueError("Chưa tạo bài trình chiếu")
        if not str(instruction).strip():
            raise ValueError("Nhập yêu cầu cho Claude")
        out = self._ask(deckmod.edit_prompt(self._deck, instruction, index), deckmod.EDIT_SCHEMA)
        self._deck, dropped = deckmod.apply_edit(self._deck, out, index)
        self._show["i"] = min(self._show["i"], len(self._deck["slides"]) - 1)
        self._save_deck()
        return {"deck": self._deck_out(), "dropped": dropped}

    @safe
    def deck_notes(self, index: int, notes: str) -> dict:
        """Speaker notes typed by the user. Not pushed: the audience screen never shows notes, and a push would
        re-render the presenter view under the user's cursor."""
        if not self._deck:
            raise ValueError("Chưa tạo bài trình chiếu")
        self._deck["slides"][int(index)]["notes"] = str(notes or "")[:5000]
        self._save_deck(push=False)
        return {}

    @safe
    def present_start(self) -> dict:
        """External monitor connected: slides full-screen there, this window becomes the presenter view.
        One screen: {"external": False} and the UI goes full-screen itself."""
        if self._window is None:  # before touching webview.screens: without a GUI backend (Linux CI) it raises
            return {"external": False}
        import webview
        screens = list(getattr(webview, "screens", []) or [])
        if len(screens) < 2:
            if not self._full:
                self._window.toggle_fullscreen()
                self._full = True
            return {"external": False}
        if self._audience is None:
            wx, wy = getattr(self._window, "x", 0) or 0, getattr(self._window, "y", 0) or 0
            here = lambda s: s.x <= wx < s.x + s.width and s.y <= wy < s.y + s.height  # noqa: E731
            other = next((s for s in screens if not here(s)), screens[1])
            from .app import ui_path
            self._audience = webview.create_window("PMKT Alert – trình chiếu", url=str(ui_path().with_name("present.html")),
                                                   js_api=self, screen=other, fullscreen=True, background_color="#0B1220")
            self._audience.events.closed += self._audience_closed
        return {"external": True}

    def _audience_closed(self) -> None:
        self._audience = None
        if self._window is not None:
            self._window.evaluate_js("window.presentEnded && presentEnded()")

    @safe
    def present_state(self) -> dict:
        return {"deck": self._deck_out(), "show": self._show}

    @safe
    def present_show(self, i: int, pop=None) -> dict:
        """Either window moves the show (slide / opened popup); both follow."""
        n = len((self._deck or {}).get("slides") or [])
        self._show = {"i": max(0, min(int(i), n - 1)), "pop": pop}
        self._push()
        return self._show

    @safe
    def present_stop(self) -> dict:
        if self._full and self._window is not None:
            self._window.toggle_fullscreen()
        self._full = False
        if self._audience is not None:
            w, self._audience = self._audience, None
            w.destroy()
        return {}

    @safe
    def results(self, run_id: str | None = None) -> dict:
        if self._viewer():
            return self.open_report(run_id) if run_id else self._latest()
        return self._store.load_run(run_id) if run_id else self._latest()

    @safe
    def claude_status(self) -> dict:
        return self._status().to_dict()

    @safe
    def claude_stats(self) -> dict:
        return {"usage": cc_usage()}

    @safe
    def install_claude(self) -> dict:
        out = install_claude_cli()
        return {**out, "status": self._status().to_dict()}

    @safe
    def open_claude_login(self) -> dict:
        exe = claude_exe()
        if not exe:
            raise RuntimeError("Chưa cài Claude Code")
        open_login(exe)
        return {"ok": True}

    # ------------------------------------------------------------- feedback & review
    @safe
    @runner_only
    def submit_feedback(self, item: dict) -> dict:
        run = self._store.load_run(item["run_id"]) if item.get("run_id") else self._latest()
        if not run:
            raise ValueError("Không tìm thấy lần chạy")
        rows = {r["unit_id"]: r for r in run["result"]["pl"] + run["result"]["camp"]}
        row = rows.get(item.get("unit_id"), {})
        fid = self._store.add_feedback({**item, "run_id": run["run_id"],
                                        "logic_version": run["result"]["logic_version"], "row": row})
        fb = next(f for f in self._store.list_feedback() if f["id"] == fid)
        try:
            out = propose_from_feedback(fb, row, self._logic(), self._store, self._ensure_inputs(),
                                        date.fromisoformat(run["result"]["as_of"]), ask_fn=self._ask)
        except ClaudeError as e:
            return {"feedback_id": fid, "error": f"Đã lưu góp ý, nhưng Claude chưa phân tích được: {e}"}
        return {"feedback_id": fid, **out}

    @safe
    def review(self) -> dict:
        if self._viewer():
            run = self._latest()
        else:
            runs = self._store.list_runs()
            run = self._store.load_run(runs[0]["run_id"]) if runs else {}
        res, ai = run.get("result") or {}, run.get("ai") or {}
        issues = res.get("logic_issues") or []
        logic_eval = ai.get("logic_eval")
        if issues and not logic_eval:  # run without Claude: still show rule-based verdicts
            logic_eval = evaluate_logic(issues, load_logic(self._store.active_logic()), ask_fn=always_fail)
        return {"findings": ai.get("review") or [], "proposals": self._store.proposals(),
                "feedback": self._store.list_feedback(), "logic_issues": issues, "logic_eval": logic_eval,
                "logic_file": res.get("logic_file")}

    @safe
    @runner_only
    def set_proposal(self, pid: str, status: str, new=None) -> dict:
        if status not in ("approved", "rejected", "pending"):
            raise ValueError("Trạng thái không hợp lệ")
        if new is not None:  # user edited the proposed value before approving
            prop = next((p for p in self._store.proposals() if p["id"] == pid), None)
            key = prop and prop.get("param_key")
            if key:
                try:
                    val = str(new) if key.startswith("matrix:") else float(new)
                except (TypeError, ValueError):
                    raise ValueError("Giá trị phải là số")
                if not valid_change(key, val, self._logic()):
                    raise ValueError("Giá trị không hợp lệ")
                self._store.update_proposal(pid, {"new": val})
        self._store.set_proposal_status(pid, status)
        return {"proposals": self._store.proposals()}

    @safe
    @runner_only
    def apply_proposals(self) -> dict:
        out = apply_approved(self._store, self._logic())
        self._ensure_inputs()
        run = self.run(self._paths)
        return {**run, "logic_file": out.name}

    # ------------------------------------------------------------- lessons & history
    @safe
    def lessons(self) -> dict:
        return {"lessons": self._store.lessons()}

    @safe
    @runner_only
    def delete_lesson(self, lid: str) -> dict:
        self._store.delete_lesson(lid)
        return {"lessons": self._store.lessons()}

    @safe
    def history(self) -> dict:
        if self._viewer():
            return {"runs": [{"run_id": r["name"], "as_of": None, "logic_version": None, "alert_count": None,
                              "feedback_count": None} for r in self.list_reports().get("reports", [])[:30]],
                    "logic_versions": []}
        active = self._store.active_logic()
        return {"runs": self._store.list_runs(),
                "logic_versions": [{"version": v, "name": p.name, "active": p == active}
                                   for v, p in self._store.logic_versions()]}

    @safe
    @runner_only
    def set_active_logic(self, version: int) -> dict:
        self._store.set_active_logic(int(version))
        return self.history()

    # ------------------------------------------------------------- style & settings
    @safe
    def get_style(self) -> dict:
        return self._store.get_style()

    @safe
    @runner_only
    def save_style(self, d: dict) -> dict:
        self._store.save_style(d)
        return self._store.get_style()

    @safe
    @runner_only
    def add_style_sample(self, text: str) -> dict:
        self._store.add_style_sample(text)
        return self._store.get_style()

    @safe
    @runner_only
    def preview_style(self) -> dict:
        run = self._latest()
        d = max(run["result"]["digest"], key=lambda x: x["camp_high"] + x["pl_high"])
        rows = pic_rows(run["result"], d["pic"])
        out = self._ask(style_prompt(self._store.get_style(), d, {"pl": rows["pl"][:5], "camp": rows["camp"][:8]}), STYLE_SCHEMA)
        return {"slack": out["slack"], "pic": d["pic"]}

    @safe
    @runner_only
    def save_pic_address(self, pic: str, d: dict) -> dict:
        self._store.set_pic_address(pic, d)
        return self._store.get_style()

    @safe
    @runner_only
    def rewrite_message(self, pic: str, run_id: str | None = None) -> dict:
        run = self._store.load_run(run_id) if run_id else self._latest()
        if not run:
            raise ValueError("Không tìm thấy lần chạy")
        d = next((x for x in run["result"]["digest"] if x["pic"] == pic), None)
        if d is None:
            raise ValueError(f"Không có PIC {pic} trong lần chạy này")
        rows = pic_rows(run["result"], pic)
        out = self._ask(style_prompt(self._store.get_style(), d, {"pl": rows["pl"], "camp": rows["camp"]}), STYLE_SCHEMA)
        context = {"time_gone": Windows(date.fromisoformat(run["result"]["as_of"])).time_gone}
        if not grounded(out["slack"], list(rows["all"].values()) + [d, context]):
            raise ValueError("Claude viết số không khớp dữ liệu – đã giữ tin nhắn cũ, thử lại nhé")
        ai = run.get("ai") or {"claude_ok": True, "error": None, "review": [], "per_pic": {}}
        ai["per_pic"].setdefault(pic, {"insights": [], "todos": [], "dropped": 0})["slack"] = out["slack"]
        self._store.update_run_ai(run["run_id"], ai)
        return {"slack": out["slack"], "pic": pic}

    @safe
    def memory_info(self) -> dict:
        return self._store.usage()

    @safe
    @runner_only
    def history_info(self) -> dict:
        """Daily data kept from past runs (raw_sso_us + ads_camp + INELIGIBLE ASIN, last 3 months)."""
        return self._history().info()

    @safe
    @runner_only
    def history_delete(self, month: str | None = None) -> dict:
        """Delete one month (YYYY-MM) of stored daily data, or all of it (month = None)."""
        if month is not None and not re.fullmatch(r"\d{4}-\d{2}", str(month)):
            raise ValueError("Tháng không hợp lệ")
        self._history().delete(month)
        self._inputs = None  # reload without the deleted days
        return self._history().info()

    @safe
    @runner_only
    def prune_memory(self) -> dict:
        deleted = self._store.prune()
        return {"deleted": deleted, **self._store.usage()}

    @safe
    def get_settings(self) -> dict:
        return self._store.get_settings()

    @safe
    def save_settings(self, d: dict) -> dict:
        if self._role() == "member" and set(d) - MEMBER_SETTINGS:
            raise PermissionError(LEAD_ONLY)
        self._store.save_settings(d)
        return self._store.get_settings()

    @safe
    def email_map_suggestions(self) -> dict:
        saved = self._store.get_settings().get("email_map", {})
        users = sorted({u for u in self._ensure_inputs().activity["user"].dropna().astype(str).str.strip().str.lower() if u})
        pics = sorted({d["pic"] for d in self._latest()["result"]["digest"]})
        suggested = suggest_email_map(users, pics)
        return {"email_map": {u: saved.get(u) or suggested.get(u, "") for u in users}, "pics": pics}

    # ------------------------------------------------------------- update & export
    @safe
    def latest_tag(self) -> dict:
        return {"tag": self._tag(self._repo())}

    @safe
    def check_update(self) -> dict:
        repo = self._repo()
        rel = self._release(repo)
        return {"current": __version__, "repo": repo, "latest": rel.tag if rel else None,
                "newer": bool(rel and is_newer(rel.tag, __version__)), "notes": rel.notes if rel else "",
                "published": rel.published if rel else "",
                "previous": [{"tag": r.tag, "notes": r.notes, "published": r.published} for r in self._recent(repo)][1:]
                if rel else []}

    def _feedback_sb(self, call):
        """Run a feedback call; a project set up before feedback existed has no table yet."""
        try:
            return call(self._sb())
        except TeamError as e:
            if "pmkt_feedback" in str(e) or "404" in str(e):
                raise TeamError("Máy chủ nhóm chưa có mục Góp ý – Lead cần chạy lại SQL thiết lập "
                                "(Supabase → SQL Editor, hoặc scripts/provision_supabase.py)") from None
            raise

    def _feedback_upload(self, sb, files: list) -> list[str]:
        """Upload new attachments ({name, data}) to feedback/<own email>/<uuid>/<name>; storage paths back."""
        email, paths = (self._team().get("email") or "").lower(), []
        for name, blob in files:
            path = f"{email}/{uuid.uuid4().hex}/{name}"
            sb.upload(path, blob, bucket="feedback", content_type=FEEDBACK_TYPES[_feedback_ext(name)][0])
            paths.append(path)
        return paths

    @safe
    def send_feedback(self, kind: str, message: str, context: dict | None = None, files: list | None = None) -> dict:
        """Any signed-in team member. Version and role are added here, not trusted from the page.
        files: [{name, data: data URL}], at most FEEDBACK_MAX_FILES of FEEDBACK_TYPES, each ≤ FEEDBACK_MAX_BYTES."""
        message = (message or "").strip()
        if kind not in ("bug", "idea"):
            raise ValueError("Chọn loại: Lỗi hoặc Góp ý")
        if not message:
            raise ValueError("Nhập nội dung góp ý")
        if len(files or []) > FEEDBACK_MAX_FILES:
            raise ValueError(f"Tối đa {FEEDBACK_MAX_FILES} tệp")
        blobs = [_feedback_file(x) for x in (files or [])]
        ctx = {**{k: str(v)[:200] for k, v in (context or {}).items()}, "version": __version__, "role": self._role()}
        self._feedback_sb(lambda sb: sb.send_feedback({"kind": kind, "message": message[:4000], "context": ctx,
                                                        "images": self._feedback_upload(sb, blobs)}))
        return {"ok": True}

    def _feedback_mine(self) -> str | None:
        """None for the Lead (reviews every ticket); otherwise the signed-in email (own tickets only)."""
        if not self._secrets().get("session"):
            raise PermissionError(SIGN_IN_FIRST)
        return None if self._role() == "lead" else (self._team().get("email") or "").lower()

    @safe
    def feedback_image(self, path: str) -> dict:
        """One attached image as a data URL (the bucket is private, so the page cannot load it directly).
        Who may read which file is enforced by the storage policy (own tickets; the Lead reads all)."""
        self._feedback_mine()
        ext = _feedback_ext(path)
        if ext not in FEEDBACK_IMAGES:
            raise ValueError("Ảnh không hợp lệ")
        blob = self._feedback_sb(lambda sb: sb.download(path, bucket="feedback"))
        return {"url": f"data:{FEEDBACK_TYPES[ext][0]};base64," + base64.b64encode(blob).decode()}

    @safe
    def save_feedback_file(self, path: str, dest: str | None = None) -> dict:
        """Download one attachment and save it where the person picks."""
        self._feedback_mine()
        if _feedback_ext(path) not in FEEDBACK_TYPES:
            raise ValueError("Tệp không hợp lệ")
        if not dest:
            if self._window is None:
                raise RuntimeError("Chưa mở cửa sổ app")
            import webview
            picked = self._window.create_file_dialog(webview.FileDialog.SAVE, save_filename=path.rsplit("/", 1)[-1])
            if not picked:
                return {"cancelled": True}
            dest = picked if isinstance(picked, str) else picked[0]
        Path(dest).write_bytes(self._feedback_sb(lambda sb: sb.download(path, bucket="feedback")))
        return {"path": str(dest)}

    @safe
    def feedback_list(self) -> dict:
        """Lead: every ticket (to review). Anyone else: only the tickets they sent (RLS enforces the same)."""
        mine = self._feedback_mine()
        items = self._feedback_sb(lambda sb: sb.feedback()) or []
        return {"items": [x for x in items if mine is None or x["email"].lower() == mine], "all": mine is None}

    @safe
    @admin_only
    def feedback_review(self, fid: int, status: str, message: str | None = None, note: str | None = None,
                        files: list | None = None) -> dict:
        """Lead: approve / reject a ticket, optionally rewriting its text and attachments (the server keeps the
        originals). files: the full new list – kept storage paths (str) and new uploads ({name, data})."""
        if status not in ("approved", "rejected"):
            raise ValueError("Trạng thái không hợp lệ")
        if message is not None and not message.strip():
            raise ValueError("Nhập nội dung góp ý")
        if files is not None and len(files) > FEEDBACK_MAX_FILES:
            raise ValueError(f"Tối đa {FEEDBACK_MAX_FILES} tệp")
        new = [_feedback_file(x) for x in files or [] if not isinstance(x, str)]

        def review(sb):
            up = iter(self._feedback_upload(sb, new))
            images = None if files is None else [x if isinstance(x, str) else next(up) for x in files]
            sb.review_feedback(fid, status, message and message[:4000], note and note[:1000], images)
        self._feedback_sb(review)  # ponytail: files dropped in an edit stay in storage; add cleanup if space matters
        return {"ok": True}

    @safe
    def whats_new(self) -> dict:
        """Notes for the installed version from the bundled CHANGELOG.md; `show` once after each update."""
        sections = parse_changelog(bundled_text())
        cur = __version__.split("-")[0]
        mine = sections.get(cur, {"date": "", "notes": ""})
        seen = self._store.get_settings().get("last_seen_version")
        return {"version": cur, "date": mine["date"], "notes": mine["notes"],
                "show": "-dev" not in __version__ and seen != __version__ and bool(mine["notes"]),
                "previous": [{"tag": f"v{v}", "notes": s["notes"], "published": s["date"]}
                             for v, s in sections.items() if v != cur][:5]}

    @safe
    def mark_whats_new_seen(self) -> dict:
        self._store.save_settings({"last_seen_version": __version__})
        return {"ok": True}

    @safe
    def install_update(self) -> dict:
        rel = self._release(self._repo())
        if not rel or not is_newer(rel.tag, __version__):
            raise ValueError("Không có bản cập nhật mới")
        exe = download_verified(rel, self._home.base / "updates")
        apply_update(exe)
        if self._window is not None:
            self._window.destroy()
        return {"ok": True}

    @safe
    @lead_only
    def export(self, pic: str, path: str | None = None, run_id: str | None = None) -> dict:
        run = self._store.load_run(run_id) if run_id else self._latest()
        if not run:
            raise ValueError("Không tìm thấy lần chạy")
        if path is None:
            import webview
            picked = self._window.create_file_dialog(webview.SAVE_DIALOG, save_filename=f"PMKT Alert - {pic}.xlsx")
            if not picked:
                return {"cancelled": True}
            path = picked if isinstance(picked, str) else picked[0]
        return {"path": str(export_pic(run["result"], run.get("ai"), pic, Path(path))), "run_id": run["run_id"]}
