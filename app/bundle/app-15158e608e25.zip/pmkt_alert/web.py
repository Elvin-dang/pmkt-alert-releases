"""The web viewer (PWA): the same Api, run in the browser by Pyodide, for reading the team's reports only.

Everyone signs in with their PMKT Alert account and reads exactly what the desktop app would let them read (a Member
their PIC, staff the full report): the report is downloaded encrypted and opened on the device with the keys the
account backed up on the server (keybackup.py). Nothing is run, uploaded or changed from the web, so a Lead / Team
Lead is a reader here too, and the web never creates or replaces a Lead signing key."""
import base64
import io
import re
import shutil
import tempfile
import urllib.error
from datetime import date
from pathlib import Path

from .api import RUNNERS, Api, safe
from .store import Store

# What the web UI may call: reading reports and the account itself. Everything else answers WEB_ONLY_DESKTOP.
ALLOWED = frozenset({
    "team_info", "team_connect", "team_sign_in", "team_sign_out", "team_change_password", "team_sync",
    "list_reports", "open_report", "startup_open", "results", "dashboard", "performance", "performance_drivers",
    "evidence", "hourly", "hourly_drivers", "hourly_status", "get_settings", "save_settings", "set_work_team", "save_table",
})
# UI preferences only (the desktop's Member list, without the update settings)
WEB_SETTINGS = frozenset({"language", "ui_lang", "nav_mini", "layouts", "last_seen_version"})
WEB_ONLY_DESKTOP = "Chỉ có trên app PMKT Alert cho Windows – bản web chỉ để xem dữ liệu"
NO_LEAD_KEY = ("Tài khoản này chưa có bản sao khoá trên máy chủ. Mở app PMKT Alert trên máy tính và đăng nhập một lần "
               "(khoá sẽ tự theo tài khoản), rồi đăng nhập lại trên web")


class WebApi(Api):
    def __init__(self, store: Store, sb_opener, **kw):
        super().__init__(store, sb_opener=sb_opener, **kw)

    def call(self, method: str, args: list) -> dict:
        """The one entry point of the browser: only ALLOWED methods, the rest is answered, never run."""
        if method not in ALLOWED:
            return {"error": WEB_ONLY_DESKTOP, "kind": "WebOnlyDesktop"}
        return getattr(self, method)(*args)

    # every role reads uploaded reports, like an Operator / Member on the desktop
    def _viewer(self) -> bool:
        return True

    def _register_device(self, sb, row: dict, email: str) -> bool:
        """A Lead / Team Lead needs the team's signing key from its key backup; the web never makes a new one (that
        would lock every member out of new reports) – without the backup it reads nothing (needs_key)."""
        if row["role"] in RUNNERS and not self._keys(email).get("lead"):
            return True
        return super()._register_device(sb, row, email)

    @safe
    def team_sign_in(self, email: str, password: str) -> dict:
        info = Api.team_sign_in.__wrapped__(self, email, password)
        if info.get("needs_key"):  # a Lead without a usable key: nothing to read on the web – don't stay half signed in
            self._sign_out()
            self._wipe()
            raise PermissionError(NO_LEAD_KEY)
        return info

    @safe
    def team_sign_out(self) -> dict:
        """Signing out of the browser also removes the account's keys and the opened report from it (a phone or a
        shared computer): the next sign-in brings the keys back from the server backup."""
        self._sign_out()
        self._wipe()
        return self.team_info()

    @safe
    def save_table(self, title: str, header: list, rows: list, path: str | None = None) -> dict:
        """The table as .xlsx, handed to the browser to download (no file dialog here)."""
        name = (re.sub(r'[\\/:*?"<>|\s]+', " ", title or "").strip()[:80] or "PMKT Alert") + f" {date.today().isoformat()}.xlsx"
        with tempfile.TemporaryDirectory() as d:
            out = Api.save_table.__wrapped__(self, title, header, rows, str(Path(d) / "t.xlsx"))
            data = Path(out["path"]).read_bytes()
        return {"path": name, "download": {"name": name, "b64": base64.b64encode(data).decode(),
                                           "mime": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}}

    @safe
    def save_settings(self, d: dict) -> dict:
        self._store.save_settings({k: v for k, v in (d or {}).items() if k in WEB_SETTINGS})
        return self._store.get_settings()

    def _wipe(self) -> None:
        base = self._home.base
        for p in list(base.iterdir()) if base.exists() else []:
            shutil.rmtree(p, ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True)
        self._home = self._store = Store(base)
        self._workspaces, self._member, self._sb_cache, self._inputs = {}, None, None, None
        self._hr_shared = None
        self._use_team()


# ---------------------------------------------------------------- browser HTTP (Pyodide in a Web Worker)
class _Response:
    def __init__(self, status: int, body: bytes):
        self.status, self._body = status, body

    def read(self) -> bytes:
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def xhr_opener(req, timeout=None):
    """urllib.request.urlopen for Pyodide: a synchronous XMLHttpRequest (allowed – binary too – inside a Web Worker),
    so supabase.py runs unchanged. HTTP errors raise HTTPError with the body, like urllib."""
    from js import Uint8Array, XMLHttpRequest  # noqa: PLC0415 – only exists in the browser
    from pyodide.ffi import to_js  # noqa: PLC0415

    x = XMLHttpRequest.new()
    x.open(req.get_method(), req.full_url, False)
    x.responseType = "arraybuffer"
    for k, v in req.header_items():
        x.setRequestHeader(k, v)
    try:
        x.send(to_js(memoryview(req.data)) if req.data is not None else None)
    except Exception as e:  # network down, CORS, DNS – XHR gives no detail
        raise urllib.error.URLError(f"mạng không truy cập được ({e})") from None
    if x.status == 0:
        raise urllib.error.URLError("mạng không truy cập được")
    body = bytes(Uint8Array.new(x.response).to_py()) if x.response else b""
    if x.status >= 400:
        raise urllib.error.HTTPError(req.full_url, x.status, x.statusText, {}, io.BytesIO(body))
    return _Response(x.status, body)
