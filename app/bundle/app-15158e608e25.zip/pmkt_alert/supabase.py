"""Team backend on Supabase (one project, built into the app – nobody on the team touches infrastructure):
email + password sign-in (accounts are created by a Lead through the pmkt-admin function, no email is ever sent),
the member list (who is Lead, which PIC) and the private "reports" bucket. Every rule is enforced by Postgres row-level security (setup_sql), so a
modified app gets nothing more than its own rows and files. Reports stay encrypted and Lead-signed on top."""
import hashlib
import json
import urllib.error
import urllib.parse
import urllib.request

BUCKET = "reports"


class TeamError(Exception):
    pass


def pic_file(pic: str) -> str:
    """Storage file name of a PIC's part (md5 = the same slug the SQL policy computes; not a secret)."""
    return hashlib.md5(pic.encode("utf-8")).hexdigest() + ".pmkt"


LEAD_FILE = "lead.pmkt"
HOURLY_DIR = "hourly"  # <report>/hourly/<same file names>: the Lead's latest hourly data, replaced as it changes

_SQL = """-- PMKT Alert team setup: run once in Supabase → SQL Editor. Safe to re-run.
create table if not exists public.pmkt_members (
  email text primary key check (email = lower(email)),
  role text not null,                       -- lead (= Admin, every team) | team_lead | operator | member
  pic text,
  name text,
  user_id uuid,                             -- the login (auth.users) – set by the pmkt-admin function
  enc_keys text[] not null default '{}',   -- public encryption keys of the person's devices (set by their app)
  sign_pub text,                            -- Admin / Team Lead: public signing key, readers verify reports with it
  active boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.pmkt_members enable row level security;
revoke all on public.pmkt_members from anon;
grant select, insert, update, delete on public.pmkt_members to authenticated;
alter table public.pmkt_members drop constraint if exists pmkt_members_role_check;
alter table public.pmkt_members add constraint pmkt_members_role_check
  check (role in ('lead', 'team_lead', 'operator', 'member'));

-- Teams (SSO, SFO, ...). Every account belongs to one team, except an Admin (role 'lead'): every team. A Team Lead runs,
-- uploads and manages the Operators / Members of its own team; Operators and Members see only their team's reports.
-- Report folders carry the team: PMKT-Alert-<TEAM>_<date>; a folder without one (PMKT-Alert_<date>, every report from
-- before teams) belongs to the default team.
create table if not exists public.pmkt_teams (
  id text primary key check (id ~ '^[a-z0-9]{2,12}$'),
  name text not null,
  ads_profile text,                         -- the team's Ads profile (campaign on/off, budget, Activity Log)
  is_default boolean not null default false
);
create unique index if not exists pmkt_teams_one_default on public.pmkt_teams (is_default) where is_default;
insert into public.pmkt_teams (id, name, is_default) values ('sso', 'SSO', true), ('sfo', 'SFO', false)
  on conflict (id) do nothing;
alter table public.pmkt_teams enable row level security;
revoke all on public.pmkt_teams from anon;
revoke truncate, references, trigger on public.pmkt_teams from authenticated;
grant select, insert, update, delete on public.pmkt_teams to authenticated;

create or replace function public.pmkt_default_team() returns text language sql stable security definer
  set search_path = public as $$ select id from pmkt_teams where is_default limit 1 $$;

alter table public.pmkt_members add column if not exists team text references public.pmkt_teams(id);
-- An Admin has no team; everyone else has one (the default team when none is given – also for older apps).
create or replace function public.pmkt_members_team() returns trigger language plpgsql security definer
  set search_path = public as $$
begin
  new.team := case when new.role = 'lead' then null else coalesce(new.team, pmkt_default_team()) end;
  return new;
end $$;
drop trigger if exists pmkt_members_team on public.pmkt_members;
create trigger pmkt_members_team before insert or update on public.pmkt_members
  for each row execute function public.pmkt_members_team();
update public.pmkt_members set team = case when role = 'lead' then null else coalesce(team, public.pmkt_default_team()) end
  where (role = 'lead') <> (team is null);
alter table public.pmkt_members drop constraint if exists pmkt_members_team_check;
alter table public.pmkt_members add constraint pmkt_members_team_check check ((role = 'lead') = (team is null));

-- Admin: every team, every account.
create or replace function public.pmkt_is_lead() returns boolean language sql stable security definer
  set search_path = public as $$
  select exists (select 1 from pmkt_members where email = auth.email() and role = 'lead' and active) $$;

create or replace function public.pmkt_is_team_lead() returns boolean language sql stable security definer
  set search_path = public as $$
  select exists (select 1 from pmkt_members where email = auth.email() and role = 'team_lead' and active) $$;

create or replace function public.pmkt_my_team() returns text language sql stable security definer
  set search_path = public as $$
  select team from pmkt_members where email = auth.email() and active $$;

-- Admin, Team Lead or Operator (of any team).
create or replace function public.pmkt_is_staff() returns boolean language sql stable security definer
  set search_path = public as $$
  select exists (select 1 from pmkt_members where email = auth.email() and role in ('lead', 'team_lead', 'operator') and active) $$;

-- Reads a team's full report: an Admin, or that team's Team Lead / Operators.
create or replace function public.pmkt_is_staff_of(p_team text) returns boolean language sql stable security definer
  set search_path = public as $$
  select exists (select 1 from pmkt_members where email = auth.email() and active
                 and (role = 'lead' or (role in ('team_lead', 'operator') and team = p_team))) $$;

-- Runs, uploads and deletes a team's reports: an Admin, or that team's Team Lead.
create or replace function public.pmkt_runs(p_team text) returns boolean language sql stable security definer
  set search_path = public as $$
  select exists (select 1 from pmkt_members where email = auth.email() and active
                 and (role = 'lead' or (role = 'team_lead' and team = p_team))) $$;

create or replace function public.pmkt_folder_team(p_folder text) returns text language sql stable security definer
  set search_path = public as $$
  select coalesce((select id from pmkt_teams where starts_with(p_folder, 'PMKT-Alert-' || upper(id) || '_') limit 1),
                  pmkt_default_team()) $$;

drop policy if exists pmkt_teams_read on public.pmkt_teams;
create policy pmkt_teams_read on public.pmkt_teams for select to authenticated using (true);
drop policy if exists pmkt_teams_admin on public.pmkt_teams;
create policy pmkt_teams_admin on public.pmkt_teams for all to authenticated
  using (public.pmkt_is_lead()) with check (public.pmkt_is_lead());

create or replace function public.pmkt_my_file() returns text language sql stable security definer
  set search_path = public as $$
  select md5(pic) || '.pmkt' from pmkt_members
  where email = auth.email() and role = 'member' and active and pic is not null $$;

-- A device registers its public keys; a member can never set a signing key or change role / PIC / team.
create or replace function public.pmkt_register_keys(p_enc text, p_sign text, p_reset boolean default false)
  returns void language plpgsql security definer set search_path = public as $$
begin
  update pmkt_members set
    enc_keys = (select coalesce(array_agg(k order by n), '{}') from (
                  select k, n from unnest(array_remove(enc_keys, p_enc) || p_enc) with ordinality as t(k, n)
                  order by n desc limit 3) last3),
    sign_pub = case when role in ('lead', 'team_lead', 'operator') and p_sign is not null and (sign_pub is null or p_reset) then p_sign
                    else sign_pub end
  where email = auth.email() and active;
end $$;
revoke all on function public.pmkt_register_keys(text, text, boolean) from public, anon;
grant execute on function public.pmkt_register_keys(text, text, boolean) to authenticated;

-- Who sees which accounts: own row; the Admins' rows (their signing keys); in the own team, its Team Leads and Operators
-- (their keys) – and every row of the team for its Team Lead. The Admin sees all. Never the other team.
drop policy if exists pmkt_read on public.pmkt_members;
create policy pmkt_read on public.pmkt_members for select to authenticated
  using (email = auth.email() or public.pmkt_is_lead() or (role = 'lead' and active)
         or (team = public.pmkt_my_team() and (public.pmkt_is_team_lead() or (role in ('team_lead', 'operator') and active))));
drop policy if exists pmkt_lead_write on public.pmkt_members;
create policy pmkt_lead_write on public.pmkt_members for all to authenticated
  using (public.pmkt_is_lead()) with check (public.pmkt_is_lead());
-- A Team Lead edits its own team's Operators and Members (PIC, name, role between the two) – never moves them to
-- another team, never makes anyone a Lead. Creating, locking and deleting logins go through pmkt-admin.
drop policy if exists pmkt_team_lead_update on public.pmkt_members;
create policy pmkt_team_lead_update on public.pmkt_members for update to authenticated
  using (public.pmkt_is_team_lead() and team = public.pmkt_my_team() and role in ('operator', 'member'))
  with check (public.pmkt_is_team_lead() and team = public.pmkt_my_team() and role in ('operator', 'member'));
-- Operators never edit accounts.
drop policy if exists pmkt_operator_update on public.pmkt_members;

-- Only emails the Lead added (and still active) can create a login.
create or replace function public.pmkt_only_listed() returns trigger language plpgsql security definer
  set search_path = public as $$
begin
  if not exists (select 1 from pmkt_members where email = lower(new.email) and active) then
    raise exception 'PMKT: email chưa được Lead thêm vào nhóm';
  end if;
  return new;
end $$;
drop trigger if exists pmkt_only_listed on auth.users;
create trigger pmkt_only_listed before insert on auth.users for each row execute function public.pmkt_only_listed();

-- Reports: <report>/lead.pmkt (full: the team's staff) + <report>/<md5(PIC)>.pmkt (one per PIC, that PIC's members),
-- hourly in <report>/hourly/. Everything is scoped to the report folder's team.
insert into storage.buckets (id, name, public) values ('reports', 'reports', false) on conflict do nothing;
drop policy if exists pmkt_reports_read on storage.objects;
create policy pmkt_reports_read on storage.objects for select to authenticated
  using (bucket_id = 'reports' and (public.pmkt_is_staff_of(public.pmkt_folder_team(split_part(name, '/', 1)))
         or (storage.filename(name) = public.pmkt_my_file()
             and public.pmkt_folder_team(split_part(name, '/', 1)) = public.pmkt_my_team())));
drop policy if exists pmkt_reports_insert on storage.objects;
create policy pmkt_reports_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'reports' and public.pmkt_runs(public.pmkt_folder_team(split_part(name, '/', 1))));
drop policy if exists pmkt_reports_delete on storage.objects;
create policy pmkt_reports_delete on storage.objects for delete to authenticated
  using (bucket_id = 'reports' and public.pmkt_runs(public.pmkt_folder_team(split_part(name, '/', 1))));
alter table public.pmkt_members add column if not exists user_id uuid;

-- In-app feedback: every role sends and reads their own; the Lead also reads all and reviews new tickets
-- (pmkt_review_feedback). Only approved tickets get worked on; processing (fix under way), done and fixed_in are set
-- by the app owner (service key).
create table if not exists public.pmkt_feedback (
  id bigint generated always as identity primary key,
  email text not null default auth.email(),
  kind text not null check (kind in ('bug', 'idea')),
  message text not null check (length(message) between 1 and 4000),
  context jsonb not null default '{}',
  status text not null default 'new' check (status in ('new', 'done')),
  created_at timestamptz not null default now()
);
alter table public.pmkt_feedback enable row level security;
revoke all on public.pmkt_feedback from anon;
grant select, insert on public.pmkt_feedback to authenticated;
revoke update on public.pmkt_feedback from authenticated;
create or replace function public.pmkt_is_active() returns boolean language sql stable security definer
  set search_path = public as $$
  select exists (select 1 from pmkt_members where email = auth.email() and active) $$;
alter table public.pmkt_feedback add column if not exists images text[] not null default '{}';
-- App version that shipped the fix (e.g. 0.1.22), filled when the fix is released; shown to the sender.
alter table public.pmkt_feedback add column if not exists fixed_in text;
-- Screenshots: feedback/<sender email>/<uuid>.<ext>; sender writes and reads own folder only.
insert into storage.buckets (id, name, public) values ('feedback', 'feedback', false) on conflict do nothing;
drop policy if exists pmkt_feedback_img_insert on storage.objects;
create policy pmkt_feedback_img_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'feedback' and split_part(name, '/', 1) = auth.email() and public.pmkt_is_active());
drop policy if exists pmkt_feedback_img_read on storage.objects;
create policy pmkt_feedback_img_read on storage.objects for select to authenticated
  using (bucket_id = 'feedback' and (split_part(name, '/', 1) = auth.email() or public.pmkt_is_lead()
    or exists (select 1 from public.pmkt_feedback f where f.email = auth.email() and name = any(f.images))));
drop policy if exists pmkt_feedback_insert on public.pmkt_feedback;
create policy pmkt_feedback_insert on public.pmkt_feedback for insert to authenticated
  with check (email = auth.email() and public.pmkt_is_active());  -- status: set by pmkt_feedback_stamp
drop policy if exists pmkt_feedback_read on public.pmkt_feedback;
create policy pmkt_feedback_read on public.pmkt_feedback for select to authenticated
  using (email = auth.email() or public.pmkt_is_lead());
drop policy if exists pmkt_feedback_update on public.pmkt_feedback;
-- Lead review: new → approved / rejected (changeable until processing / done). An edit keeps the sender's text in
-- original_message (written once, never overwritten). No update grant: this function is the only way in.
alter table public.pmkt_feedback drop constraint if exists pmkt_feedback_status_check;
alter table public.pmkt_feedback add constraint pmkt_feedback_status_check
  check (status in ('new', 'approved', 'rejected', 'processing', 'done'));
alter table public.pmkt_feedback add column if not exists original_message text;
alter table public.pmkt_feedback add column if not exists review_note text;
alter table public.pmkt_feedback add column if not exists reviewed_by text;
alter table public.pmkt_feedback add column if not exists reviewed_at timestamptz;
-- Attachments (images = storage paths, up to 5 files): an edit may drop the sender's files and add the Lead's own
-- (feedback/<lead email>/...); original_images keeps the sender's list (written once).
alter table public.pmkt_feedback add column if not exists original_images text[];
drop function if exists public.pmkt_review_feedback(bigint, text, text, text);
create or replace function public.pmkt_review_feedback(p_id bigint, p_status text, p_message text default null,
  p_note text default null, p_images text[] default null) returns void language plpgsql security definer
  set search_path = public as $$
declare m text := nullif(btrim(p_message), '');
begin
  if not pmkt_is_lead() then raise exception 'PMKT: chỉ Lead duyệt góp ý'; end if;
  if p_status not in ('approved', 'rejected') then raise exception 'PMKT: trạng thái không hợp lệ'; end if;
  if cardinality(p_images) > 5 then raise exception 'PMKT: tối đa 5 tệp'; end if;
  update pmkt_feedback set
    status = p_status,
    original_message = case when m is not null and m <> message then coalesce(original_message, message)
                            else original_message end,
    message = coalesce(m, message),
    original_images = case when p_images is not null and p_images <> images then coalesce(original_images, images)
                           else original_images end,
    images = coalesce(p_images, images),
    review_note = nullif(btrim(p_note), ''),
    reviewed_by = auth.email(), reviewed_at = now()
  where id = p_id and status not in ('processing', 'done')
    -- only files already on the ticket or uploaded by this Lead
    and not exists (select 1 from unnest(p_images) x where not (x = any(images) or split_part(x, '/', 1) = auth.email()));
  if not found then raise exception 'PMKT: không tìm thấy góp ý, góp ý đã xử lý xong hoặc tệp không hợp lệ'; end if;
end $$;
revoke all on function public.pmkt_review_feedback(bigint, text, text, text, text[]) from public, anon;
grant execute on function public.pmkt_review_feedback(bigint, text, text, text, text[]) to authenticated;
-- The Lead's own tickets need no review: approved on insert. Anyone else's start as new (whatever the client sent).
create or replace function public.pmkt_feedback_stamp() returns trigger language plpgsql security definer
  set search_path = public as $$
declare lead boolean := pmkt_is_lead();
begin
  new.status := case when lead then 'approved' else 'new' end;
  new.reviewed_by := case when lead then auth.email() end;
  new.reviewed_at := case when lead then now() end;
  return new;
end $$;
drop trigger if exists pmkt_feedback_stamp on public.pmkt_feedback;
create trigger pmkt_feedback_stamp before insert on public.pmkt_feedback
  for each row execute function public.pmkt_feedback_stamp();

-- Report opens: who opened which uploaded report and when (each person records only their own opens).
create table if not exists public.pmkt_report_opens (
  report text not null,
  email text not null default auth.email(),
  first_opened_at timestamptz not null default now(),
  last_opened_at timestamptz not null default now(),
  primary key (report, email)
);
alter table public.pmkt_report_opens enable row level security;
revoke all on public.pmkt_report_opens from anon;
grant select, insert, update on public.pmkt_report_opens to authenticated;
drop policy if exists pmkt_opens_insert on public.pmkt_report_opens;
create policy pmkt_opens_insert on public.pmkt_report_opens for insert to authenticated
  with check (email = auth.email() and public.pmkt_is_active());
drop policy if exists pmkt_opens_update on public.pmkt_report_opens;
create policy pmkt_opens_update on public.pmkt_report_opens for update to authenticated
  using (email = auth.email()) with check (email = auth.email());
drop policy if exists pmkt_opens_read on public.pmkt_report_opens;
create policy pmkt_opens_read on public.pmkt_report_opens for select to authenticated
  using (email = auth.email() or public.pmkt_is_staff_of(public.pmkt_folder_team(report)));

-- Key backup: each person's device keys, locked in the app with their own password (pmkt_alert.keybackup), so
-- signing in on another computer brings them along. Only the owner reads or writes their row – not the Lead, not
-- an Operator; the server never sees a usable key. Deleting the member deletes the backup.
create table if not exists public.pmkt_key_backup (
  email text primary key default auth.email() references public.pmkt_members(email) on delete cascade,
  blob text not null check (length(blob) between 1 and 8000),
  updated_at timestamptz not null default now()
);
alter table public.pmkt_key_backup enable row level security;
revoke all on public.pmkt_key_backup from anon;
revoke truncate, references, trigger on public.pmkt_key_backup from authenticated;  -- truncate ignores RLS
grant select, insert, update, delete on public.pmkt_key_backup to authenticated;
drop policy if exists pmkt_key_backup_own on public.pmkt_key_backup;
create policy pmkt_key_backup_own on public.pmkt_key_backup for all to authenticated
  using (email = auth.email() and public.pmkt_is_active())
  with check (email = auth.email() and public.pmkt_is_active());

-- The first Lead.
insert into public.pmkt_members (email, role, name) values ('LEAD_EMAIL', 'lead', 'Lead')
  on conflict (email) do update set role = 'lead', active = true;
"""


def setup_sql(lead_email: str) -> str:
    email = lead_email.strip().lower()
    if "@" not in email or "'" in email:
        raise TeamError("Email Lead không hợp lệ")
    return _SQL.replace("LEAD_EMAIL", email)


class Supabase:
    """Supabase REST (Auth, PostgREST, Storage) with the user's session token."""

    def __init__(self, url: str, anon: str, opener=urllib.request.urlopen):
        if not url.startswith("https://") and not url.startswith("http://127.0.0.1"):
            raise TeamError("Supabase URL phải bắt đầu bằng https://")
        if not anon:
            raise TeamError("Thiếu anon key của Supabase")
        self.url, self.anon, self.opener = url.rstrip("/"), anon, opener
        self.token: str | None = None

    def _call(self, method: str, path: str, body=None, json_body=None, headers=None) -> bytes:
        h = {"apikey": self.anon, **(headers or {})}  # works with legacy anon (JWT) and sb_publishable_ keys
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        data = body
        if json_body is not None:
            data, h["Content-Type"] = json.dumps(json_body).encode(), "application/json"
        req = urllib.request.Request(self.url + path, data=data, headers=h, method=method)
        try:
            with self.opener(req, timeout=60) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            try:
                d = json.loads(e.read() or b"{}")
                detail = d.get("error") if isinstance(d.get("error"), str) and " " in d.get("error", "") else (
                    d.get("msg") or d.get("message") or d.get("error_description") or d.get("error") or "")
            except (ValueError, AttributeError):
                detail = ""
            if "Invalid login credentials" in detail:
                raise TeamError("Sai email hoặc mật khẩu") from None
            if "banned" in detail.lower():
                raise TeamError("Tài khoản đã bị Lead khoá") from None
            if path.startswith("/functions/") and detail:
                raise TeamError(detail) from None
            if e.code in (401, 403):
                raise TeamError(f"Không có quyền ({detail or e.code}) – thử đăng nhập lại") from None
            raise TeamError(f"Supabase báo lỗi {e.code}: {detail}") from None
        except (urllib.error.URLError, OSError) as e:
            raise TeamError(f"Không kết nối được Supabase: {e}") from None

    def _json(self, *a, **k):
        out = self._call(*a, **k)
        return json.loads(out) if out else None

    # -- auth: email + password (signs-ups are disabled; a Lead creates logins through pmkt-admin)
    def sign_in(self, email: str, password: str) -> str:
        out = self._json("POST", "/auth/v1/token?grant_type=password",
                         json_body={"email": email.strip().lower(), "password": password})
        self.token = out["access_token"]
        return out["refresh_token"]

    def change_password(self, password: str) -> None:
        self._call("PUT", "/auth/v1/user", json_body={"password": password})

    def admin(self, action: str, **payload) -> dict:
        """Lead-only account management, run inside Supabase by the pmkt-admin function."""
        return self._json("POST", "/functions/v1/pmkt-admin", json_body={"action": action, **payload}) or {}

    def refresh(self, refresh_token: str) -> str:
        out = self._json("POST", "/auth/v1/token?grant_type=refresh_token", json_body={"refresh_token": refresh_token})
        self.token = out["access_token"]
        return out["refresh_token"]

    def sign_out(self) -> None:
        self._call("POST", "/auth/v1/logout")

    # -- member list (RLS: everyone reads itself + Lead/Operator rows; the Lead reads/writes everything)
    def members(self) -> list[dict]:
        return self._json("GET", "/rest/v1/pmkt_members?select=*&order=role,pic,email")

    def teams(self) -> list[dict]:
        return self._json("GET", "/rest/v1/pmkt_teams?select=id,name,is_default,ads_profile&order=id")

    def update_team(self, team: str, fields: dict) -> dict:
        rows = self._json("PATCH", f"/rest/v1/pmkt_teams?id=eq.{urllib.parse.quote(team)}", json_body=fields,
                          headers={"Prefer": "return=representation"})
        if not rows:
            raise TeamError("Không có quyền sửa nhóm này")
        return rows[0]

    def member(self, email: str) -> dict | None:
        rows = self._json("GET", f"/rest/v1/pmkt_members?select=*&email=eq.{urllib.parse.quote(email.lower())}")
        return rows[0] if rows else None

    def add_member(self, row: dict) -> dict:
        return self._json("POST", "/rest/v1/pmkt_members", json_body=row, headers={"Prefer": "return=representation"})[0]

    def update_member(self, email: str, fields: dict) -> dict:
        rows = self._json("PATCH", f"/rest/v1/pmkt_members?email=eq.{urllib.parse.quote(email.lower())}",
                          json_body=fields, headers={"Prefer": "return=representation"})
        if not rows:
            raise TeamError("Không có quyền sửa thành viên này")
        return rows[0]

    def delete_member(self, email: str) -> None:
        self._call("DELETE", f"/rest/v1/pmkt_members?email=eq.{urllib.parse.quote(email.lower())}")

    def register_keys(self, enc_pub: str, sign_pub: str | None, reset: bool = False) -> None:
        self._call("POST", "/rest/v1/rpc/pmkt_register_keys", json_body={"p_enc": enc_pub, "p_sign": sign_pub, "p_reset": reset})

    # -- key backup (RLS: the owner's own row only; the blob is locked with their password in the app)
    def key_backup(self) -> str | None:
        rows = self._json("GET", "/rest/v1/pmkt_key_backup?select=blob")
        return rows[0]["blob"] if rows else None

    def save_key_backup(self, blob: str) -> None:
        self._call("POST", "/rest/v1/pmkt_key_backup?on_conflict=email", json_body={"blob": blob, "updated_at": "now()"},
                   headers={"Prefer": "resolution=merge-duplicates,return=minimal"})

    # -- in-app feedback (RLS: sender inserts and reads own; the Lead reads all and reviews via pmkt_review_feedback)
    def send_feedback(self, row: dict) -> None:
        self._call("POST", "/rest/v1/pmkt_feedback", json_body=row)

    def feedback(self) -> list[dict]:
        return self._json("GET", "/rest/v1/pmkt_feedback?select=*&order=created_at.desc&limit=300")

    def review_feedback(self, fid: int, status: str, message: str | None, note: str | None,
                        images: list[str] | None = None) -> None:
        self._call("POST", "/rest/v1/rpc/pmkt_review_feedback",
                   json_body={"p_id": int(fid), "p_status": status, "p_message": message, "p_note": note,
                              "p_images": images})

    # -- report opens (RLS: everyone upserts own rows; Lead / Operator read all)
    def record_open(self, report: str, email: str, at: str) -> None:
        self._call("POST", "/rest/v1/pmkt_report_opens?on_conflict=report,email",
                   json_body={"report": report, "email": email, "last_opened_at": at},
                   headers={"Prefer": "resolution=merge-duplicates"})

    def report_opens(self) -> list[dict]:
        return self._json("GET", "/rest/v1/pmkt_report_opens?select=*&order=last_opened_at.desc&limit=2000")

    # -- reports (RLS: Leads everything; a member only <report>/<md5(own PIC)>.pmkt)
    def files(self, prefix: str = "") -> list[dict]:
        return self._json("POST", f"/storage/v1/object/list/{BUCKET}",
                          json_body={"prefix": prefix, "limit": 1000, "offset": 0, "sortBy": {"column": "name", "order": "desc"}})

    def reports(self) -> list[str]:
        """Report folders this user can see (a member sees only reports that contain their part), newest first."""
        return sorted({r["name"] for r in self.files() if r.get("id") is None and r.get("name")}, reverse=True)

    def upload(self, path: str, blob: bytes, bucket: str = BUCKET, content_type: str = "application/octet-stream") -> None:
        self._call("POST", f"/storage/v1/object/{bucket}/{urllib.parse.quote(path)}", body=blob,
                   headers={"Content-Type": content_type, "x-upsert": "false"})

    def download(self, path: str, bucket: str = BUCKET) -> bytes:
        return self._call("GET", f"/storage/v1/object/{bucket}/{urllib.parse.quote(path)}")

    def replace(self, path: str, blob: bytes, old: bytes) -> None:
        """Reports have no update policy: delete + insert; if the insert fails the old bytes go back."""
        self._call("DELETE", f"/storage/v1/object/{BUCKET}", json_body={"prefixes": [path]})
        try:
            self.upload(path, blob)
        except TeamError:
            self.upload(path, old)
            raise

    def overwrite(self, path: str, blob: bytes) -> None:
        """No update policy on reports: delete + insert (readers keep their last copy for the moment in between)."""
        self._call("DELETE", f"/storage/v1/object/{BUCKET}", json_body={"prefixes": [path]})
        self.upload(path, blob)

    def delete_report(self, report: str) -> None:
        files = [f"{report}/{r['name']}" for r in self.files(report + "/") if r.get("id")]
        files += [f"{report}/{HOURLY_DIR}/{r['name']}" for r in self.files(f"{report}/{HOURLY_DIR}/") if r.get("id")]
        if files:
            self._call("DELETE", f"/storage/v1/object/{BUCKET}", json_body={"prefixes": files})
