"""What goes inside a .pmkt: the run (results, Claude output, team review), the logic file, and only the data
rows a Member's app needs for Evidence and the Dashboard (date windows of that run), as compressed JSON."""
import json
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

from .loaders import Inputs, fill_campaign_names
from .windows import Windows

TABLES = ("raw", "products", "kpi", "ineligible", "ads", "activity")
OPTIONAL_TABLES = ("inventory", "converted")  # v4 data / converted product file; older packages lack them


def _frame_bytes(df: pd.DataFrame) -> bytes:
    dates = [c for c in df.columns if len(df) and isinstance(df[c].dropna().iloc[0] if df[c].notna().any() else None, date)]
    out = df.copy()
    for c in dates:
        out[c] = out[c].map(lambda v: v.isoformat() if isinstance(v, date) else None)
    return json.dumps({"columns": list(out.columns), "dates": dates, "attrs": df.attrs,
                       "data": out.astype(object).where(out.notna(), None).values.tolist()},
                      ensure_ascii=False, default=str).encode("utf-8")


def _frame_from(data: bytes) -> pd.DataFrame:
    d = json.loads(data)
    df = pd.DataFrame(d["data"], columns=d["columns"])
    for c in d["dates"]:
        df[c] = df[c].map(lambda v: date.fromisoformat(v) if v else None)
    for c in df.columns:
        if c not in d["dates"] and df[c].map(lambda v: isinstance(v, (int, float)) or v is None).all() and df[c].notna().any():
            df[c] = pd.to_numeric(df[c])
    df.attrs = d.get("attrs", {})
    return df


ADS_DAYS = 30  # ads_camp days shipped in an uploaded report


def _since(df: pd.DataFrame, start: date) -> pd.DataFrame:
    return df[df["date"] >= start] if "date" in df.columns and len(df) else df


def pack_run(run: dict, inputs: Inputs, logic_path: Path) -> dict[str, bytes]:
    as_of = date.fromisoformat(run["result"]["as_of"])
    win = Windows(as_of)
    # raw_sso_us, INELIGIBLE ASIN: every day the Lead has (file + up to 3 months of stored history) – Performance Review;
    # ads_camp: the last 30 days (and always this month + P7D for the rules) – the bulk of the size.
    ads_start = min(win.mtd[0], win.p7d[0], as_of - timedelta(days=ADS_DAYS - 1))
    tables = {"raw": inputs.raw, "products": inputs.products,
              "kpi": inputs.kpi[inputs.kpi["month"] == as_of.month], "ineligible": inputs.ineligible,
              "ads": _since(inputs.ads, ads_start), "activity": inputs.activity,
              "inventory": _since(inputs.inventory, win.l7d[0] - timedelta(days=14))}
    if getattr(inputs, "converted", None) is not None:
        tables["converted"] = inputs.converted
    files = {f"data/{k}.json": _frame_bytes(v) for k, v in tables.items()}
    files["run.json"] = json.dumps(run, ensure_ascii=False).encode("utf-8")
    files["logic.xlsx"] = Path(logic_path).read_bytes()
    files["meta.json"] = json.dumps({"sources": inputs.sources, "defind_text": inputs.defind_text,
                                     "event_days": {k.isoformat(): v for k, v in inputs.event_days.items()},
                                     "contrib": {k.isoformat(): v for k, v in (inputs.contrib or {}).items()},
                                     "keepa": getattr(inputs, "keepa", None) or {},  # today's Keepa values (listing chart)
                                     "logic_name": Path(logic_path).name}, ensure_ascii=False).encode("utf-8")
    return files


def unpack_run(files: dict[str, bytes]) -> tuple[dict, Inputs, bytes, str]:
    meta = json.loads(files["meta.json"])
    t = {k: _frame_from(files[f"data/{k}.json"]) for k in TABLES + OPTIONAL_TABLES if f"data/{k}.json" in files}
    inv = t.get("inventory", pd.DataFrame(columns=["date", "asin", "sku", "stock"]))
    if "campaign" in t["ads"].columns:  # reports uploaded before blank names were filled
        attrs, t["ads"] = t["ads"].attrs, fill_campaign_names(t["ads"])
        t["ads"].attrs = attrs
    inputs = Inputs(t["raw"], t["products"], t["kpi"], t["ineligible"], t["ads"], t["activity"],
                    {date.fromisoformat(k): v for k, v in meta["event_days"].items()}, meta["defind_text"], meta["sources"],
                    inv, {date.fromisoformat(k): v for k, v in meta.get("contrib", {}).items()}, keepa=meta.get("keepa") or {},
                    converted=t.get("converted"))
    return json.loads(files["run.json"]), inputs, files["logic.xlsx"], meta["logic_name"]


def filter_run(run: dict, pic: str, scorecard_row: dict | None) -> dict:
    """Only what one PIC may see: their rows, their Claude output, the Department frame needed to read their
    score, and their own scorecard row (no ranking, no other PICs, no logic review, no data warnings)."""
    res = run["result"]
    mine = lambda rows: [r for r in rows if r.get("pic") == pic]  # noqa: E731
    result = {**res, "pl": mine(res["pl"]), "camp": mine(res["camp"]), "digest": mine(res["digest"]),
              "pics": mine(res.get("pics") or []), "issues": [], "logic_issues": [], "unreliable": False}
    ai = run.get("ai") or {}
    ai_part = {"claude_ok": ai.get("claude_ok"), "error": ai.get("error"), "review": [], "logic_eval": None,
               "per_pic": {pic: ai["per_pic"][pic]} if pic in (ai.get("per_pic") or {}) else {}}
    row = None
    if scorecard_row:
        row = {**scorecard_row, "rank": None}
    return {"run_id": run.get("run_id"), "result": result, "ai": ai_part, "team_review": None, "my_scorecard": row}


def filter_inputs(inputs: Inputs, run: dict, pic: str) -> Inputs:
    """Data rows for this PIC's own product lines / campaigns only."""
    pls = {r["pl"] for r in run["result"]["pl"] if r.get("pic") == pic}
    asins = set(inputs.products.loc[inputs.products["pl"].isin(pls), "asin"])
    keys = {r.get("camp_key") for r in run["result"]["camp"] if r.get("pic") == pic}
    from .rules.actions import _campaign_of, normalize_name
    act = inputs.activity
    if len(act):
        act = act[[normalize_name(_campaign_of(lv) or "") in keys for lv in act["level"]]]
    pick = lambda df: df[df["asin"].isin(asins)] if "asin" in df.columns else df  # noqa: E731
    conv = getattr(inputs, "converted", None)  # cross sale needs the advertised ASIN in scope, halo the converted one
    conv = conv[conv["adv"].isin(asins) | conv["conv"].isin(asins)] if conv is not None else None
    return Inputs(pick(inputs.raw), pick(inputs.products), pick(inputs.kpi), pick(inputs.ineligible), pick(inputs.ads),
                  act, inputs.event_days, inputs.defind_text, inputs.sources, pick(inputs.inventory), inputs.contrib,
                  keepa={a: v for a, v in (getattr(inputs, "keepa", None) or {}).items() if a in asins}, converted=conv)


def build_parts(run: dict, inputs: Inputs, logic_path: Path, pics: list[str], scorecard_rows: dict) -> dict:
    """{"lead": full files, "pic:X": only X's files} – each becomes its own encrypted .pmkt."""
    parts = {"lead": pack_run(run, inputs, logic_path)}
    for pic in sorted(pics):
        inp = filter_inputs(inputs, run, pic)
        mine = set(inp.products["asin"])
        prev, hist = run.get("prev_listing"), run.get("listing_history") or {}
        listing = {"prev_listing": None if prev is None else {a: prev[a] if isinstance(prev, dict) else "" for a in prev if a in mine},
                   "listing_history": {d: {a: v for a, v in h.items() if a in mine} for d, h in hist.items()},
                   "keepa_history": {d: {a: v for a, v in h.items() if a in mine} for d, h in (run.get("keepa_history") or {}).items()}}
        parts[f"pic:{pic}"] = pack_run({**filter_run(run, pic, scorecard_rows.get(pic)), **listing}, inp, logic_path)
    return parts
