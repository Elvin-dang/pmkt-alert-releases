"""Find the SharePoint exports that OneDrive syncs to this computer, so nobody has to pick them.

Synced libraries live in known places: Windows %USERPROFILE%\\<Org>\\<Site - Library> (and the OneDrive folders),
macOS ~/Library/CloudStorage/OneDrive-*. Files are matched by their SharePoint name; listing a folder never downloads
a cloud-only file. "Add shortcut to My files" on a single file (no access to its folder) leaves only an Internet
Shortcut, `<name>.url` – found too, and downloaded by sharepoint.py."""
import os
from pathlib import Path

# The Data workbook's Power Query sources (see its Refresh All queries).
EXPORTS = ("SSO US Data Extraction Daily -- raw_sso_us.xlsx", "SSO AMZ Ads by Campaign -- ads_camp.xlsx",
           "Ineligible adgroup -- INELIGIBLE ASIN.xlsx", "US Keepa Raw Auto.xlsx", "USA Inventory Y4A-AMZ.xlsx")
MAX_DEPTH = 10  # ponytail: bounded walk of the synced trees; a deeper library needs the file picked once by hand


def roots(home: Path | None = None, env: dict | None = None) -> list[Path]:
    home, env = home or Path.home(), os.environ if env is None else env
    found = [Path(env[k]) for k in ("OneDriveCommercial", "OneDrive") if env.get(k)]
    found += [p for p in home.glob("*") if p.is_dir() and ("yes4all" in p.name.lower() or p.name.startswith("OneDrive"))]
    found += [p for p in (home / "Library" / "CloudStorage").glob("OneDrive*") if p.is_dir()]
    seen, out = set(), []
    for p in found:
        if p.exists() and p.resolve() not in seen:
            seen.add(p.resolve())
            out.append(p)
    return out


def export_of(p: Path, names: tuple = EXPORTS) -> str | None:
    """The export a path is (the file itself or its `.url` shortcut), lower-case; None for other files."""
    name = p.name.lower().removesuffix(".url")
    return name if name in {n.lower() for n in names} else None


def find(known: list[str] | None = None, search: list[Path] | None = None, names: tuple = EXPORTS) -> list[Path]:
    """Paths of the exports: the remembered ones that still exist, and a search for the rest. A synced file wins
    over a `.url` shortcut to the same export."""
    want = {n.lower(): n for n in names}
    out = {}

    def add(p: Path) -> None:
        key = export_of(p, names)
        if key and (key not in out or (out[key].suffix == ".url" and p.suffix != ".url")):
            out[key] = p

    def done() -> bool:
        return len(out) == len(want) and not any(p.suffix == ".url" for p in out.values())

    for p in map(Path, known or []):
        if p.is_file():
            add(p)
    for root in (roots() if search is None else search):
        if done():
            break
        base = len(root.parts)
        for dirpath, dirs, files in os.walk(root):
            if len(Path(dirpath).parts) - base >= MAX_DEPTH:
                dirs[:] = []
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for f in files:
                add(Path(dirpath) / f)
            if done():
                break
    return list(out.values())
