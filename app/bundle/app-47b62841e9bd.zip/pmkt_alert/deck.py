"""In-app presentation: slides built from a run (no Claude needed), then reworded by Claude on request.
Numbers live in the slide data (kpis / chart / facts); Claude only rewrites text, and any sentence quoting a
number that is not in the slide's facts is dropped – the same grounding rule as the insights."""
import json

from .claude import grounded

CATEGORIES = [  # key, label – the order slides appear in
    ("overview", "Tổng quan"),
    ("ranking", "Xếp hạng PIC"),
    ("pace", "Tiến độ GMV & spend"),
    ("weekly", "Xu hướng theo tuần"),
    ("pl", "PL cần xử lý"),
    ("camp", "Campaign cần action"),
    ("pic", "Từng PIC"),
    ("review", "Nhận xét của Claude"),
    ("data", "Chất lượng data"),
]
TOP = 6  # rows per list slide: a slide is read from across the room, not scrolled


def money(v) -> str:
    return "—" if v is None else f"${round(v):,}"


def pct(v, d: int = 0) -> str:
    return "—" if v is None else f"{v * 100:.{d}f}%"


def _kpi(label, value, detail="", tone=""):
    return {"label": label, "value": value, "detail": detail, "tone": tone}


def _slide(sid, cat, title, *, kpis=(), items=(), chart=None, insight="", notes="", facts=()):
    return {"id": sid, "cat": cat, "title": title, "kpis": list(kpis), "items": list(items), "chart": chart,
            "insight": insight, "notes": notes, "facts": list(facts)}


def _overview(rj, sc):
    d = rj["digest"]
    tot = {k: sum(x.get(k) or 0 for x in d) for k in ("pl_high", "pl_med", "camp_high", "camp_med", "excess_new")}
    worst = max(d, key=lambda x: x["pl_high"] + x["camp_high"], default=None)
    top_excess = max(d, key=lambda x: x["excess_new"], default=None)
    insight = (f"{worst['pic']} đang có nhiều cảnh báo HIGH nhất ({worst['pl_high'] + worst['camp_high']})."
               if worst and worst["pl_high"] + worst["camp_high"] else "Không có cảnh báo HIGH.")
    by = lambda k: "\n".join(f"{x['pic']}: {x[k]}" for x in d)  # noqa: E731
    return [_slide("overview", "overview", f"Tổng quan – data đến {rj['as_of']}", kpis=[
        _kpi("PL HIGH", str(tot["pl_high"]), by("pl_high"), "high" if tot["pl_high"] else "ok"),
        _kpi("PL MED", str(tot["pl_med"]), by("pl_med"), "med" if tot["pl_med"] else ""),
        _kpi("Camp HIGH / MED", f"{tot['camp_high']} / {tot['camp_med']}", by("camp_high"), "high" if tot["camp_high"] else ""),
        _kpi("Excess spend", money(tot["excess_new"]), "\n".join(f"{x['pic']}: {money(x['excess_new'])}" for x in d),
             "high" if tot["excess_new"] else "ok"),
        _kpi("Time gone", pct(sc["time_gone"]), "Phần tháng đã qua – mốc so tiến độ GMV/spend."),
    ], insight=insight,
        notes=f"{len(d)} PIC. Excess cao nhất: {top_excess['pic']} ({money(top_excess['excess_new'])})." if top_excess else "",
        facts=[{**tot, "high": worst["pl_high"] + worst["camp_high"] if worst else 0, "time_gone": sc["time_gone"]}, *d])]


def _ranking(sc):
    ranked = [p for p in sc["pics"] if p["rank"]]
    if not ranked:
        return []
    short = {m["key"]: m["short"] for m in sc["metrics"]}
    details = ["\n".join(f"{short[k]}: điểm {v}" for k, v in p["scores"].items() if v is not None) for p in ranked]
    top, last = ranked[0], ranked[-1]
    return [_slide("ranking", "ranking", "Xếp hạng PIC (điểm 0–100)",
                   chart={"kind": "hbar", "fmt": "n", "labels": [p["pic"] for p in ranked],
                          "series": [{"name": "Điểm", "data": [p["total"] for p in ranked]}], "details": details},
                   insight=f"{top['pic']} dẫn đầu với {top['total']} điểm; {last['pic']} thấp nhất ({last['total']}).",
                   notes="Điểm là xếp hạng tương đối giữa các PIC, mỗi người đo so với target của chính họ.",
                   facts=[{"pic": p["pic"], "total": p["total"], **p["scores"]} for p in ranked])]


def _pace(sc):
    named = [p for p in sc["pics"] if p["rank"] and (p["values"]["gmv_pct"] is not None or p["values"]["spend_pct"] is not None)]
    if not named:
        return []
    tg = sc["time_gone"]
    slow = [p["pic"] for p in named if (p["values"]["gmv_pct"] or 0) < tg]
    details = [f"GMV {pct(p['values']['gmv_pct'], 1)} target · spend {pct(p['values']['spend_pct'], 1)} target\n"
               f"GMV {money(p['values']['gmv_mtd'])} / {money(p['values']['target_gmv'])}\n"
               f"Spend {money(p['values']['spend_mtd'])} / {money(p['values']['target_spend'])}" for p in named]
    return [_slide("pace", "pace", "Tiến độ GMV & spend so với time gone",
                   chart={"kind": "hbar", "fmt": "pct", "labels": [p["pic"] for p in named], "ref": tg,
                          "series": [{"name": "GMV % target", "data": [p["values"]["gmv_pct"] for p in named]},
                                     {"name": "Spend % target", "data": [p["values"]["spend_pct"] for p in named]}],
                          "details": details},
                   insight=(f"GMV dưới time gone ({pct(tg)}): {', '.join(slow)}." if slow else
                            f"Mọi PIC đều có GMV trên time gone ({pct(tg)})."),
                   notes="Vạch đứt = time gone. GMV dưới vạch là chậm; spend vượt vạch là tiêu nhanh.",
                   facts=[{"time_gone": tg}, *[p["values"] for p in named]])]


def _weekly(weekly):
    if not weekly:
        return []
    weeks = sorted({w["week"] for w in weekly})
    pics = sorted({w["pic"] for w in weekly})
    tot = {wk: sum(w["gmv"] or 0 for w in weekly if w["week"] == wk) for wk in weeks}
    series = [{"name": p, "data": [next((w["gmv"] for w in weekly if w["pic"] == p and w["week"] == wk), None) for wk in weeks]}
              for p in pics]
    details = [f"Tổng GMV {money(tot[wk])}\n" + "\n".join(f"{w['pic']}: {money(w['gmv'])} · TACoS {pct(w['tacos'], 1)}"
                                                         for w in weekly if w["week"] == wk) for wk in weeks]
    full = [wk for wk in weeks if next(w["days"] for w in weekly if w["week"] == wk) == 7]
    insight = ""
    if len(full) >= 2 and tot[full[-2]]:
        ch = tot[full[-1]] / tot[full[-2]] - 1
        insight = f"GMV tuần {full[-1]} {'tăng' if ch >= 0 else 'giảm'} {pct(abs(ch))} so với tuần trước."
    return [_slide("weekly", "weekly", "Xu hướng GMV theo tuần",
                   chart={"kind": "line", "fmt": "money", "labels": weeks, "series": series, "details": details},
                   insight=insight, notes="Tuần tính từ thứ Hai; tuần cuối có thể chưa đủ 7 ngày.",
                   facts=[*weekly, {"week_" + k: v for k, v in tot.items()},
                          {"change": (tot[full[-1]] / tot[full[-2]] - 1) if insight else 0}])]


def _pl(rj):
    rows = sorted((r for r in rj["pl"] if r.get("pacing_sev") in ("HIGH", "MED")),
                  key=lambda r: (r["pacing_sev"] != "HIGH", -(r.get("l7d_spend") or 0)))[:TOP]
    if not rows:
        return []
    items = [{"text": f"{r['pl']} – {r['pic']}: {r.get('pacing_action') or ''}",
              "detail": f"{r.get('pacing_reason') or ''}\nGMV {pct(r.get('pct_gmv'), 1)} target · spend {pct(r.get('pct_spend'), 1)} target"
                        f"\nTACoS {pct(r.get('actual_tacos'), 1)} (target {pct(r.get('target_tacos'), 1)})",
              "tone": r["pacing_sev"].lower()} for r in rows]
    n_high = sum(r["pacing_sev"] == "HIGH" for r in rows)
    return [_slide("pl", "pl", "PL cần xử lý", items=items,
                   insight=f"{n_high} PL HIGH trong top {len(rows)} – xử lý trước các PL tiêu nhiều nhất.",
                   notes="Sắp theo mức độ rồi spend L7D.", facts=[*rows, {"n": n_high, "top": len(rows)}])]


def _camp(rj):
    rows = sorted((c for c in rj["camp"] if c.get("sev") in ("HIGH", "MED") and (c.get("excess") or 0) > 0),
                  key=lambda c: -(c.get("excess") or 0))[:TOP]
    if not rows:
        return []
    total = sum(c["excess"] for c in rows)
    return [_slide("camp", "camp", "Campaign cần action (theo excess spend)",
                   chart={"kind": "hbar", "fmt": "money", "labels": [str(c["campaign"])[:48] for c in rows],
                          "series": [{"name": "Excess $", "data": [c["excess"] for c in rows]}],
                          "details": [f"{c['pl']} – {c['pic']}\n{c.get('final_label') or c.get('base_action') or ''}\n"
                                      f"Spend L7D {money(c.get('l7d_spend'))} · ACoS {pct(c.get('l7d_acos'), 1)}" for c in rows]},
                   insight=f"Top {len(rows)} campaign chiếm {money(total)} excess spend.",
                   notes="Excess = spend L7D vượt mức hợp lý theo ACoS target.", facts=[*rows, {"total": total}])]


def _pics(rj, ai):
    out = []
    for d in rj["digest"]:
        mine = ((ai or {}).get("per_pic") or {}).get(d["pic"]) or {}
        items = [{"text": i["text"], "detail": "", "tone": ""} for i in (mine.get("insights") or [])[:5]]
        items += [{"text": t["title"], "detail": t["detail"], "tone": t["severity"].lower()} for t in (mine.get("todos") or [])[:3]]
        out.append(_slide(f"pic:{d['pic']}", "pic", d["pic"], kpis=[
            _kpi("PL HIGH / MED", f"{d['pl_high']} / {d['pl_med']}", tone="high" if d["pl_high"] else ""),
            _kpi("Camp HIGH / MED", f"{d['camp_high']} / {d['camp_med']}", tone="high" if d["camp_high"] else ""),
            _kpi("Follow-up", str(d["camp_followup"]), "Campaign đã action, đang chờ kiểm tra kết quả."),
            _kpi("Excess spend", money(d["excess_new"]), tone="high" if d["excess_new"] else "ok"),
        ], items=items, insight=items[0]["text"] if items else "",
            notes=(mine.get("slack") or "")[:600],
            # the digest row plus every PL / camp row of this PIC, so reworded insights stay checkable
            facts=[d, *(r for r in rj["pl"] + rj["camp"] if r.get("pic") == d["pic"])]))
    return out


def _review(tr):
    if not tr:
        return []
    items = [{"text": f"{h['pic']}: {h['text']}", "detail": "", "tone": "ok"} for h in tr.get("highlights", [])]
    items += [{"text": f"{h['pic']}: {h['text']}", "detail": h.get("suggestion", ""), "tone": "med"} for h in tr.get("improve", [])]
    return [_slide("review", "review", "Nhận xét của Claude", items=items, insight=tr.get("summary", ""))]


def _data(rj):
    issues = rj.get("issues") or []
    return [_slide("data", "data", "Chất lượng data",
                   items=[{"text": i["title"], "detail": i.get("detail", ""), "tone": "med" if i.get("severity") == "WARN" else ""}
                          for i in issues] or [{"text": "Data ổn.", "detail": "", "tone": "ok"}],
                   insight="Cảnh báo data – kiểm tra trước khi action." if rj.get("unreliable") else "")]


def _cover(rj):
    d = rj["digest"]
    high = sum(x["pl_high"] + x["camp_high"] for x in d)
    excess = sum(x.get("excess_new") or 0 for x in d)
    return _slide("cover", "cover", "Hiệu quả quảng cáo Amazon", kpis=[
        _kpi("PIC", str(len(d))), _kpi("Cảnh báo HIGH", str(high), tone="high" if high else "ok"),
        _kpi("Excess spend", money(excess), tone="high" if excess else "ok")],
        insight=f"Báo cáo nhóm · data đến {rj['as_of']}", notes="Mở đầu: phạm vi báo cáo và mốc data.",
        facts=[{"pic": len(d), "high": high, "excess": excess}])


def _agenda(sections):
    return _slide("agenda", "agenda", "Nội dung", notes="Lướt nhanh các phần; bấm một phần để nhảy tới.",
                  facts=[{"n": len(sections)}])


def build(run: dict, sc: dict, weekly: list[dict], cats: list[str]) -> dict:
    """Cover, agenda (when there are 3+ sections), then the picked sections. Every content slide carries `sec`
    (its section label) so the UI can letter the sections and jump to them from the agenda."""
    rj = run["result"]
    makers = {"overview": lambda: _overview(rj, sc), "ranking": lambda: _ranking(sc), "pace": lambda: _pace(sc),
              "weekly": lambda: _weekly(weekly), "pl": lambda: _pl(rj), "camp": lambda: _camp(rj),
              "pic": lambda: _pics(rj, run.get("ai")), "review": lambda: _review(run.get("team_review")),
              "data": lambda: _data(rj)}
    label = dict(CATEGORIES)
    body = [{**s, "sec": label[k]} for k, _ in CATEGORIES if k in cats for s in makers[k]()]
    sections = {s["cat"] for s in body}
    slides = [_cover(rj), *([_agenda(sections)] if len(sections) >= 3 else []), *body]
    return {"run_id": run.get("run_id"), "as_of": rj["as_of"], "cats": [k for k, _ in CATEGORIES if k in cats], "slides": slides}


# ----------------------------------------------------------------- Claude edit
_TEXT = {"type": "string"}
EDIT_SCHEMA = {
    "type": "object", "required": ["slides"],
    "properties": {"slides": {"type": "array", "items": {
        "type": "object", "required": ["id", "title"],
        "properties": {"id": _TEXT, "title": _TEXT, "insight": _TEXT, "notes": _TEXT,
                       "items": {"type": "array", "items": {"type": "object", "required": ["text"],
                                                            "properties": {"text": _TEXT, "detail": _TEXT,
                                                                           "tone": {"enum": ["", "high", "med", "ok"]}}}}}}}},
}


def _public(s: dict) -> dict:
    return {k: s[k] for k in ("id", "title", "insight", "notes", "items")} | {
        "data": {"kpis": [f"{k['label']}: {k['value']}" for k in s["kpis"]],
                 "chart": s["chart"] and {"labels": s["chart"]["labels"],
                                          "series": [{x["name"]: x["data"]} for x in s["chart"]["series"]]}}}


def edit_prompt(deck: dict, instruction: str, index: int | None) -> str:
    target = [deck["slides"][index]] if index is not None else deck["slides"]
    scope = (f'CHỈ sửa slide id "{target[0]["id"]}". Trả về đúng 1 slide.' if index is not None else
             "Sửa cả bài trình chiếu. Có thể đổi thứ tự, bỏ slide (bỏ khỏi danh sách) hoặc thêm slide chỉ có chữ "
             '(id bắt đầu bằng "new:").')
    return f"""Bạn biên tập một bài trình chiếu về hiệu quả quảng cáo Amazon của nhóm, data đến {deck['as_of']}.
Yêu cầu của người dùng: {instruction}

{scope}
Quy tắc:
- Chỉ sửa chữ: title, insight (1 câu điểm nhấn), notes (ghi chú người nói, có thể dài), items (text ngắn + detail mở rộng khi bấm).
- Mọi con số phải lấy đúng từ "data", "items" hoặc chữ sẵn có của slide; không tự tính số mới. Câu có số sai sẽ bị bỏ.
- "data" (kpis, chart) là cố định, không trả về.
- Giữ nguyên id của slide có sẵn.
Slides: {json.dumps([_public(s) for s in target], ensure_ascii=False, default=str)}
Trả về JSON đúng schema: {json.dumps(EDIT_SCHEMA, ensure_ascii=False)}"""


def apply_edit(deck: dict, out: dict, index: int | None) -> tuple[dict, int]:
    """Merge Claude's text into the deck. Returns (new deck, sentences dropped by the grounding check)."""
    by_id = {s["id"]: s for s in deck["slides"]}
    all_facts = [f for s in deck["slides"] for f in s["facts"]]
    dropped, merged = 0, []
    for o in out["slides"]:
        base = by_id.get(o["id"])
        if base is None and not o["id"].startswith("new:"):
            continue
        base = base or {**_slide(o["id"], "text", ""), "sec": ""}
        facts = base["facts"] + [{"kpi": k["value"]} for k in base["kpis"]] if base["cat"] != "text" else all_facts
        # numbers already on the slide (its own text) count as facts too – Claude may move them around
        own = " ".join([base["title"], base["insight"], base["notes"], *(i["text"] + " " + i.get("detail", "") for i in base["items"])])
        ok = lambda t: not t or grounded(t, facts) or _same_numbers(t, own)  # noqa: E731
        s = {**base}
        for k in ("title", "insight", "notes"):
            if k in o:
                if ok(o[k]):
                    s[k] = o[k]
                else:
                    dropped += 1
        if "items" in o:
            items = [{"text": i["text"], "detail": i.get("detail", ""), "tone": i.get("tone", "")} for i in o["items"]]
            kept = [i for i in items if ok(i["text"]) and ok(i["detail"])]
            dropped += len(items) - len(kept)
            s["items"] = kept
        merged.append(s)
    if index is not None:
        slides = list(deck["slides"])
        if merged:
            slides[index] = merged[0]
        return {**deck, "slides": slides}, dropped
    return {**deck, "slides": merged or deck["slides"]}, dropped


def _same_numbers(text: str, own: str) -> bool:
    from .claude import number_tokens
    have = {r for tok in number_tokens(own) for r in tok}
    return all(any(r in have for r in tok) for tok in number_tokens(text))
