"""Performance Review (logic file sheet 'Performance Review_brief'): for a PIC / timeframe / product line –
summary tiles, PL and SKU target-vs-actual tables, daily chart series and the campaign list.
Actuals follow the timeframe; targets are the month's KPI (month of the timeframe's end). Daily targets spread the
monthly target with the Data workbook's Summary %Contribution (GMV & RS: GMV row; spend: PPC row), else evenly.
Scope and PIC as in the score model: Team Label = the logic's team label, PIC = PMKT PIC_Final."""
import calendar
from datetime import date, timedelta
from itertools import takewhile

import pandas as pd

from .aggregate import NO_PIC, scoped_map
from .rules.actions import parse_activity
from .rules.inventory import LOW, OUT, sku_cover
from .store import KEEPA_SERIES, OLD_RUN_ISSUE

_div = lambda a, b: (a / b) if b and a is not None else None  # noqa: E731
_blocked = lambda s: str(s).strip().upper().startswith("INELIGIBLE")  # noqa: E731


def _iso(d) -> str:
    return d.isoformat() if d else None


def _ineligible(rows: pd.DataFrame | None, month_start: date, end: date, last_log: date | None) -> dict:
    """rows = one ASIN's INELIGIBLE log rows of this month up to end. current = its delivery_status on the last log
    day ≤ end ('' = not listed = eligible); changes = status changes day to day this month; days = days listed as
    INELIGIBLE this month."""
    by_day = {} if rows is None else {d: str(s).strip().upper() for d, s in zip(rows["date"], rows["status"])
                                      if s == s and s is not None}
    flips, prev, day = 0, None, month_start
    while day <= end:
        state = by_day.get(day, "")
        if prev is not None and state != prev:
            flips += 1
        prev, day = state, day + timedelta(days=1)
    return {"current": by_day.get(last_log, "") if last_log else "", "changes": flips,
            "days": sum(1 for v in by_day.values() if v.startswith("INELIGIBLE"))}


def ineligible_fn(inputs, month_start: date, end: date):
    """→ asin → _ineligible() of this month up to end (judged at the last log day ≤ end, not the newest log)."""
    ie = inputs.ineligible
    logs = ie["date"].dropna() if len(ie) else pd.Series(dtype=object)
    logs = logs[logs <= end]
    last_log = max(logs) if len(logs) else None
    ie_month = ie[(ie["date"] >= month_start) & (ie["date"] <= end)] if len(ie) else ie
    by_asin = {a: g for a, g in ie_month.groupby("asin")} if len(ie_month) else {}
    return lambda asin: _ineligible(by_asin.get(asin), month_start, end, last_log)


def sku_stock_fn(inputs, month: int):
    """→ (asin, sku) → current stock. A row on an Inactive ASIN shows the stock of the SKU's Active ASIN (Product Info
    status), which may sit outside the PIC / team scope – hence the unscoped KPI month."""
    k_month = inputs.kpi[inputs.kpi["month"] == month]
    stock = {a: s for a, s in zip(k_month["asin"], k_month["stock"]) if s == s} if "stock" in k_month.columns else {}
    prods = inputs.products
    active = prods[prods["status"] == "Active"]
    active_asins = set(active["asin"])
    active_of_sku: dict = {}
    for sku_, a in zip(active["sku"], active["asin"]):  # Product Info order: the first Active ASIN with stock wins
        active_of_sku.setdefault(str(sku_).strip().upper(), []).append(a)

    def sku_stock(asin: str, sku_) -> float | None:
        if asin not in active_asins:
            for a in active_of_sku.get(str(sku_).strip().upper(), []):
                if a in stock:
                    return float(stock[a])
        st = stock.get(asin)
        return None if st is None else float(st)
    return sku_stock


def _listing_issue(row: dict) -> str:
    """Listing Issue sheet flags (CG–CI). Product Info status (Inactive) and lifecycle (Withdrawal) are product
    stages, not listing issues."""
    return str(row.get("listing") or "")


NOT_ISSUES = ("Inactive", "Withdrawal")  # counted as listing issues before v0.1.22 / v0.1.23


def _drop_inactive(issues: dict) -> dict:
    """Snapshots saved while Inactive / Withdrawal still counted: strip them, drop ASINs left with no issue."""
    return {a: v for a, iss in issues.items() if (v := " · ".join(x for x in str(iss).split(" · ") if x not in NOT_ISSUES))}


def listing_issues(products: pd.DataFrame) -> dict[str, str]:
    """{asin: issue} for ASINs that currently carry a listing issue – one day of the 30-day listing history."""
    info = products.drop_duplicates("asin").set_index("asin")
    return {a: v for a, row in info.to_dict("index").items() if (v := _listing_issue(row))}


BUYBOX, OOS = "Mất buybox", "Hết hàng"
# est GMV lost waterfall: an ASIN-day has one lost number → it goes to the first matching cause, so nothing is counted twice.
LOST_CAUSES = ((OOS, OOS), (BUYBOX, BUYBOX), ("Long Shipping Time", "Shipping"), ("Tăng giá", "Giá"))
UNEXPLAINED = "Unexplained"
WEEKS, MIN_WEEKDAYS, FALLBACK_DAYS = 8, 4, 14


def lost_cause(issue: str) -> str:
    return next((c for k, c in LOST_CAUSES if k in (issue or "")), UNEXPLAINED)


def _with_oos(issues: dict, asins) -> dict:
    out = dict(issues)
    for a in asins:
        out[a] = out[a] if OOS in out.get(a, "") else " · ".join(x for x in (out.get(a), OOS) if x)
    return out


def day_issues(inputs, day: date) -> dict[str, str]:
    """Listing snapshot for one data day: Product Info / Listing Issue flags + Hết hàng (KPI Current Stock ≤ 0;
    blank stock = unknown, not flagged). Undated like the Listing Issue sheet → saved per run."""
    inv = inputs.inventory  # = KPI Current Stock (see loaders)
    return _with_oos(listing_issues(inputs.products), set(inv.loc[inv["stock"] <= 0, "asin"]))


def gmv_lost_fn(raw: pd.DataFrame, history: dict):
    """est(asin, day) = max(Potential − actual GMV of the ASIN-day, 0). Clean day = no listing issue in the history, no deal
    (raw total_promotion > 0); Buy Box % per day is not in the data. Potential = the day's sessions (glance_views) × CVR_b
    × AOV_b over the clean same-weekday days of the last 8 weeks, when ≥ 4 exist (with rows) and the day had sessions;
    else (not enough data yet) the average daily GMV of the 14 days before – clean days if any, else all.
    Days before the raw data starts don't count."""
    first = raw["date"].min() if len(raw) else None
    cols = ["gmv", "promo", "units", "sessions"]
    g = raw.assign(**{c: raw[c] if c in raw.columns else 0.0 for c in cols}).groupby(["asin", "date"])[cols].sum()
    by = {}
    for (a, d), *v in zip(g.index, *(g[c] for c in cols)):
        by.setdefault(a, {})[d] = tuple(map(float, v))

    def est(asin: str, day: date) -> float | None:
        d = by.get(asin, {})
        row = lambda x: d.get(x, (0.0, 0.0, 0.0, 0.0))  # noqa: E731  gmv, promo, units, sessions
        clean = lambda x: row(x)[1] <= 0 and not history.get(x.isoformat(), {}).get(asin)  # noqa: E731
        same = [x for x in (day - timedelta(weeks=w) for w in range(1, WEEKS + 1)) if x in d and clean(x)]
        sessions = sum(row(x)[3] for x in same)
        if len(same) >= MIN_WEEKDAYS and sessions > 0 and row(day)[3] > 0:
            # ponytail: no seasonality / YoY adjustment (Prime Day, BFCM) – the raw has < 1 year; add it when YoY data exists.
            # Days without a saved listing snapshot count as clean (history keeps 30 days).
            gmv, units = (sum(row(x)[i] for x in same) for i in (0, 2))
            potential = row(day)[3] * (units / sessions) * (gmv / units if units else 0.0)  # Sessions × CVR_b × AOV_b
        else:
            days = [x for x in (day - timedelta(days=i) for i in range(1, FALLBACK_DAYS + 1)) if first is not None and x >= first]
            days = [x for x in days if clean(x)] or days
            if not days:
                return None
            potential = sum(row(x)[0] for x in days) / len(days)
        return max(potential - row(day)[0], 0.0)  # returns can make GMV negative
    return est


def listing_issue_asins(products: pd.DataFrame) -> list[str]:
    """ASINs that currently carry a listing issue – saved per run so the next run can diff against it
    (the Product Info sheet has no date; the comparison is this upload vs the most recent saved run)."""
    info = products.drop_duplicates("asin").set_index("asin")
    return sorted(a for a, row in info.to_dict("index").items() if _listing_issue(row))


def today_summary(inputs, amap: pd.DataFrame, info: pd.DataFrame, inv_params: dict | None,
                  end_d: date, prev_listing, est=None, history: dict | None = None) -> dict:
    """Daily ops snapshot for the PIC scope (amap), judged at end_d (= latest data day, 'calendar −1').
    Ads-block (INELIGIBLE sheet) is dated → today vs the previous log day; listing issue is undated →
    today vs prev_listing (the most recent saved run, None when there is no baseline yet).
    history: {data day ISO: {asin: issue}} – listing_open = ASINs with an issue now that the baseline already had (new ones
    are listing_new only), with the run of saved days behind it;
    a resolved ASIN shows its issue from the latest saved day before end_d."""
    pl_of = dict(zip(amap["asin"], amap["pl"]))
    sku_of = dict(zip(amap["asin"], amap["sku"])) if "sku" in amap.columns else {}
    scope = set(amap["asin"])
    name_of = info["product_name"].to_dict() if "product_name" in info.columns else {}  # feedback #52: Product name by ASIN
    key = lambda a: (pl_of.get(a, ""), sku_of.get(a, a))  # noqa: E731
    items = lambda asins, ex=None: [{"asin": a, "sku": sku_of.get(a, a), "product": name_of.get(a) or "", "pl": pl_of.get(a, ""),  # noqa: E731
                                     **(ex(a) if ex else {})}
                                    for a in sorted(asins, key=key)]

    ie = inputs.ineligible
    iea = ie[ie["asin"].isin(scope)] if len(ie) else ie
    days = sorted({d for d in iea["date"].dropna() if d <= end_d}) if len(iea) else []
    on = lambda day: {a for a, s in zip(iea.loc[iea["date"] == day, "asin"], iea.loc[iea["date"] == day, "status"]) if _blocked(s)}  # noqa: E731
    now_b = on(days[-1]) if days else set()
    last = iea[iea["date"] == days[-1]] if days else iea
    why = {a: " · ".join(str(x) for x in (s, r) if x is not None and str(x).strip() and str(x) != "nan")
           for a, s, r in zip(last["asin"], last["status"], last["reason"])}
    prev_b = on(days[-2]) if len(days) >= 2 else set()

    now_li = {a for a in scope if a in info.index and _listing_issue(info.loc[a].to_dict())}
    has_base = prev_listing is not None
    prev_li = (set(prev_listing) & scope) if has_base else set()
    prev_text = _drop_inactive(prev_listing) if isinstance(prev_listing, dict) else {}  # the baseline run's own issue text
    # Baselines saved while Inactive / Withdrawal counted would read as "resolved"; a still-Inactive or Withdrawal
    # ASIN's resolution isn't actionable
    prev_li -= {a for a in prev_li - now_li if a in info.index and (
        str(info.loc[a].get("status") or "Active").lower() != "active" or str(info.loc[a].get("lifecycle") or "").lower() == "withdrawal")}
    history = history or {}
    hdays = sorted((d for d in history if d <= end_d.isoformat()), reverse=True)

    def resolved_issue(a):  # the baseline's text, else the latest saved day naming the issue (not the old-run placeholder)
        texts = [prev_text.get(a)] + [history[d].get(a) for d in hdays if d < end_d.isoformat()]
        return next((v for v in texts if v and v != OLD_RUN_ISSUE), prev_text.get(a, ""))

    def outstanding(a):
        # ponytail: streak over saved days only – gaps between saved days (no run that day) are skipped, a saved day
        # without the ASIN breaks it; history is capped at store.LISTING_DAYS
        run = list(takewhile(lambda d: history[d].get(a), hdays))
        lost = [v for d in run if est and (v := est(a, date.fromisoformat(d))) is not None]
        return {"issue": history[run[0]][a] if run else _listing_issue(info.loc[a].to_dict()),  # + Hết hàng → explains est
                "since": run[-1] if run else None, "days": len(run),
                "est_gmv_lost": sum(lost) if lost else None,
                "lost_cause": lost_cause(history[run[0]][a] if run else _listing_issue(info.loc[a].to_dict()))}

    oos, inv_ok = [], False
    if inv_params is not None and len(inputs.inventory):
        cover, meta = sku_cover(inputs.inventory, inputs.raw, sorted(scope), end_d, inv_params)
        inv_ok = not meta["stale"]
        if inv_ok:
            status_of = dict(zip(cover["asin"], cover["inv_status"]))
            days_of = dict(zip(cover["asin"], cover["days_left"]))
            low = {a for a in scope if status_of.get(a) in (OUT, LOW)}
            ads = inputs.ads  # only ASINs still spending on the latest data day (today−1); skip if that day's spend is 0
            spent = set(ads.loc[(ads["date"] == end_d) & ads["asin"].isin(low) & (ads["spend"] > 0), "asin"]) if len(ads) else set()
            oos = items(spent, lambda a: {"status": status_of.get(a),
                                          "days_left": None if days_of.get(a) is None else float(days_of[a])})

    return {"as_of": end_d.isoformat(), "blocked_total": len(now_b), "blocked_now": items(now_b, lambda a: {"issue": why.get(a, "")}),
            "blocked_new": items(now_b - prev_b), "blocked_removed": items(prev_b - now_b),
            "listing_new": items(now_li - prev_li, lambda a: {"issue": (iss := _listing_issue(info.loc[a].to_dict())),
                                                             "est_gmv_lost": est(a, end_d) if est else None, "lost_cause": lost_cause(iss)}),
            "listing_resolved": items(prev_li - now_li, lambda a: {"issue": resolved_issue(a)}),
            "listing_open": sorted(items(now_li & prev_li, outstanding), key=lambda x: -x["days"]),  # longest first, then PL/SKU
            "has_listing_baseline": has_base, "oos": oos, "inv_available": inv_ok}


def sku_listing(inputs, asin: str, sku: str, start_d: date, end_d: date, history: dict, keepa_history: dict | None) -> dict:
    """One SKU's listing over the timeframe (Performance Review, only when exactly one SKU is filtered):
    current = today's Keepa row; days = per data day the Keepa prices / Sales Rank saved by that day's run and the
    listing issue of the listing history ("" = clean, None = no snapshot that day). The newest data day takes this
    upload's own Keepa file, as the listing history does."""
    keepa = getattr(inputs, "keepa", None) or {}
    data_max = inputs.raw["date"].max()
    kh = {d: v for d, v in (keepa_history or {}).items()}
    if asin in keepa:
        kh[data_max.isoformat()] = {**kh.get(data_max.isoformat(), {}), asin: [keepa[asin].get(k) for k in KEEPA_SERIES]}
    days, day = [], start_d
    while day <= end_d:
        d = day.isoformat()
        vals = (kh.get(d) or {}).get(asin)
        days.append({"date": d, **dict(zip(KEEPA_SERIES, vals or [None] * len(KEEPA_SERIES))),
                     "issue": history[d].get(asin, "") if d in history else None})
        day += timedelta(days=1)
    return {"asin": asin, "sku": sku, "current": keepa.get(asin), "issue": history.get(data_max.isoformat(), {}).get(asin, ""),
            "days": days, "keepa_days": sum(1 for v in kh.values() if asin in v)}


def _many(v) -> list:  # a filter value: one string, several, or None / [] = all
    if isinstance(v, str):
        return [v] if v else []
    return [x for x in v or [] if x]


def period_spans(day: date, period: str) -> tuple[tuple[date, date], tuple[date, date]]:
    """(current, previous) date spans of the change-driver compare (feedback #51): day = the day vs the day before;
    week = the 7 days ending on the day vs the 7 days before; month = month-to-date vs the same days of the month before."""
    if period == "week":
        return (day - timedelta(days=6), day), (day - timedelta(days=13), day - timedelta(days=7))
    if period == "month":
        p0 = (day.replace(day=1) - timedelta(days=1)).replace(day=1)
        return (day.replace(day=1), day), (p0, p0.replace(day=min(day.day, calendar.monthrange(p0.year, p0.month)[1])))
    return (day, day), (day - timedelta(days=1), day - timedelta(days=1))


def change_drivers(r: pd.DataFrame, cur: tuple, prev: tuple, sku_of: dict, name_of: dict | None = None) -> dict:
    """Total + every PL (with every SKU) of the change from the `prev` span to the `cur` span (feedback #32, #51).
    name_of = ASIN → Product name, shown on the SKU rows (feedback #73).
    d_tacos = (Δ spend − TACOS of the previous span × Δ GMV) / GMV of the current span (both whole scope): the PL rows,
    and a PL's SKU rows, add up to the TACOS change. rs = Real Sale (units)."""
    cols = ["gmv", "spend", "units"]
    pick = lambda s: r[(r["date"] >= s[0]) & (r["date"] <= s[1])].groupby(["pl", "asin"])[cols].sum()  # noqa: E731
    both = pick(cur).merge(pick(prev), how="outer", left_index=True, right_index=True, suffixes=("", "_prev")).fillna(0.0)
    tot = both.sum()
    t0, g1 = _div(float(tot["spend_prev"]), float(tot["gmv_prev"])), float(tot["gmv"])

    def row(v) -> dict:
        dg, ds = float(v["gmv"] - v["gmv_prev"]), float(v["spend"] - v["spend_prev"])
        return {"gmv": float(v["gmv"]), "gmv_prev": float(v["gmv_prev"]), "d_gmv": dg,
                "spend": float(v["spend"]), "spend_prev": float(v["spend_prev"]), "d_spend": ds,
                "rs": float(v["units"]), "rs_prev": float(v["units_prev"]), "d_rs": float(v["units"] - v["units_prev"]),
                "tacos": _div(float(v["spend"]), float(v["gmv"])), "tacos_prev": _div(float(v["spend_prev"]), float(v["gmv_prev"])),
                "d_tacos": (ds - t0 * dg) / g1 if t0 is not None and g1 else None}
    return {"cur": [_iso(cur[0]), _iso(cur[1])], "prev": [_iso(prev[0]), _iso(prev[1])], "total": row(tot),
            "pls": [{"pl": pl, **row(grp.sum()), "skus": [{"sku": sku_of.get(a, a), "asin": a, "product": (name_of or {}).get(a, ""), **row(v)} for (_, a), v in grp.iterrows()]}
                    for pl, grp in both.groupby(level="pl")]}


CROSS_KEYS = ("cross_nmv", "cross_rs", "halo_nmv", "halo_rs")


def cross_halo(conv: pd.DataFrame | None, start_d: date, end_d: date, pl_of: dict | None = None,
               pl_all: dict | None = None) -> dict | None:
    """Converted product rows (USD) of the timeframe → {"asin": {asin: sums}, "camp": {campaign_id: sums}, "camp_asin":
    {(campaign_id, asin): sums}, "pl": {pl: sums}}; None without the file. A row is cross sale when the converted ASIN ≠
    the advertised ASIN. Per ASIN: cross sale = sales its ads brought to other ASINs (advertised = it); halo effect = its
    own sales brought by other ASINs' ads (converted = it). Per campaign: cross sale only. NMV = sales, RS = units_sold.
    Per PL (feedback #63, pl_of = the page's ASIN → PL): cross sale = the PL's ads selling another PL's ASINs, halo =
    other PLs' ads selling the PL's ASINs – a sale between two ASINs of the same PL (pl_all = every tracker ASIN → PL)
    is neither."""
    if conv is None:
        return None
    c = conv[(conv["date"] >= start_d) & (conv["date"] <= end_d) & (conv["adv"] != conv["conv"])]
    sums = lambda by, nmv, rs, df=c: {k: {nmv: float(v["sales"]), rs: float(v["units"])}  # noqa: E731
                                      for k, v in df.groupby(by)[["sales", "units"]].sum().iterrows()}
    out = {"camp": sums("campaign_id", "cross_nmv", "cross_rs"), "camp_asin": sums(["campaign_id", "adv"], "cross_nmv", "cross_rs")}
    cross, halo = sums("adv", "cross_nmv", "cross_rs"), sums("conv", "halo_nmv", "halo_rs")
    out["asin"] = {a: {**dict.fromkeys(CROSS_KEYS, 0.0), **cross.get(a, {}), **halo.get(a, {})} for a in set(cross) | set(halo)}
    if pl_of is not None:
        cross = sums("pl", "cross_nmv", "cross_rs", _other_pl(c, "adv", "conv", pl_of, pl_all or {}))
        halo = sums("pl", "halo_nmv", "halo_rs", _other_pl(c, "conv", "adv", pl_of, pl_all or {}))
        out["pl"] = {k: {**dict.fromkeys(CROSS_KEYS, 0.0), **cross.get(k, {}), **halo.get(k, {})} for k in set(cross) | set(halo)}
    return out


def _other_pl(c: pd.DataFrame, side: str, other: str, pl_of: dict, pl_all: dict) -> pd.DataFrame:
    """Rows whose `side` ASIN is on the page (column pl = its PL) and whose `other` ASIN is in another PL (or in none)."""
    m = c.assign(pl=c[side].map(pl_of))
    m = m[m["pl"].notna() & (m["pl"] != "")]
    return m[m[other].map(lambda a: pl_all.get(a, pl_of.get(a))) != m["pl"]]


def _sku_names(products: pd.DataFrame) -> dict:
    """ASIN → SKU over every product of the tracker (a counterpart ASIN may be outside the page's filters)."""
    if "sku" not in products.columns:
        return {}
    p = products[~products["sku"].astype(str).str.strip().isin({"", "nan", "None"})].drop_duplicates("asin")
    return dict(zip(p["asin"], p["sku"].astype(str)))


def _product_names(products: pd.DataFrame) -> dict:
    """ASIN → Product name over every product of the tracker (feedback #64: shown in the cross sale / halo panels)."""
    if "product_name" not in products.columns:
        return {}
    p = products[~products["product_name"].astype(str).str.strip().isin({"", "nan", "None"})].drop_duplicates("asin")
    return dict(zip(p["asin"], p["product_name"].astype(str)))


def _pl_names(products: pd.DataFrame) -> dict:
    """ASIN → PL over every product of the tracker (whether a counterpart is in the same PL, page filters or not)."""
    p = products[products["pl"].astype(str).str.strip().ne("")]
    if "status" in p.columns:  # a duplicate ASIN: the Active row wins, as in aggregate.asin_map
        p = p.assign(_off=(p["status"] != "Active").astype(int)).sort_values("_off", kind="stable")
    p = p.drop_duplicates("asin")
    return dict(zip(p["asin"], p["pl"].astype(str)))


CROSS_TOP = 10  # counterparts listed per hover panel; the rest is one "+N khác" line


def cross_detail(conv: pd.DataFrame | None, start_d: date, end_d: date, pl_of: dict, sku_of: dict,
                 top: int = CROSS_TOP, pl_all: dict | None = None, name_of: dict | None = None) -> dict | None:
    """Feedback #61: where each SKU's / PL's cross sale and halo effect come from / go to, for the hover panels.
    {"sku": {asin: {key: entry}}, "pl": {pl: {key: entry}}}, key ∈ CROSS_KEYS, entry = {"top": [[sku, asin, name, value],
    …] (largest first, at most `top`; name = Product name, feedback #64), "more": count of the other counterparts,
    "rest": their sum}. Cross sale of X lists
    the converted (purchased) ASINs of X's ads; halo of X lists the advertised ASINs whose ads sold X. A PL sums its
    SKUs (pl_of = the page's ASIN → PL, so only rows on the page) minus the sales between its own ASINs (pl_all = every
    tracker ASIN → PL, feedback #63). Same rows as cross_halo; zero values are left out.
    Feedback #76: also "camp" {campaign_id: …} and "camp_asin" {"campaign_id|advertised ASIN": …} – the converted ASINs
    behind the Campaign table's Cross-sale cells (cross sale only, every row of the campaign, as cross_halo["camp"])."""
    if conv is None:
        return None
    name_of = name_of or {}
    c = conv[(conv["date"] >= start_d) & (conv["date"] <= end_d) & (conv["adv"] != conv["conv"])]
    out: dict = {"sku": {}, "pl": {}, "camp": {}, "camp_asin": {}}

    def add(level: str, rows: pd.DataFrame, other: str, keys: tuple) -> None:
        g = rows.groupby(["row", other])[["sales", "units"]].sum()
        for (row_key, grp) in g.groupby(level="row"):
            for key, col in zip(keys, ("sales", "units")):
                v = grp[col].droplevel("row")
                v = v[v != 0].sort_values(ascending=False, kind="stable")
                if not len(v):
                    continue
                out[level].setdefault(row_key, {})[key] = {
                    "top": [[sku_of.get(a, ""), a, name_of.get(a, ""), float(x)] for a, x in v.iloc[:top].items()],
                    "more": max(len(v) - top, 0), "rest": float(v.iloc[top:].sum())}

    for side, other, keys in (("adv", "conv", CROSS_KEYS[:2]), ("conv", "adv", CROSS_KEYS[2:])):
        mine = c[c[side].isin(pl_of.keys())]
        between = _other_pl(c, side, other, pl_of, pl_all or {})  # PL level: same-PL sales are neither (#63)
        add("sku", mine.assign(row=mine[side]), other, keys)
        add("pl", between.assign(row=between["pl"]), other, keys)
    cid = c["campaign_id"].astype(str)
    add("camp", c.assign(row=cid), "conv", CROSS_KEYS[:2])
    add("camp_asin", c.assign(row=cid + "|" + c["adv"].astype(str)), "conv", CROSS_KEYS[:2])
    return out


def _scope(inputs, rj: dict, team_label: str, end_d: date, pic: list, leader: list, pl: list):
    """(team map ∧ PIC ∧ Sales Leader, ∧ Product line, PIC options, leader options) – shared by the page and its drivers."""
    amap = scoped_map(inputs.products, end_d, rj.get("model"), team_label)
    pics = sorted(set(amap["pic"]) - {NO_PIC})
    if pic:
        amap = amap[amap["pic"].isin(pic)]
    # Sales Leader (Product Info column): options = leaders of the team-scoped, PIC-filtered ASINs
    leaders = sorted(set(amap["leader"]) - {""}) if "leader" in amap.columns else []
    if leader:
        amap = amap[amap["leader"].isin(leader)] if "leader" in amap.columns else amap.iloc[0:0]
    return amap, (amap if not pl else amap[amap["pl"].isin(pl)]), pics, leaders


def _end_day(inputs, end: str | None) -> date:
    data_min, data_max = inputs.raw["date"].min(), inputs.raw["date"].max()
    return min(max(date.fromisoformat(end), data_min), data_max) if end else data_max


def period_drivers(inputs, rj: dict, team_label: str = "", pic=None, pl=None, end: str | None = None, leader=None,
                   chart_asin=None, day: str | None = None, period: str = "day") -> dict:
    """The change-driver table for one day and period, on demand (feedback #51): same scope as performance() (PIC ∧ Sales
    Leader ∧ Product line ∧ SKU), but read from the whole raw data, so a week / month compare can reach before the timeframe."""
    end_d = _end_day(inputs, end)
    _, pl_map, _, _ = _scope(inputs, rj, team_label, end_d, _many(pic), _many(leader), _many(pl))
    asins = set(_many(chart_asin) or pl_map["asin"])
    cur, prev = period_spans(date.fromisoformat(day) if day else end_d, period)
    raw = inputs.raw[(inputs.raw["date"] >= prev[0]) & (inputs.raw["date"] <= cur[1]) & inputs.raw["asin"].isin(asins)]
    out = change_drivers(raw.merge(pl_map[["asin", "pl"]], on="asin"), cur, prev,
                         dict(zip(pl_map["asin"], pl_map["sku"] if "sku" in pl_map.columns else pl_map["asin"])),
                         _product_names(inputs.products))
    return {**out, "day": _iso(cur[1]), "period": period, "partial": prev[0] < inputs.raw["date"].min()}


# Summary insight (feedback #54): GMV day change vs the day before, the PLs carrying GMV, the most off-track PL.
INSIGHT_ABNORMAL = 0.2  # day GMV off its L3D / L7D daily average by more than ±20% → abnormal, else a one-day move
INSIGHT_FLAT = 0.05  # a PL's change within ±5% counts as flat (signal)
INSIGHT_DROP = 0.1  # off-track reasons: spend / CVR / ASP of the insight day below its L7D daily average by more than 10%
INSIGHT_TOP_PLS = 3


def insight_day(start_d: date, end_d: date, last_d: date) -> date:
    """The day the insight evaluates (feedback #57): the last data day is usually incomplete, so the day before it
    (an earlier end day is kept). A timeframe (of the month) with only that one day keeps it."""
    d = min(end_d, last_d - timedelta(days=1))
    return d if d >= max(start_d, end_d.replace(day=1)) else end_d


def pf_insight(raw: pd.DataFrame, kpi: pd.DataFrame, start_d: date, end_d: date, last_d: date, issues: dict) -> dict:
    """raw = every raw day of the PIC ∧ Sales Leader scope (with pl), so the days before the timeframe count for the
    day before / L3D / L7D; kpi = the month's KPI with pl; last_d = the last data day. Every section is as of the
    insight day (insight_day, feedback #57): to-date GMV / achieve / time gone, its change vs the day before, and
    vs L3D / L7D = vs the daily average of the 3 / 7 days before it (that have data). PL GMV share and achieve:
    timeframe start → insight day; issues = day_issues {asin: issue} (current listing / stock snapshot)."""
    day_d = insight_day(start_d, end_d, last_d)
    first = raw["date"].min() if len(raw) else day_d
    back = lambda n: [d for d in (day_d - timedelta(days=i) for i in range(1, n + 1)) if d >= first]  # noqa: E731
    cols = ["gmv", "spend", "ads_gmv", "units", "ads_units", "sessions"]
    r = raw[(raw["date"] >= day_d - timedelta(days=7)) & (raw["date"] <= day_d)]
    zero = pd.Series(0.0, index=cols)

    def at(g, d):
        return g.loc[d] if d in g.index else zero

    def avg(g, days):  # daily average over the days (a day without rows = 0), not their sum (feedback #57)
        return sum((at(g, d) for d in days), zero) / len(days) if days else None

    def vs(a, b):  # relative change a vs b
        return _div(a - b, b) if b is not None else None

    # Overall PFM to the insight day (feedback #57): time gone = its day of the month
    tf_raw = raw[(raw["date"] >= start_d) & (raw["date"] <= day_d)]
    gmv, spend = float(tf_raw["gmv"].sum()), float(tf_raw["spend"].sum())
    t_gmv, t_spend = float(kpi["gmv"].sum()), float(kpi["spend"].sum())
    time_gone = day_d.day / calendar.monthrange(end_d.year, end_d.month)[1]
    overall = {"gmv": gmv, "gmv_target": t_gmv, "gmv_pct": _div(gmv, t_gmv), "time_gone": time_gone,
               "tacos": _div(spend, gmv), "tacos_target": _div(t_spend, t_gmv)}

    day = r.groupby("date")[cols].sum()
    cur, prev = at(day, day_d), (at(day, day_d - timedelta(days=1)) if back(1) else None)
    l3, l7 = avg(day, back(3)), avg(day, back(7))
    change = None
    if prev is not None:
        d_gmv, d_ads = float(cur["gmv"] - prev["gmv"]), float(cur["ads_gmv"] - prev["ads_gmv"])
        tacos, tacos_prev = _div(float(cur["spend"]), float(cur["gmv"])), _div(float(prev["spend"]), float(prev["gmv"]))
        vs3, vs7 = (vs(float(cur["gmv"]), float(x["gmv"])) if x is not None else None for x in (l3, l7))
        change = {"day": day_d.isoformat(), "prev": (day_d - timedelta(days=1)).isoformat(),
                  "gmv": float(cur["gmv"]), "d_gmv": d_gmv, "gmv_pct": vs(float(cur["gmv"]), float(prev["gmv"])),
                  "d_spend": float(cur["spend"] - prev["spend"]), "spend_pct": vs(float(cur["spend"]), float(prev["spend"])),
                  "d_tacos": tacos - tacos_prev if tacos is not None and tacos_prev is not None else None,
                  "d_ads": d_ads, "d_organic": d_gmv - d_ads, "d_ads_rs": float(cur["ads_units"] - prev["ads_units"]),
                  "ads_share": _div(d_ads, d_gmv), "organic_share": _div(d_gmv - d_ads, d_gmv),
                  "cause": None if d_gmv == d_ads == 0 else "ads" if abs(d_ads) >= abs(d_gmv - d_ads) else "organic",
                  "l3d_gmv": float(l3["gmv"]) if l3 is not None else None, "l7d_gmv": float(l7["gmv"]) if l7 is not None else None,
                  "vs_l3d": vs3, "vs_l7d": vs7,
                  "abnormal": any(v is not None and abs(v) > INSIGHT_ABNORMAL for v in (vs3, vs7))}

    by_pl = r.groupby(["pl", "date"])[cols].sum()
    pl_days = lambda n: by_pl.xs(n, level="pl") if n in by_pl.index.get_level_values("pl") else by_pl.iloc[0:0].droplevel("pl")  # noqa: E731
    tf = tf_raw.groupby("pl")["gmv"].sum()
    total = float(tf.sum())
    top = []
    for name, g in tf[tf > 0].sort_values(ascending=False).head(INSIGHT_TOP_PLS).items():
        g_pl = pl_days(name)
        now = float(at(g_pl, day_d)["gmv"])
        ch = [vs(now, float(x["gmv"])) if x is not None else None
              for x in (at(g_pl, day_d - timedelta(days=1)) if back(1) else None, avg(g_pl, back(3)), avg(g_pl, back(7)))]
        up, down = (sum(1 for v in ch if v is not None and f(v)) for f in (lambda v: v > INSIGHT_FLAT, lambda v: v < -INSIGHT_FLAT))
        top.append({"pl": name, "share": _div(float(g), total), "vs_prev": ch[0], "vs_l3d": ch[1], "vs_l7d": ch[2],
                    "signal": "up" if up >= 2 else "down" if down >= 2 else "flat"})

    # Most off-track PL (feedback #57): the largest GMV gap in $, not the lowest % – gap = the time-gone share of the
    # target not yet reached
    tgt = kpi.groupby("pl")["gmv"].sum()
    off = max(((n, float(tf.get(n, 0.0)), float(t)) for n, t in tgt.items() if t > 0),
              key=lambda x: x[2] * time_gone - x[1], default=None)
    worst = None
    if off and off[2] * time_gone - off[1] > 0:
        name, a, t = off
        g_pl = pl_days(name)
        now, base = at(g_pl, day_d), avg(g_pl, back(7))
        asins = set(raw.loc[raw["pl"] == name, "asin"]) | set(kpi.loc[kpi["pl"] == name, "asin"])
        oos = sum(1 for x in asins if OOS in issues.get(x, ""))
        listing = sum(1 for x in asins if issues.get(x, "").replace(OOS, "").strip(" ·"))
        ratio = lambda n_, d_: lambda v: _div(float(v[n_]), float(v[d_]))  # noqa: E731
        drops = {k: vs(f(now), f(base)) if base is not None and f(now) is not None and f(base) is not None else None
                 for k, f in (("spend", lambda v: float(v["spend"])), ("cvr", ratio("units", "sessions")), ("asp", ratio("gmv", "units")))}
        reasons = ([{"k": "oos", "n": oos}] if oos else []) + ([{"k": "listing", "n": listing}] if listing else []) + \
            [{"k": k, "v": v} for k, v in drops.items() if v is not None and v < -INSIGHT_DROP]
        worst = {"pl": name, "achieve": a / t, "gap": t * time_gone - a, "reasons": reasons}
    return {"day": day_d.isoformat(), "last": last_d.isoformat(), "overall": overall,
            "change": change, "top_pls": top, "off_track": worst}


def performance(inputs, rj: dict, team_label: str = "", pic: str | list | None = None, pl: str | list | None = None,
                start: str | None = None, end: str | None = None,
                inv_params: dict | None = None, prev_listing=None, listing_history: dict | None = None,
                leader: str | list | None = None, chart_asin: str | list | None = None,
                keepa_history: dict | None = None) -> dict:
    """pic / leader / pl / chart_asin: one value, several, or None = all.
    chart_asin: the SKU filter (ASINs of the PL scope) – the daily chart series follow it (tables filter by SKU in the UI).
    team_label scopes like the score model; with the Ver 1 rule model (no label) the month's PIC column is used.
    The timeframe follows the raw_sso_us dates (first → last data day); default = month of the last data day.
    listing_history: {data day ISO: {asin: issue}} saved by earlier runs; this upload's snapshot is its last data day.
    keepa_history: {data day ISO: {asin: KEEPA_SERIES values}} – with exactly one SKU picked, its listing chart (sku_listing)."""
    data_min, data_max = inputs.raw["date"].min(), inputs.raw["date"].max()
    end_d = _end_day(inputs, end)
    month_start = end_d.replace(day=1)
    start_d = min(max(date.fromisoformat(start) if start else month_start, data_min), end_d)
    dim = calendar.monthrange(end_d.year, end_d.month)[1]

    pic, leader, pl, chart_asin = _many(pic), _many(leader), _many(pl), _many(chart_asin)
    amap, pl_map, pics, leaders = _scope(inputs, rj, team_label, end_d, pic, leader, pl)
    pls_all = sorted(set(amap["pl"]))
    # Summary tiles: the PIC; every table (today card, PL, SKU, listing issue, campaigns) and the charts follow all the
    # filters combined (PIC ∧ Sales Leader ∧ Product line ∧ SKU).
    raw = inputs.raw[(inputs.raw["date"] >= start_d) & (inputs.raw["date"] <= end_d) & inputs.raw["asin"].isin(set(amap["asin"]))]
    raw = raw.merge(amap[["asin", "pl"]], on="asin")
    kpi = inputs.kpi[(inputs.kpi["month"] == end_d.month) & inputs.kpi["asin"].isin(set(amap["asin"]))].merge(amap[["asin", "pl"]], on="asin")
    contrib = {d: v for d, v in (inputs.contrib or {}).items() if d.month == end_d.month and d.year == end_d.year}
    pl_page = dict(zip(pl_map["asin"], pl_map["pl"]))
    pl_all = _pl_names(inputs.products)
    ch = cross_halo(getattr(inputs, "converted", None), start_d, end_d, pl_page, pl_all)
    share = lambda d, k: contrib[d][k] if d in contrib else 1 / dim  # noqa: E731

    def sums(r: pd.DataFrame, k: pd.DataFrame) -> tuple[dict, dict]:
        return ({"gmv": float(r["gmv"].sum()), "units": float(r["units"].sum()), "spend": float(r["spend"].sum()),
                 "ads_gmv": float(r["ads_gmv"].sum()), "ads_units": float(r["ads_units"].sum())},
                {"gmv": float(k["gmv"].sum()), "rs": float(k["rs"].sum()), "spend": float(k["spend"].sum())})

    def from_sums(rs: dict, ks: dict) -> tuple[dict, dict, dict]:
        act = {"gmv": float(rs.get("gmv", 0.0)), "rs": float(rs.get("units", 0.0)), "spend": float(rs.get("spend", 0.0))}
        act["tacos"] = _div(act["spend"], act["gmv"])
        act["acos"] = _div(act["spend"], float(rs.get("ads_gmv", 0.0)))  # no ACOS target in KPI → actual only
        act["ads_nmv"], act["ads_rs"] = float(rs.get("ads_gmv", 0.0)), float(rs.get("ads_units", 0.0))  # actual only
        act["ads_rs_share"] = _div(act["ads_rs"], act["rs"])
        if ch is not None:  # cross sale / halo effect (converted product file), actual only
            act.update({k: float(rs.get(k, 0.0)) for k in CROSS_KEYS})
        tgt = {"gmv": float(ks.get("gmv", 0.0)), "rs": float(ks.get("rs", 0.0)), "spend": float(ks.get("spend", 0.0))}
        tgt["tacos"] = _div(tgt["spend"], tgt["gmv"])
        ach = {m: _div(act[m], tgt[m]) for m in ("gmv", "rs", "spend", "tacos")}
        return tgt, act, ach

    def totals(r: pd.DataFrame, k: pd.DataFrame) -> tuple[dict, dict, dict]:
        return from_sums(*sums(r, k))

    def grouped(by: str) -> tuple[dict, dict]:  # per-PL / per-ASIN sums in one pass (was one table scan per row)
        r = raw.groupby(by)[["gmv", "units", "spend", "ads_gmv", "ads_units"]].sum().to_dict("index")
        if ch is not None:  # + cross sale / halo effect of each ASIN, or each PL (between PLs, feedback #63)
            per = ch["pl"] if by == "pl" else {a: v for a, v in ch["asin"].items() if a in pl_page}
            for k, v in per.items():
                r[k] = {**r.get(k, {}), **v}
        return r, kpi.groupby(by)[["gmv", "rs", "spend"]].sum().to_dict("index")

    tgt, act, _ = totals(raw, kpi)
    ads_gmv, units, ads_units = float(raw["ads_gmv"].sum()), float(raw["units"].sum()), float(raw["ads_units"].sum())
    summary = {
        "time_gone": end_d.day / dim,
        "campaign_gone": sum(v["gmv"] for d, v in contrib.items() if d <= end_d) if contrib else None,
        "gmv": act["gmv"], "gmv_target": tgt["gmv"], "gmv_pct": _div(act["gmv"], tgt["gmv"]),
        "spend": act["spend"], "spend_target": tgt["spend"], "spend_pct": _div(act["spend"], tgt["spend"]),
        "ads_nmv": ads_gmv, "acos": _div(act["spend"], ads_gmv), "tacos": act["tacos"],
        "tacos_target": tgt["tacos"],  # Σ spend target ÷ Σ GMV target of the scope (never an average of ratios)
        "ads_rs_share": _div(ads_units, units),
    }

    pl_rows = {r["pl"]: r for r in rj.get("pl", [])}
    pls = []
    raw_by_pl, kpi_by_pl = grouped("pl")
    for name in sorted(set(pl_map["pl"])):  # the filtered PL, or every PL of the PIC
        t, a, ach = from_sums(raw_by_pl.get(name, {}), kpi_by_pl.get(name, {}))
        r = pl_rows.get(name, {})
        pls.append({"pl": name, "target": t, "actual": a, "achieve": ach, "action": r.get("pacing_action") or "",
                    "sev": r.get("pacing_sev") or "", "reason": r.get("pacing_reason") or ""})

    ineligible = ineligible_fn(inputs, month_start, end_d)
    info = inputs.products.drop_duplicates("asin").set_index("asin")
    info_d = info.to_dict("index")
    raw_by_asin, kpi_by_asin = grouped("asin")
    raw_pl, kpi_pl = raw[raw["pl"].isin(set(pl_map["pl"]))], kpi[kpi["pl"].isin(set(pl_map["pl"]))]
    sku_stock = sku_stock_fn(inputs, end_d.month)

    incoming = getattr(inputs, "incoming", None) or {}  # SKU key → nearest arrival (loaders._incoming)
    skus = []
    for a, sku, name in sorted(zip(pl_map["asin"], pl_map["sku"] if "sku" in pl_map.columns else pl_map["asin"], pl_map["pl"]),
                               key=lambda x: (x[2], x[1])):
        t, ac, ach = from_sums(raw_by_asin.get(a, {}), kpi_by_asin.get(a, {}))
        prod = info_d.get(a, {})
        skus.append({"sku": sku, "asin": a, "pl": name, "product": prod.get("product_name") or "",
                     "ineligible": ineligible(a),
                     "stock": sku_stock(a, sku),
                     "incoming": incoming.get(str(sku).strip().upper()), "listing_issue": _listing_issue(prod),
                     "target": t, "actual": ac, "achieve": ach})

    if chart_asin:  # target = the SKU's monthly target × the Summary allocate-by-day share, as for a PL
        raw_pl, kpi_pl = raw_pl[raw_pl["asin"].isin(chart_asin)], kpi_pl[kpi_pl["asin"].isin(chart_asin)]
    daily = []
    by_day = raw_pl.groupby("date")[["gmv", "spend", "ads_gmv", "units", "ads_units"]].sum()
    t_pl, _, _ = totals(raw_pl, kpi_pl)
    day = start_d
    while day <= end_d:
        v = by_day.loc[day] if day in by_day.index else None
        g, s, ag = (float(v["gmv"]), float(v["spend"]), float(v["ads_gmv"])) if v is not None else (0.0, 0.0, 0.0)
        u, au = (float(v["units"]), float(v["ads_units"])) if v is not None else (0.0, 0.0)
        gt, stg = t_pl["gmv"] * share(day, "gmv"), t_pl["spend"] * share(day, "ppc")
        daily.append({"date": day.isoformat(), "gmv": g, "gmv_target": gt, "ads_nmv": ag, "ads_rs_share": _div(au, u),
                      "spend": s, "spend_target": stg, "acos": _div(s, ag), "tacos": _div(s, g), "tacos_target": _div(stg, gt)})
        day += timedelta(days=1)
    history = {**{d: _drop_inactive(v) for d, v in (listing_history or {}).items()}, data_max.isoformat(): day_issues(inputs, data_max)}
    est = gmv_lost_fn(inputs.raw[inputs.raw["asin"].isin(set(amap["asin"]))], history)
    pl_sku = dict(zip(pl_map["asin"], pl_map["sku"] if "sku" in pl_map.columns else pl_map["asin"]))
    pl_of = dict(zip(pl_map["asin"], pl_map["pl"]))
    issue_days = [{"date": d, "asin": a, "sku": pl_sku[a], "pl": pl_of[a], "issue": iss,
                   "est_gmv_lost": est(a, date.fromisoformat(d)), "lost_cause": lost_cause(iss)}
                  for d in sorted(history, reverse=True) if start_d.isoformat() <= d <= end_d.isoformat()
                  for a, iss in sorted(history[d].items()) if a in pl_sku and iss]
    one = [a for a in chart_asin if a in pl_sku]
    listing = sku_listing(inputs, one[0], pl_sku[one[0]], start_d, end_d, history, keepa_history) if len(one) == 1 else None
    times = {}
    for r in issue_days:
        times[(r["asin"], r["issue"])] = times.get((r["asin"], r["issue"]), 0) + 1
    for r in issue_days:
        r["count"] = times[(r["asin"], r["issue"])]  # days with this issue in the timeframe

    # Campaigns: the filters (PIC ∧ Sales Leader ∧ Product line; SKU client-side) pick which campaigns are listed – those
    # advertising at least one matching ASIN in the timeframe. A listed campaign's columns are always the sum of ALL its
    # team ASINs regardless of the filters, and its SKU / ASIN breakdown lists every one (in_scope = matches the filters).
    # The team scope itself is not a filter: non-team ASINs never reach this page.
    every = scoped_map(inputs.products, end_d, rj.get("model"), team_label)
    ads_t = inputs.ads[(inputs.ads["date"] >= start_d) & (inputs.ads["date"] <= end_d) & inputs.ads["asin"].isin(set(every["asin"]))]
    in_scope = set(pl_map["asin"])
    ads = ads_t[ads_t["campaign_id"].isin(set(ads_t.loc[ads_t["asin"].isin(in_scope), "campaign_id"]))]
    g = ads.groupby("campaign_id").agg(campaign=("campaign", "first"), spend=("spend", "sum"),
                                       nmv=("sales", "sum"), orders=("orders", "sum"), clicks=("clicks", "sum")).reset_index()
    pl_of_asin = dict(zip(every["asin"], every["pl"]))
    sku_of = dict(zip(every["asin"], every["sku"] if "sku" in every.columns else every["asin"]))
    pls_of = {cid: sorted({pl_of_asin[a] for a in set(s) if pl_of_asin.get(a)}) for cid, s in ads.groupby("campaign_id")["asin"]}
    by_asin = ads.groupby(["campaign_id", "asin"]).agg(spend=("spend", "sum"), nmv=("sales", "sum"),
                                                       orders=("orders", "sum"), clicks=("clicks", "sum")).reset_index()
    camp_skus: dict = {}
    camp_names = _product_names(inputs.products)
    for r in by_asin.sort_values("spend", ascending=False).to_dict("records"):
        camp_skus.setdefault(r["campaign_id"], []).append(
            {"sku": sku_of.get(r["asin"], r["asin"]), "asin": r["asin"], "pl": pl_of_asin.get(r["asin"], ""),
             "product": camp_names.get(r["asin"], ""),  # feedback #76
             "in_scope": r["asin"] in in_scope, "spend": r["spend"],
             **({k: ch["camp_asin"].get((r["campaign_id"], r["asin"]), {}).get(k, 0.0) for k in CROSS_KEYS[:2]} if ch else {}),
             "nmv": r["nmv"], "orders": r["orders"], "acos": _div(r["spend"], r["nmv"]),
             "clicks": r["clicks"], "cpc": _div(r["spend"], r["clicks"])})
    # The run's campaign rows are per (campaign, PL) but carry campaign-level metrics; take the most severe PL row.
    sev_rank = {"HIGH": 0, "MED": 1}
    run_camp: dict = {}
    for c in rj.get("camp", []):
        cur = run_camp.get(c.get("campaign_id"))
        if cur is None or sev_rank.get(c.get("sev"), 9) < sev_rank.get(cur.get("sev"), 9):
            run_camp[c.get("campaign_id")] = c
    # feedback #53: every action of the campaign's last action day, for the Last action hover note
    acts = parse_activity(inputs.activity)
    notes = acts.groupby(["camp_key", acts["action_date"].map(_iso)])["note"].agg(list).to_dict() if len(acts) else {}
    campaigns = []
    for r in g.sort_values("spend", ascending=False).to_dict("records"):
        c = run_camp.get(r["campaign_id"], {})
        l7, p7 = c.get("l7d_acos"), c.get("p7d_acos")
        campaigns.append({"campaign": r["campaign"], "campaign_id": r["campaign_id"], "pl": ", ".join(pls_of.get(r["campaign_id"], [])), "pls": pls_of.get(r["campaign_id"], []),
                          "spend": r["spend"], "nmv": r["nmv"], "orders": r["orders"],
                          **({k: ch["camp"].get(r["campaign_id"], {}).get(k, 0.0) for k in CROSS_KEYS[:2]} if ch else {}),
                          "acos": _div(r["spend"], r["nmv"]), "clicks": r["clicks"], "cpc": _div(r["spend"], r["clicks"]),
                          "trend_spend": c.get("d_spend"),
                          "trend_acos": (l7 / p7 - 1) if l7 is not None and p7 else None,
                          "last_action": c.get("last_action_date"), "last_action_type": c.get("last_action_type") or "",
                          "last_action_notes": notes.get((c.get("camp_key"), c.get("last_action_date")), []),
                          "alert": c.get("sev") in ("HIGH", "MED"), "action": c.get("final_label") or c.get("base_action") or "",
                          "skus": camp_skus.get(r["campaign_id"], [])})

    return {"filters": {"pic": pic, "pl": pl, "leader": leader, "sku": chart_asin, "leaders": leaders, "start": _iso(start_d), "end": _iso(end_d), "pics": pics, "pls": pls_all,
                        "min": _iso(data_min), "max": _iso(data_max)},
            "summary": summary, "pls": pls,
            # feedback #54: PIC ∧ Sales Leader ∧ date only (not the PL / SKU filters), like the tiles
            "insight": pf_insight(inputs.raw[inputs.raw["asin"].isin(set(amap["asin"]))].merge(amap[["asin", "pl"]], on="asin"),
                                  kpi, start_d, end_d, data_max, history[data_max.isoformat()]), "skus": skus, "daily": daily, "campaigns": campaigns,
            "ads_last": _iso(max((d for d in inputs.ads["date"] if d <= end_d), default=None)), "issue_days": issue_days,
            "history_days": len(history), "listing": listing,
            # converted product file: loaded or not, and its last day (cross sale / halo columns)
            "converted": ch is not None,
            # feedback #61: the counterparts behind each SKU / PL cross sale & halo cell (hover panels), top CROSS_TOP each;
            # feedback #76: and behind each campaign / campaign SKU cross sale cell
            "cross_detail": cross_detail(inputs.converted, start_d, end_d, pl_page, _sku_names(inputs.products),
                                         pl_all=pl_all, name_of=_product_names(inputs.products)) if ch is not None else None,
            "converted_last": _iso(max((d for d in inputs.converted["date"] if d <= end_d), default=None)) if ch is not None else None,
            # every table follows PIC ∧ Sales Leader ∧ Product line (pl_map); the SKU filter narrows them in the UI
            "today": today_summary(inputs, pl_map, info, inv_params, end_d, prev_listing, est, history)}
