"""Daily data kept across runs: the raw_sso_us, ads_camp and INELIGIBLE ASIN rows of every run, last KEEP_DAYS data days, in one
SQLite file next to the runs. A Data file covers ~45 days; each run replaces the days it carries (the newest export
wins) and the stored days older than the file are added in front of it, so analysis sees up to 3 months."""
import dataclasses
import sqlite3
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

from .loaders import fill_campaign_names

KEEP_DAYS = 92  # ~3 months of data days, counted back from the newest stored day
COLS = {"raw": ["date", "asin", "sku", "gmv", "ads_gmv", "spend", "clicks", "orders", "units", "ads_units", "promo",
                "sessions"],
        "ads": ["date", "account", "type", "campaign_id", "campaign", "asin", "spend", "clicks", "sales", "orders"],
        "ie": ["date", "asin", "status", "reason"],
        "inc": ["date", "sku", "label", "arrival"]}  # nearest incoming window per SKU on each data day


def _cat(stored: pd.DataFrame, new: pd.DataFrame) -> pd.DataFrame:
    """Stored days in front of the file's. SQL gives object columns when empty / all NULL: the file's numbers would
    become objects, and object division by 0 raises (ZeroDivisionError) instead of giving NaN / inf."""
    if not len(stored):
        return new.reset_index(drop=True)
    out = pd.concat([stored, new], ignore_index=True)
    return out.astype({c: float for c, t in new.dtypes.items() if t.kind == "f"})


def _incoming_rows(inputs) -> pd.DataFrame | None:
    inc = getattr(inputs, "incoming", None)  # inputs.pkl from before the field: no inventory incoming
    if not inc:
        return None
    return pd.DataFrame([{"date": inputs.raw["date"].max(), "sku": k, "label": v["window"], "arrival": v["arrival"]}
                         for k, v in inc.items()])


def incoming_changes(incoming: dict, prev: list[tuple], today: date) -> dict:
    """incoming + "change" ("earlier" / "delay" / "changed" when the headers are no dates) and "prev" (the earlier
    window) where the nearest window of the SKU moved since the previous data day. A previous window already over is
    no change (that shipment came in; the next one is the nearest now)."""
    before = {sku: (window, arrival) for sku, window, arrival in prev}
    out = {}
    for sku, v in incoming.items():
        v = {k: x for k, x in v.items() if k not in ("change", "prev")}
        if sku in before and before[sku][0] != v["window"]:
            was = before[sku][1]
            if was and v["arrival"]:
                if was >= today.isoformat() and was != v["arrival"]:
                    v |= {"change": "earlier" if v["arrival"] < was else "delay", "prev": before[sku][0]}
            elif not was and not v["arrival"]:
                v |= {"change": "changed", "prev": before[sku][0]}
        out[sku] = v
    return out


class History:
    def __init__(self, path: Path):
        self.path = Path(path)

    def _db(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.path, timeout=30)
        for t, cols in COLS.items():
            con.execute(f"create table if not exists {t} ({', '.join(cols)})")
            con.execute(f"create index if not exists {t}_date on {t} (date)")
        return con

    def save(self, inputs) -> None:
        """Store this run's rows: the days in the file replace the stored ones, then trim to KEEP_DAYS."""
        account = inputs.ads.attrs.get("account") or ""
        frames = {"raw": inputs.raw, "ads": inputs.ads.assign(account=account),
                  "ie": inputs.ineligible.dropna(subset=["date"]) if len(inputs.ineligible) else None,
                  "inc": _incoming_rows(inputs)}
        con = self._db()
        try:
            with con:
                for t, df in frames.items():
                    if df is None:  # no INELIGIBLE ASIN sheet / inventory file in this file → keep the stored days
                        continue
                    df = df[COLS[t]].assign(date=df["date"].map(date.isoformat))
                    days = [(d,) for d in sorted(set(df["date"]))]
                    if t == "ads":  # another account's rows are a different data set
                        con.executemany("delete from ads where date = ? and account = ?", [(d, account) for (d,) in days])
                    else:
                        con.executemany(f"delete from {t} where date = ?", days)
                    con.executemany(f"insert into {t} values ({', '.join('?' * len(COLS[t]))})",
                                    df.itertuples(index=False, name=None))
                newest = con.execute("select max(date) from raw").fetchone()[0]
                if newest:
                    cutoff = (date.fromisoformat(newest) - timedelta(days=KEEP_DAYS - 1)).isoformat()
                    for t in COLS:
                        con.execute(f"delete from {t} where date < ?", (cutoff,))
        finally:
            con.close()

    def merge(self, inputs):
        """inputs + the stored days older than the file (no source row: they are not in the file)."""
        if not self.path.exists():
            return inputs
        con = self._db()
        try:
            prev = con.execute("select sku, label, arrival from inc where date = (select max(date) from inc where date < ?)",
                               (inputs.raw["date"].max().isoformat(),)).fetchall()
            raw = pd.read_sql_query("select * from raw where date < ?", con,
                                    params=(inputs.raw["date"].min().isoformat(),))
            ads = pd.read_sql_query("select * from ads where date < ? and account = ?", con,
                                    params=(inputs.ads["date"].min().isoformat() if len(inputs.ads) else "",
                                            inputs.ads.attrs.get("account") or ""))
            ie_days = inputs.ineligible["date"].dropna() if "date" in inputs.ineligible else []
            ie = pd.read_sql_query("select * from ie where date < ?", con,  # no INELIGIBLE sheet → every stored day
                                   params=(ie_days.min().isoformat() if len(ie_days) else "9999",))
        finally:
            con.close()
        if getattr(inputs, "incoming", None) and prev:
            inputs = dataclasses.replace(inputs, incoming=incoming_changes(inputs.incoming, prev, inputs.raw["date"].max()))
        if raw.empty and ads.empty and ie.empty:
            return inputs
        for df in (raw, ads, ie):
            df["date"] = df["date"].map(date.fromisoformat)
        out_ads = fill_campaign_names(_cat(ads.drop(columns="account"), inputs.ads))
        out_ads.attrs = dict(inputs.ads.attrs)
        return dataclasses.replace(inputs, raw=_cat(raw, inputs.raw), ads=out_ads, ineligible=_cat(ie, inputs.ineligible))

    def info(self) -> dict:
        empty = {"first": None, "last": None, "days": 0, "missing": [], "months": [], "bytes": 0, "keep_days": KEEP_DAYS}
        if not self.path.exists():
            return empty
        con = self._db()
        try:
            raw = dict(con.execute("select date, count(*) from raw group by date").fetchall())
            ads = dict(con.execute("select date, count(*) from ads group by date").fetchall())
            ie = dict(con.execute("select date, count(*) from ie group by date").fetchall())
        finally:
            con.close()
        days = sorted(set(raw) | set(ads) | set(ie))
        if not days:
            return {**empty, "bytes": self.path.stat().st_size}
        rd = sorted(raw)  # gaps are counted inside raw_sso_us's own range (ads_camp may reach further back)
        first, last = (date.fromisoformat(rd[0]), date.fromisoformat(rd[-1])) if rd else (None, None)
        every = [(first + timedelta(days=i)).isoformat() for i in range((last - first).days + 1)] if rd else []
        months: dict[str, dict] = {}
        for d in days:
            m = months.setdefault(d[:7], {"month": d[:7], "days": 0, "raw_rows": 0, "ads_rows": 0, "ie_rows": 0})
            m["days"] += 1
            m["raw_rows"] += raw.get(d, 0)
            m["ads_rows"] += ads.get(d, 0)
            m["ie_rows"] += ie.get(d, 0)
        return {"first": days[0], "last": days[-1], "days": len(days), "missing": [d for d in every if d not in raw],
                "months": sorted(months.values(), key=lambda m: m["month"], reverse=True),
                "bytes": self.path.stat().st_size, "keep_days": KEEP_DAYS}

    def delete(self, month: str | None = None) -> None:
        """One month (YYYY-MM) or everything."""
        if not self.path.exists():
            return
        if month is None:
            self.path.unlink()
            return
        con = self._db()
        try:
            with con:
                for t in COLS:
                    con.execute(f"delete from {t} where substr(date, 1, 7) = ?", (month,))
            con.execute("vacuum")
        finally:
            con.close()
