"""The SharePoint exports for people who can open the files but not their folder, so OneDrive cannot sync them.

"Add shortcut to My files" on such a file leaves an Internet Shortcut (`<name>.xlsx.url`) in OneDrive whose URL= line
is the file's address. Sign-in: the SharePoint page opens in an app window and, once Microsoft's login lands back on
SharePoint, the window's cookies (FedAuth, rtFa) are kept encrypted (secrets.bin). Each run downloads the files with
them through _layouts/15/download.aspx; an expired session gives back the login page instead of a workbook."""
import urllib.parse
import urllib.request
from pathlib import Path

from .progress import check

SESSION = ("FedAuth", "rtFa")  # SharePoint Online sign-in cookies


class SharePointError(Exception):
    pass


def link_of(shortcut: Path) -> str:
    """`<name>.url` → the file's SharePoint address (without ?web=1)."""
    for line in shortcut.read_text(encoding="utf-8", errors="replace").splitlines():
        if line.strip().lower().startswith("url="):
            return line.strip()[4:].split("?")[0]
    raise SharePointError(f"{shortcut.name}: không có địa chỉ SharePoint")


def download_url(link: str) -> str:
    """https://host/sites/<site>/<library>/…/file.xlsx → the site's download.aspx for that file."""
    u = urllib.parse.urlsplit(link)
    parts = u.path.split("/")
    if len(parts) < 4 or parts[1] not in ("sites", "teams"):
        raise SharePointError(f"Không phải địa chỉ file SharePoint: {link}")
    site = "/".join(parts[:3])
    return (f"{u.scheme}://{u.netloc}{site}/_layouts/15/download.aspx?SourceUrl="
            + urllib.parse.quote(urllib.parse.unquote(u.path), safe="/"))


def signed_in(cookies: dict) -> bool:
    return all(cookies.get(k) for k in SESSION)


CHUNK = 256 * 1024  # bytes read between two looks at the Stop button


def _same(a: Path, b: Path) -> bool:
    if not (a.is_file() and b.is_file()) or a.stat().st_size != b.stat().st_size:
        return False
    with open(a, "rb") as fa, open(b, "rb") as fb:
        while True:
            x, y = fa.read(CHUNK), fb.read(CHUNK)
            if x != y:
                return False
            if not x:
                return True


def download(shortcuts: list[Path], cookies: dict, dest: Path, cancel=None) -> list[Path]:
    """Each shortcut's workbook → dest/<name>.xlsx (replaced only by a complete download). cancel: a threading.Event
    looked at between chunks – once set the download stops (progress.Cancelled) and its .part file is removed."""
    if not signed_in(cookies):
        raise SharePointError("chưa đăng nhập SharePoint – bấm “Lấy file SharePoint” một lần để đăng nhập")
    header = "; ".join(f"{k}={v}" for k, v in cookies.items())
    dest.mkdir(parents=True, exist_ok=True)
    out = []
    for s in shortcuts:
        check(cancel)
        req = urllib.request.Request(download_url(link_of(s)), headers={"Cookie": header, "User-Agent": "Mozilla/5.0"})
        f = dest / s.name.removesuffix(".url")
        tmp = f.with_name(f.name + ".part")
        try:
            try:
                with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as w:
                    first = True
                    while True:
                        check(cancel)
                        chunk = r.read(CHUNK)
                        if first and not chunk.startswith(b"PK"):  # an .xlsx is a zip; else the login / access-denied page
                            raise SharePointError("phiên đăng nhập SharePoint đã hết – bấm “Lấy file SharePoint” để đăng nhập lại")
                        first = False
                        if not chunk:
                            break
                        w.write(chunk)
            except OSError as e:  # urllib.error.* included
                raise SharePointError(f"{s.name.removesuffix('.url')}: tải từ SharePoint lỗi ({e})") from e
            check(cancel)
            if not _same(tmp, f):  # unchanged on SharePoint: keep the file (and its modified time) as it is
                try:
                    tmp.replace(f)
                except OSError as e:  # e.g. the file is open in Excel
                    raise SharePointError(f"{f.name}: không ghi đè được ({e}) – đóng file nếu đang mở rồi chạy lại") from e
        finally:
            tmp.unlink(missing_ok=True)  # never leave a half download behind
        out.append(f)
    return out
