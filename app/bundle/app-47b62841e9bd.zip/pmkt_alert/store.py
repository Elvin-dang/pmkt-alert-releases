"""User state under %APPDATA%\\PMKT Alert: runs, feedback, lessons, style, settings, logic versions.
Plain JSON written atomically; a corrupt file is set aside and defaults are used."""
import json
import os
import shutil
import sys
import threading
import time
import uuid
from datetime import date, datetime, timedelta
from pathlib import Path

from .logic import version_from_name

DEFAULT_STYLE = {"language": "vi_en_terms", "pronoun": "em_anhchi", "length": "short", "tone": "friendly_direct",
                 "emoji": "low", "samples": [], "rules": "", "pic_address": {}}
DEFAULT_SETTINGS = {"auto_update_check": True, "email_map": {}, "last_inputs": {}, "active_logic": None,
                    "github_repo": "Elvin-dang/pmkt-alert-releases", "ads_account": "", "careful_mode": True,
                    "memory_limit_mb": 1024, "auto_prune": True, "claude_note": ""}
MAX_MEMORY_BYTES = 1024 ** 3  # 1 GB hard cap
# Settings that belong to a team's data (an Admin working on several teams keeps one set per team); every other setting
# is the person's own (sign-in, role, language, layout...) and is shared by all the teams on this computer.
TEAM_KEYS = frozenset({"last_inputs", "last_run_files", "synced_paths", "active_logic", "score_weights", "step_times",
                       "hourly_path", "hourly_share", "reshared", "ads_account", "ads_profile_id", "email_map",
                       "claude_note"})


def replace(src: Path, dst: Path, tries: int = 20) -> None:
    """os.replace that rides out Windows briefly holding the target open (antivirus / search indexer right after a
    write: PermissionError, WinError 5 / 32 – about 1 in 75 rapid writes on a team PC). Up to ~1 s, then raises."""
    for i in range(tries):
        try:
            os.replace(src, dst)
            return
        except PermissionError:
            if i == tries - 1:
                raise
            time.sleep(0.01 * (i + 1))


def write_atomic(p: Path, data: bytes) -> None:
    """Write via a temp file + replace: readers never see half a file; the temp file never stays behind."""
    tmp = p.with_name(f"{p.name}.{uuid.uuid4().hex[:6]}.tmp")
    try:
        tmp.write_bytes(data)
        replace(tmp, p)
    finally:
        tmp.unlink(missing_ok=True)
LISTING_DAYS = 30  # listing-issue snapshots kept (was: only the previous run)
KEEPA_DAYS = 90  # Keepa price / rank snapshots kept (the one-SKU listing chart)
KEEPA_SERIES = ("bb", "new", "list", "amazon", "rank")  # one snapshot = these values in this order (compact on disk)
OLD_RUN_ISSUE = "Listing issue (lần chạy cũ)"  # backfilled day: only the ASIN list was saved, not the issue text


def default_base() -> Path:
    if sys.platform == "win32":
        return Path(os.environ.get("APPDATA", Path.home())) / "PMKT Alert"
    return Path.home() / ".pmkt-alert"


def _locked(fn):
    def wrapper(self, *a, **k):
        with self._lock:
            return fn(self, *a, **k)
    return wrapper


def _last_days(h: dict, days: int = LISTING_DAYS) -> dict:
    """Keep the `days` data days ending at the newest one."""
    if not h:
        return h
    cutoff = (date.fromisoformat(max(h)) - timedelta(days=days - 1)).isoformat()
    return {d: v for d, v in h.items() if d >= cutoff}


def _id() -> str:
    return uuid.uuid4().hex[:8]


class Store:
    # pywebview runs each JS call on its own thread; all read-modify-write goes through this lock.
    _lock = threading.RLock()

    def __init__(self, base: Path, home: "Store | None" = None):
        """home: a team's workspace (runs, logic versions, lessons, history, team settings in base) inside the person's
        own store (the other settings, writing style, sign-in). None = the person's own store, which is also the
        default team's workspace."""
        self.base = Path(base)
        self.home = home
        for d in ("runs", "logic"):
            (self.base / d).mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------- json io
    def _read(self, name: str, default):
        with self._lock:
            return self._read_unlocked(name, default)

    def _read_unlocked(self, name: str, default):
        p = self.base / name
        if not p.exists():
            return default
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            p.rename(p.with_name(f"{p.name}.corrupt-{datetime.now():%Y%m%d%H%M%S}"))
            return default

    def _write(self, name: str, data) -> None:
        p = self.base / name
        p.parent.mkdir(parents=True, exist_ok=True)
        with self._lock:
            write_atomic(p, json.dumps(data, ensure_ascii=False, indent=1).encode("utf-8"))

    # ------------------------------------------------------------- runs
    def save_run(self, result_json: dict, ai_json: dict | None) -> str:
        run_id = datetime.now().strftime("%Y%m%d-%H%M%S")
        while (self.base / "runs" / f"{run_id}.json").exists():
            run_id += "b"
        self._write(f"runs/{run_id}.json", {"run_id": run_id, "result": result_json, "ai": ai_json})
        if self.get_settings().get("auto_prune", True):
            self.prune()
        return run_id

    # ------------------------------------------------------------- listing-issue history
    def listing_history(self) -> dict:
        """{data day ISO: {asin: issue}} – one listing snapshot per data day, last LISTING_DAYS days.
        Data days missing from the history (runs before it existed) are backfilled from saved runs' listing_asins,
        latest run wins; runs that didn't save the issue text → OLD_RUN_ISSUE (never counted as buybox / OOS GMV lost)."""
        # A day persisted as all-placeholder (an earlier backfill) doesn't block a run that saved the issue text
        h = {d: v for d, v in self._read("listing_history.json", {}).items() if not v or set(v.values()) != {OLD_RUN_ISSUE}}
        old = {}
        # ponytail: reads every run file per call (as list_runs does); persist a marker if runs grow large
        for p in sorted((self.base / "runs").glob("*.json")):  # run_id order = oldest first
            res = self._read(f"runs/{p.name}", {}).get("result") or {}
            day = ((res.get("inputs") or {}).get("raw") or {}).get("last")
            if day and day not in h and "listing_asins" in res:
                old[day] = res.get("listing_issues") or dict.fromkeys(res["listing_asins"], OLD_RUN_ISSUE)  # text since v0.1.23
        return _last_days({**old, **h})

    def save_listing_day(self, day: str, issues: dict) -> None:
        self._write("listing_history.json", _last_days({**self.listing_history(), day: issues}))

    # ------------------------------------------------------------- Keepa price / rank history
    def keepa_history(self) -> dict:
        """{data day ISO: {asin: [bb, new, list, amazon, rank]}} (KEEPA_SERIES) – one Keepa snapshot per data day,
        last KEEPA_DAYS days. Starts with the first run that saved it: the Keepa file itself holds only today."""
        return self._read("keepa_history.json", {})

    def save_keepa_day(self, day: str, keepa: dict) -> None:
        snap = {a: [v.get(k) for k in KEEPA_SERIES] for a, v in keepa.items() if any(v.get(k) is not None for k in KEEPA_SERIES)}
        if snap:  # no Keepa file in this run: keep the history as it is
            self._write("keepa_history.json", _last_days({**self.keepa_history(), day: snap}, KEEPA_DAYS))

    # ------------------------------------------------------------- memory size
    def _limit_bytes(self) -> int:
        mb = float(self.get_settings().get("memory_limit_mb") or 1024)
        return int(min(mb * 1024 * 1024, MAX_MEMORY_BYTES))

    def _run_files(self) -> list[Path]:
        return sorted((self.base / "runs").glob("*.json"), key=lambda p: (p.stat().st_mtime, p.name))

    def usage(self) -> dict:
        kinds = {"runs": 0, "logic": 0, "lessons": 0, "feedback": 0, "proposals": 0, "history": 0, "other": 0}
        for p in self.base.rglob("*"):
            if not p.is_file():
                continue
            rel = p.relative_to(self.base).parts
            kind = rel[0] if rel[0] in ("runs", "logic") else p.stem if p.stem in kinds else "other"
            kinds[kind] += p.stat().st_size
        runs = self._run_files()
        oldest = None
        if runs:
            o = runs[0]
            oldest = {"run_id": o.stem, "date": datetime.fromtimestamp(o.stat().st_mtime).isoformat(timespec="seconds"),
                      "as_of": ((self._read(f"runs/{o.name}", {}).get("result") or {}).get("as_of"))}
        return {"bytes": sum(kinds.values()), "limit_bytes": self._limit_bytes(), "by_kind": kinds, "runs": len(runs),
                "oldest": oldest, "auto_prune": bool(self.get_settings().get("auto_prune", True))}

    @_locked
    def prune(self, limit_bytes: int | None = None) -> list[str]:
        """Delete the oldest runs until total size ≤ limit. Never the newest run; never lessons, logic, style, note."""
        limit = self._limit_bytes() if limit_bytes is None else limit_bytes
        total = sum(p.stat().st_size for p in self.base.rglob("*") if p.is_file())
        deleted = []
        for p in self._run_files()[:-1]:
            if total <= limit:
                break
            total -= p.stat().st_size
            p.unlink()
            deleted.append(p.stem)
        return deleted

    def load_run(self, run_id: str) -> dict:
        return self._read(f"runs/{run_id}.json", {})

    @_locked
    def update_run_ai(self, run_id: str, ai_json: dict) -> None:
        run = self.load_run(run_id)
        run["ai"] = ai_json
        self._write(f"runs/{run_id}.json", run)

    @_locked
    def save_run_field(self, run_id: str, key: str, value) -> None:
        run = self.load_run(run_id)
        run[key] = value
        self._write(f"runs/{run_id}.json", run)

    def list_runs(self) -> list[dict]:
        fb = self.list_feedback()
        out = []
        for p in sorted((self.base / "runs").glob("*.json"), reverse=True):
            run = self._read(f"runs/{p.name}", {})
            res = run.get("result") or {}
            alerts = sum(r.get("pacing_sev") in ("HIGH", "MED") for r in res.get("pl", [])) + \
                sum(r.get("sev") in ("HIGH", "MED") for r in res.get("camp", []))
            out.append({"run_id": run.get("run_id", p.stem), "as_of": res.get("as_of"),
                        "logic_version": res.get("logic_version"), "alert_count": alerts,
                        "feedback_count": sum(f.get("run_id") == run.get("run_id") for f in fb)})
        return out

    # ------------------------------------------------------------- feedback / lessons
    @_locked
    def add_feedback(self, item: dict) -> str:
        items = self._read("feedback.json", [])
        fid = _id()
        items.append({"status": "new", "created": datetime.now().isoformat(timespec="seconds"), **item, "id": fid})
        self._write("feedback.json", items)
        return fid

    def list_feedback(self, status: str | None = None) -> list[dict]:
        return [f for f in self._read("feedback.json", []) if status is None or f.get("status") == status]

    @_locked
    def set_feedback_status(self, fid: str, status: str) -> None:
        items = self._read("feedback.json", [])
        for f in items:
            if f["id"] == fid:
                f["status"] = status
        self._write("feedback.json", items)

    def lessons(self) -> list[dict]:
        return self._read("lessons.json", [])

    @_locked
    def add_lesson(self, text: str, source: str) -> str:
        items = self.lessons()
        lid = _id()
        items.append({"id": lid, "text": text, "source": source, "created": datetime.now().isoformat(timespec="seconds")})
        self._write("lessons.json", items)
        return lid

    @_locked
    def delete_lesson(self, lid: str) -> None:
        self._write("lessons.json", [x for x in self.lessons() if x["id"] != lid])

    # ------------------------------------------------------------- style / settings
    def get_style(self) -> dict:
        if self.home:  # the writing style is the person's, whatever team they work on
            return self.home.get_style()
        return {**DEFAULT_STYLE, **self._read("style.json", {})}

    def save_style(self, d: dict) -> None:
        if self.home:
            return self.home.save_style(d)
        with self._lock:
            self._write("style.json", {**self.get_style(), **d})

    @_locked
    def set_pic_address(self, pic: str, d: dict) -> None:
        style = self.get_style()
        style["pic_address"] = {**style.get("pic_address", {}), pic: {k: str(d.get(k, "")).strip() for k in ("self", "call", "name")}}
        self.save_style(style)

    @_locked
    def add_style_sample(self, text: str) -> None:
        style = self.get_style()
        style["samples"] = [*style["samples"], text][-10:]
        self.save_style(style)

    def get_settings(self) -> dict:
        if self.home:  # a team workspace: the person's settings + this team's own data settings
            own = {k: v for k, v in self.home.get_settings().items() if k not in TEAM_KEYS}
            return {**DEFAULT_SETTINGS, **own, **{k: v for k, v in self._read("settings.json", {}).items() if k in TEAM_KEYS}}
        return {**DEFAULT_SETTINGS, **self._read("settings.json", {})}

    def save_settings(self, d: dict) -> None:
        if self.home:
            if other := {k: v for k, v in d.items() if k not in TEAM_KEYS}:
                self.home.save_settings(other)
            if team := {k: v for k, v in d.items() if k in TEAM_KEYS}:
                with self._lock:
                    self._write("settings.json", {**self._read("settings.json", {}), **team})
            return
        with self._lock:
            self._write("settings.json", {**self.get_settings(), **d})

    # ------------------------------------------------------------- logic versions
    def import_logic(self, path: Path) -> Path:
        dest = self.base / "logic" / Path(path).name
        if Path(path).resolve() != dest.resolve():
            shutil.copyfile(path, dest)
        self.save_settings({"active_logic": dest.name})
        return dest

    def logic_versions(self) -> list[tuple[int, Path]]:
        return sorted((version_from_name(p.name), p) for p in (self.base / "logic").glob("*.xlsx"))

    def active_logic(self) -> Path | None:
        name = self.get_settings().get("active_logic")
        if name and (self.base / "logic" / name).exists():
            return self.base / "logic" / name
        versions = self.logic_versions()
        return versions[-1][1] if versions else None

    def set_active_logic(self, version: int) -> None:
        for v, p in self.logic_versions():
            if v == version:
                self.save_settings({"active_logic": p.name})
                return
        raise ValueError(f"Không có Alert_Logic Ver {version}")

    # ------------------------------------------------------------- proposals
    def proposals(self) -> list[dict]:
        return self._read("proposals.json", [])

    @_locked
    def save_proposals(self, items: list[dict]) -> None:
        self._write("proposals.json", items)

    @_locked
    def set_proposal_status(self, pid: str, status: str) -> None:
        items = self.proposals()
        for x in items:
            if x["id"] == pid:
                x["status"] = status
        self.save_proposals(items)

    @_locked
    def update_proposal(self, pid: str, fields: dict) -> None:
        items = self.proposals()
        for x in items:
            if x["id"] == pid:
                x.update(fields)
        self.save_proposals(items)
